"""
Entrena un Random Forest por sector que predice la humedad del suelo a 24 h
(punto 3.15.2 del marco práctico) usando la tabla muestras_ia generada por el backend.

Uso:  python entrenar_sector_rf.py
Salida: modelos/sector_<id>_rf.pkl y métricas impresas (MAE, RMSE).
"""
import os
import joblib
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
from conexion import consulta

FEATURES = ["humedad", "etc_loc_mm", "temp_suelo", "lluvia_prev_mm", "horas_desde_riego"]
os.makedirs("modelos", exist_ok=True)

df = consulta("SELECT * FROM muestras_ia WHERE humedad_objetivo IS NOT NULL ORDER BY fecha")
print(f"Muestras disponibles: {len(df)}")
for sector_id, d in df.groupby("sector_id"):
    d = d.dropna(subset=FEATURES + ["humedad_objetivo"])
    if len(d) < 30:
        print(f"Sector {sector_id}: datos insuficientes ({len(d)})"); continue
    corte = int(len(d) * 0.8)
    X, y = d[FEATURES].values, d["humedad_objetivo"].values
    rf = RandomForestRegressor(n_estimators=200, max_depth=10, random_state=42)
    rf.fit(X[:corte], y[:corte])
    pred = rf.predict(X[corte:])
    mae = mean_absolute_error(y[corte:], pred)
    rmse = np.sqrt(mean_squared_error(y[corte:], pred))
    joblib.dump(rf, f"modelos/sector_{sector_id}_rf.pkl")
    estado = "OK (≤ 0,02)" if mae <= 0.02 else "no cumple RNF-08"
    print(f"Sector {sector_id}: MAE={mae:.4f} RMSE={rmse:.4f} m3/m3 → {estado}")
    print("   importancia:", dict(zip(FEATURES, np.round(rf.feature_importances_, 3))))

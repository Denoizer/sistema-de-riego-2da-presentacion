"""
Entrena el modelo LSTM de predicción climática (punto 3.15.2) con las lecturas
de la estación (tabla lecturas_estacion) re-muestreadas por hora, y lo convierte
a TensorFlow Lite para ejecutarlo en la Raspberry Pi.

Uso:  python entrenar_clima_lstm.py
Salida: modelos/clima_ia.tflite
"""
import os
import numpy as np
import tensorflow as tf
from conexion import consulta

os.makedirs("modelos", exist_ok=True)
df = consulta("SELECT fecha, temp_c, hr_pct, viento_ms, radiacion_wm2, lluvia_mm, presion_kpa FROM lecturas_estacion ORDER BY fecha")
df = df.set_index("fecha").resample("1h").agg({"temp_c": "mean", "hr_pct": "mean", "viento_ms": "mean",
                                                "radiacion_wm2": "mean", "lluvia_mm": "sum", "presion_kpa": "mean"}).interpolate()
cols = list(df.columns)
mn, mx = df.min(), df.max()
datos = ((df - mn) / (mx - mn + 1e-9)).values
ENT, SAL = 48, 24
X, Y = [], []
for i in range(len(datos) - ENT - SAL):
    X.append(datos[i:i + ENT]); Y.append(datos[i + ENT:i + ENT + SAL, [0, 1, 4]].ravel())
X, Y = np.array(X), np.array(Y)
print("Ventanas:", X.shape)
corte = int(len(X) * 0.8)
modelo = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(ENT, len(cols))),
    tf.keras.layers.LSTM(64, return_sequences=True),
    tf.keras.layers.LSTM(32),
    tf.keras.layers.Dense(Y.shape[1]),
])
modelo.compile(optimizer="adam", loss="mse", metrics=["mae"])
modelo.fit(X[:corte], Y[:corte], validation_data=(X[corte:], Y[corte:]), epochs=40, batch_size=32,
           callbacks=[tf.keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True)])
pred = modelo.predict(X[corte:]).reshape(-1, SAL, 3)
real = Y[corte:].reshape(-1, SAL, 3)
mae_t = np.mean(np.abs(pred[:, :, 0] - real[:, :, 0])) * (mx["temp_c"] - mn["temp_c"])
print(f"MAE temperatura 24 h: {mae_t:.2f} °C (meta ≤ 1,5 °C)")
conv = tf.lite.TFLiteConverter.from_keras_model(modelo)
conv.optimizations = [tf.lite.Optimize.DEFAULT]
open("modelos/clima_ia.tflite", "wb").write(conv.convert())
print("Guardado modelos/clima_ia.tflite")

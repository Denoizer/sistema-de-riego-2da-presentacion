"""Conexión a la base MySQL riego_yungas (mismos datos que backend/.env)."""
import os
import pandas as pd
import pymysql

def conectar():
    return pymysql.connect(
        host=os.getenv("DB_HOST", "localhost"), port=int(os.getenv("DB_PUERTO", 3306)),
        user=os.getenv("DB_USUARIO", "riego_app"), password=os.getenv("DB_CLAVE", "RiegoApp2026!"),
        database=os.getenv("DB_NOMBRE", "riego_yungas"), charset="utf8mb4")

def consulta(sql, params=None):
    with conectar() as c:
        return pd.read_sql(sql, c, params=params)

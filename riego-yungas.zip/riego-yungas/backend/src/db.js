// Conexión a MySQL mediante un pool (mysql2/promise)
const mysql = require("mysql2/promise");
const config = require("./config");

const pool = mysql.createPool({
  ...config.db,
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true,       // DATETIME como texto 'YYYY-MM-DD HH:MM:SS'
  decimalNumbers: true,    // DECIMAL como número
  charset: "utf8mb4",
});

const limpiar = (p = []) => p.map(v => (v === undefined ? null : typeof v === "boolean" ? (v ? 1 : 0) : v));

/** Ejecuta una consulta SELECT y devuelve las filas */
async function q(sql, params) {
  const [filas] = await pool.query(sql, limpiar(params));
  return filas;
}
/** Devuelve la primera fila o null */
async function uno(sql, params) {
  const filas = await q(sql, params);
  return filas[0] || null;
}
/** Ejecuta INSERT/UPDATE/DELETE y devuelve { insertId, affectedRows } */
async function ejecutar(sql, params) {
  const [r] = await pool.query(sql, limpiar(params));
  return { insertId: r.insertId, affectedRows: r.affectedRows };
}

module.exports = { pool, q, uno, ejecutar };

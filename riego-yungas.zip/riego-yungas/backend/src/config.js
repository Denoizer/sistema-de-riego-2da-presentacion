// Carga de configuración desde backend/.env (sin dependencias externas)
const fs = require("fs");
const path = require("path");

const archivoEnv = path.join(__dirname, "..", ".env");
if (fs.existsSync(archivoEnv)) {
  for (const linea of fs.readFileSync(archivoEnv, "utf8").split(/\r?\n/)) {
    const m = linea.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}
process.env.TZ = process.env.TZ || "America/La_Paz";

const num = (v, d) => (v === undefined || v === "" ? d : Number(v));

module.exports = {
  puerto: num(process.env.PUERTO, 3000),
  jwtSecreto: process.env.JWT_SECRETO || "secreto-de-desarrollo",
  jwtHoras: num(process.env.JWT_HORAS, 8),
  db: {
    host: process.env.DB_HOST || "localhost",
    port: num(process.env.DB_PUERTO, 3306),
    user: process.env.DB_USUARIO || "root",
    password: process.env.DB_CLAVE || "",
    database: process.env.DB_NOMBRE || "riego_yungas",
  },
  simulador: process.env.SIMULADOR !== "0",
  acel: Math.max(1, num(process.env.SIM_ACELERACION, 60)),
  escenario: process.env.SIM_ESCENARIO || "seco",
  simUsarOpenMeteo: process.env.SIM_USAR_OPEN_METEO === "1",
};

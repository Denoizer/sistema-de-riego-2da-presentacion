// Estado en memoria del sistema (última lectura de cada dispositivo)
module.exports = {
  sectores: new Map(), // sector_id -> { humedad, h, temp, caudal, litros, bateria, rssi, valvula, ultimaVez, inicioValvula }
  nodosVistos: new Map(), // nodo_id -> timestamp ms del último mensaje
  tanque: { nivel_l: null, porcentaje: null, llenando: false, caudal_salida: 0 },
  clima: { temp_c: null, hr_pct: null, presion_kpa: null, viento_ms: null, radiacion_wm2: null, lluvia_1h: 0, fecha: null },
  lluviaReciente: [], // [{t, mm}] para calcular lluvia de la última hora
  ultimaPersistencia: new Map(), // clave -> ms
  enEvaluacion: new Set(),
};

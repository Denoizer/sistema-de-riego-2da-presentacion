// Supervisor: tareas periódicas del sistema (balance hídrico, horarios, vigilancia
// de nodos, resumen climático diario, predicción y aprendizaje de la IA)
const db = require("../db");
const config = require("../config");
const { ahora, fecha, fmt, parse } = require("../util/tiempo");
const estado = require("./estado");
const { guardarDia, etoReferencia } = require("./eto");
const { evaluarTodos, evaluarSector } = require("./decision");
const { obtenerConfig } = require("../servicios/config");
const { crearAlerta, resolverAutomaticamente } = require("../servicios/alertas");
const { emitir } = require("../servicios/notificador");
const iaClima = require("../ia/clima");
const iaSector = require("../ia/sector");
const { cargarSector, riegoEnCurso, iniciarRiego } = require("./riego");
const { notificar } = require("../servicios/notificador");

const PERIODO_S = 15;
let ultimoTick = Date.now();
let ultimaEvaluacion = 0, ultimaPrediccion = 0, ultimaMuestra = 0, ultimoDia = fecha(new Date()), ultimoParcial = 0;
const horariosHechos = new Set();
const arranque = Date.now();
const nodosAlertados = new Set();
const factorTiempo = () => (config.simulador ? config.acel : 1);

async function tick() {
  const ahoraMs = Date.now();
  const dtCampo = ((ahoraMs - ultimoTick) / 1000) * factorTiempo();
  ultimoTick = ahoraMs;
  const cfg = await obtenerConfig();

  // 1) Balance hídrico: el déficit crece con la ETc localizada
  const eto = await etoReferencia();
  const sectores = await db.q("SELECT s.id, s.deficit_mm, s.factor_kc_ia, s.estado, s.pospuesto_hasta, c.kc_medio kc, c.kr FROM sectores s JOIN cultivos c ON c.id = s.cultivo_id WHERE s.activo = 1");
  const etcPorSector = {};
  for (const s of sectores) {
    const etc = s.kc * s.factor_kc_ia * eto * s.kr;
    etcPorSector[s.id] = etc;
    const nuevo = Math.min(200, s.deficit_mm + (etc * dtCampo) / 86400);
    await db.ejecutar("UPDATE sectores SET deficit_mm = ? WHERE id = ?", [Math.round(nuevo * 100) / 100, s.id]);
    // Fin del aplazamiento por lluvia
    if (s.estado === "pospuesto" && s.pospuesto_hasta && parse(s.pospuesto_hasta) <= new Date()) {
      await db.ejecutar("UPDATE sectores SET estado = 'reposo', pospuesto_hasta = NULL WHERE id = ?", [s.id]);
      evaluarSector(s.id, "continuo").catch(() => {});
    }
  }

  // 1b) Riegos programados por el usuario (litros definidos)
  await ejecutarProgramados(cfg);

  // 2) Horarios de evaluación (p. ej. 05:00 y 17:00)
  const hhmm = new Date().toTimeString().slice(0, 5);
  const horarios = await db.q("SELECT hora FROM horarios_riego WHERE activo = 1");
  for (const h of horarios) {
    const clave = fecha(new Date()) + " " + String(h.hora).slice(0, 5);
    if (String(h.hora).slice(0, 5) === hhmm && !horariosHechos.has(clave)) {
      horariosHechos.add(clave);
      await evaluarTodos("horario");
    }
  }

  // 3) Evaluación continua
  if (ahoraMs - ultimaEvaluacion >= (cfg.evaluacion_continua_min || 10) * 60000) {
    ultimaEvaluacion = ahoraMs;
    await evaluarTodos("continuo");
  }

  // 4) Vigilancia de nodos (A-05)
  const limite = ((cfg.nodo_timeout_min || 15) * 60000) / factorTiempo();
  const nodos = await db.q("SELECT n.id, n.codigo, n.sector_id, n.en_linea, n.ultima_conexion FROM nodos n");
  for (const n of nodos) {
    // Tras arrancar se da un periodo de gracia antes de considerar caído un nodo
    const visto = Math.max(estado.nodosVistos.get(n.id) || 0, n.ultima_conexion ? parse(n.ultima_conexion).getTime() : 0, arranque);
    const caido = ahoraMs - visto > limite;
    if (caido && !nodosAlertados.has(n.id)) {
      nodosAlertados.add(n.id);
      await db.ejecutar("UPDATE nodos SET en_linea = 0 WHERE id = ?", [n.id]);
      await crearAlerta("A-05", { sector_id: n.sector_id, nodo_id: n.id, mensaje: `El nodo ${n.codigo} no reporta datos desde hace más de ${cfg.nodo_timeout_min || 15} min.` });
      emitir("sector", { id: n.sector_id });
    } else if (!caido && nodosAlertados.has(n.id)) {
      nodosAlertados.delete(n.id);
      await db.ejecutar("UPDATE nodos SET en_linea = 1 WHERE id = ?", [n.id]);
      await resolverAutomaticamente("A-05", { nodo_id: n.id }, "El nodo volvió a comunicarse");
    } else if (caido && n.en_linea) {
      await db.ejecutar("UPDATE nodos SET en_linea = 0 WHERE id = ?", [n.id]);
    }
  }

  // 5) Resumen climático diario y ETo (día anterior al cambiar de fecha; día actual cada 30 min)
  const hoy = fecha(new Date());
  if (hoy !== ultimoDia) { await guardarDia(ultimoDia); ultimoDia = hoy; }
  if (ahoraMs - ultimoParcial > 30 * 60000) { ultimoParcial = ahoraMs; await guardarDia(hoy); }

  // 6) IA: predicción climática cada 30 min; muestras de aprendizaje cada hora de campo
  if (ahoraMs - ultimaPrediccion > 30 * 60000) {
    ultimaPrediccion = ahoraMs;
    const r = await iaClima.generar();
    if (r) {
      emitir("prediccion", r);
      const p24 = await iaClima.resumen(24);
      if (p24 && p24.lluvia_mm >= (cfg.lluvia_intensa_mm || 30))
        await crearAlerta("A-10", { mensaje: `Se prevén ${p24.lluvia_mm.toFixed(1)} mm de lluvia en las próximas 24 h (prob. ${Math.round(p24.prob_max)} %).` });
    }
  }
  if (ahoraMs - ultimaMuestra > (3600 * 1000) / factorTiempo()) {
    if (await iaSector.registrarMuestras(etcPorSector)) ultimaMuestra = ahoraMs;
  }
  await iaSector.aprender();

  // 7) Internet de la unidad central (A-08) – solo con hardware real
  if (!config.simulador && cfg.usar_open_meteo) {
    const m = await db.uno("SELECT parametros FROM modelos_ia WHERE tipo = 'clima'");
    try {
      const om = JSON.parse(m.parametros || "{}").open_meteo;
      if (om && om.ok === false) await crearAlerta("A-08", { mensaje: "La unidad central no logra conectarse a internet. El riego continúa en modo local." });
      else if (om && om.ok) await resolverAutomaticamente("A-08", {}, "Conexión restablecida");
    } catch { /* sin datos */ }
  }
  emitir("tick", { fecha: ahora() });
}

async function ejecutarProgramados(cfg) {
  const vencidos = await db.q("SELECT * FROM riegos_programados WHERE activo = 1 AND proxima_ejecucion <= ? ORDER BY proxima_ejecucion", [ahora()]);
  for (const p of vencidos) {
    const sector = await cargarSector(p.sector_id);
    const siguiente = () => {
      if (p.repetir !== "diario") return null;
      const d = parse(p.proxima_ejecucion);
      while (d <= new Date()) d.setDate(d.getDate() + 1);
      return fmt(d);
    };
    const reprogramar = async (minutos) => db.ejecutar("UPDATE riegos_programados SET proxima_ejecucion = ? WHERE id = ?", [fmt(new Date(Date.now() + minutos * 60000)), p.id]);
    if (!sector || ["mantenimiento", "falla"].includes(sector.estado) || sector.modo === "mantenimiento") {
      const sig = siguiente();
      await db.ejecutar("UPDATE riegos_programados SET activo = ?, proxima_ejecucion = COALESCE(?, proxima_ejecucion) WHERE id = ?", [sig ? 1 : 0, sig, p.id]);
      await notificar(["agricultor", "admin"], `Riego programado omitido · ${sector ? sector.codigo : ""}`, `El sector está en ${sector ? sector.estado : "estado desconocido"}; no se aplicaron ${Math.round(p.litros)} L.`, "media", { sector_id: p.sector_id });
      continue;
    }
    if (await riegoEnCurso()) { await reprogramar(1); continue; } // riego secuencial: espera su turno
    const tq = await db.uno("SELECT nivel_l FROM tanques WHERE id = 1");
    if (tq.nivel_l < p.litros) {
      await reprogramar(10);
      await crearAlerta("A-01", { mensaje: `Tanque con ${Math.round(tq.nivel_l).toLocaleString("es-BO")} L: no alcanza para el riego programado de ${sector.codigo} (${Math.round(p.litros).toLocaleString("es-BO")} L).` });
      continue;
    }
    const minutos = (p.litros / sector.caudal_nominal_lh) * 60;
    await iniciarRiego(sector, { tipo: "programado", motivo: "M-10", litros: p.litros, lamina_mm: Math.round((p.litros / (sector.area_ha * 10000)) * 100) / 100,
      max_min: Math.ceil(minutos * 1.3) + 1, usuario_id: p.usuario_id, programado_id: p.id, detalleMotivo: `programación #${p.id}` });
    const sig = siguiente();
    await db.ejecutar("UPDATE riegos_programados SET ultima_ejecucion = ?, activo = ?, proxima_ejecucion = COALESCE(?, proxima_ejecucion) WHERE id = ?", [ahora(), sig ? 1 : 0, sig, p.id]);
    emitir("programados", {});
    void cfg;
  }
}

function iniciar() {
  const ejecutar = () => tick().catch(e => console.error("[supervisor]", e.message));
  setTimeout(async () => {
    try {
      await guardarDia(fecha(new Date(Date.now() - 86400000)));
      await iaClima.generar();
      ultimaPrediccion = Date.now();
    } catch (e) { console.error("[supervisor:init]", e.message); }
    ejecutar();
  }, 3000);
  setInterval(ejecutar, PERIODO_S * 1000);
}

module.exports = { iniciar, tick };

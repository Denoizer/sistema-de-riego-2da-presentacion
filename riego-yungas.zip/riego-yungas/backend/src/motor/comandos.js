// Cola de comandos hacia los nodos (válvulas de sector y válvula de llenado)
const db = require("../db");
const config = require("../config");
const { ahora } = require("../util/tiempo");

let ejecutorSimulado = null; // lo registra el simulador
const registrarEjecutorSimulado = fn => { ejecutorSimulado = fn; };

/**
 * Registra un comando. En modo simulación se ejecuta de inmediato;
 * con hardware real el nodo lo recoge en GET /api/iot/comandos.
 */
async function enviarComando(nodo_id, accion, { litros = null, minutos = null, usuario_id = null } = {}) {
  const r = await db.ejecutar(
    "INSERT INTO comandos (nodo_id, usuario_id, accion, litros, minutos, estado, creado_en) VALUES (?,?,?,?,?,?,?)",
    [nodo_id, usuario_id, accion, litros, minutos, "pendiente", ahora()]);
  const cmd = { id: r.insertId, nodo_id, accion, litros, minutos };
  if (config.simulador && ejecutorSimulado) {
    ejecutorSimulado(cmd);
    await db.ejecutar("UPDATE comandos SET estado = 'ejecutado', ejecutado_en = ? WHERE id = ?", [ahora(), cmd.id]);
  }
  return cmd;
}

async function nodoDeSector(sector_id) {
  const n = await db.uno("SELECT id FROM nodos WHERE sector_id = ? AND tipo = 'sector'", [sector_id]);
  return n ? n.id : null;
}
async function nodoTanque() {
  const n = await db.uno("SELECT id FROM nodos WHERE tipo = 'tanque' LIMIT 1");
  return n ? n.id : null;
}

module.exports = { enviarComando, registrarEjecutorSimulado, nodoDeSector, nodoTanque };

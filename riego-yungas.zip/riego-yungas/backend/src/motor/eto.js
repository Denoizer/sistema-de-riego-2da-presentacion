// Evapotranspiración de referencia FAO-56 Penman-Monteith y agregación diaria
const db = require("../db");
const { fecha, parse, diaDelAnio } = require("../util/tiempo");

/**
 * ETo diaria (mm/día) – FAO Penman-Monteith
 * @param {object} d { tmax, tmin, hrmax, hrmin, u2, rs (MJ/m²·día), z (m), lat (°), J (día del año) }
 */
function penmanMonteith({ tmax, tmin, hrmax, hrmin, u2, rs, z, lat, J }) {
  const tm = (tmax + tmin) / 2;
  const P = 101.3 * Math.pow((293 - 0.0065 * z) / 293, 5.26);
  const gamma = 0.000665 * P;
  const e = T => 0.6108 * Math.exp((17.27 * T) / (T + 237.3));
  const es = (e(tmax) + e(tmin)) / 2;
  const ea = (e(tmin) * hrmax / 100 + e(tmax) * hrmin / 100) / 2;
  const delta = (4098 * e(tm)) / Math.pow(tm + 237.3, 2);
  const phi = (lat * Math.PI) / 180;
  const dr = 1 + 0.033 * Math.cos((2 * Math.PI * J) / 365);
  const dec = 0.409 * Math.sin((2 * Math.PI * J) / 365 - 1.39);
  const ws = Math.acos(-Math.tan(phi) * Math.tan(dec));
  const ra = ((24 * 60) / Math.PI) * 0.082 * dr * (ws * Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.sin(ws));
  const rso = (0.75 + 2e-5 * z) * ra;
  const rns = 0.77 * rs;
  const rnl = 4.903e-9 * ((Math.pow(tmax + 273.16, 4) + Math.pow(tmin + 273.16, 4)) / 2) * (0.34 - 0.14 * Math.sqrt(ea)) * (1.35 * Math.min(rs / rso, 1) - 0.35);
  const rn = rns - rnl;
  const eto = (0.408 * delta * rn + gamma * (900 / (tm + 273)) * u2 * (es - ea)) / (delta + gamma * (1 + 0.34 * u2));
  return { eto: Math.max(0, eto), P, gamma, es, ea, delta, ra, rso, rns, rnl, rn };
}

/** Agrega las lecturas de la estación de un día y calcula su ETo */
async function calcularDia(dia) {
  const finca = await db.uno("SELECT latitud, altitud_m FROM fincas WHERE id = 1");
  const a = await db.uno(
    `SELECT MAX(temp_c) tmax, MIN(temp_c) tmin, MAX(hr_pct) hrmax, MIN(hr_pct) hrmin, AVG(viento_ms) u2,
            AVG(radiacion_wm2) rad, SUM(lluvia_mm) lluvia, COUNT(*) n
       FROM lecturas_estacion WHERE fecha >= ? AND fecha < ?`,
    [`${dia} 00:00:00`, `${fecha(new Date(parse(dia + " 00:00:00").getTime() + 86400000))} 00:00:00`]);
  if (!a || !a.n || a.n < 12) return null;
  const rs = (a.rad * 86400) / 1e6; // W/m² promedio -> MJ/m²·día
  const r = penmanMonteith({
    tmax: a.tmax, tmin: a.tmin, hrmax: a.hrmax, hrmin: a.hrmin, u2: a.u2, rs,
    z: finca.altitud_m, lat: finca.latitud, J: diaDelAnio(parse(dia + " 12:00:00")),
  });
  return { fecha: dia, tmax: a.tmax, tmin: a.tmin, hrmax: a.hrmax, hrmin: a.hrmin, viento_ms: a.u2, rs_mj: rs, lluvia_mm: a.lluvia || 0, eto_mm: r.eto };
}

/** Guarda (o actualiza) el resumen diario en clima_diario */
async function guardarDia(dia) {
  const d = await calcularDia(dia);
  if (!d) return null;
  const r2 = v => Math.round(v * 100) / 100;
  const existe = await db.uno("SELECT id FROM clima_diario WHERE fecha = ?", [dia]);
  const vals = [r2(d.tmax), r2(d.tmin), r2(d.hrmax), r2(d.hrmin), r2(d.viento_ms), r2(d.rs_mj), r2(d.lluvia_mm), r2(d.eto_mm)];
  if (existe)
    await db.ejecutar("UPDATE clima_diario SET tmax=?, tmin=?, hrmax=?, hrmin=?, viento_ms=?, rs_mj=?, lluvia_mm=?, eto_mm=? WHERE fecha=?", [...vals, dia]);
  else
    await db.ejecutar("INSERT INTO clima_diario (tmax, tmin, hrmax, hrmin, viento_ms, rs_mj, lluvia_mm, eto_mm, fecha) VALUES (?,?,?,?,?,?,?,?,?)", [...vals, dia]);
  return d;
}

/** ETo de referencia para decidir: último día completo registrado (FAO), o 2,78 mm por defecto */
async function etoReferencia() {
  const f = await db.uno("SELECT eto_mm, fecha FROM clima_diario WHERE fecha < ? ORDER BY fecha DESC LIMIT 1", [fecha(new Date())]);
  return f ? f.eto_mm : 2.78;
}

module.exports = { penmanMonteith, calcularDia, guardarDia, etoReferencia };

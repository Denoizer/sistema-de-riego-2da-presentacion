// Motor de decisión de riego por sector (punto 3.15.3 del marco práctico)
const db = require("../db");
const config = require("../config");
const { ahora, dentro, parse } = require("../util/tiempo");
const estado = require("./estado");
const { cargarSector, riegoEnCurso, iniciarRiego, motivoId } = require("./riego");
const { etoReferencia } = require("./eto");
const { obtenerConfig, obtenerReglas } = require("../servicios/config");
const { crearAlerta } = require("../servicios/alertas");
const { notificar, emitir } = require("../servicios/notificador");
const { enviarComando, nodoTanque } = require("./comandos");
const iaClima = require("../ia/clima");
const iaSector = require("../ia/sector");

const r3 = v => (v === null || v === undefined ? null : Math.round(v * 1000) / 1000);
const r2 = v => (v === null || v === undefined ? null : Math.round(v * 100) / 100);

async function registrarDecision(sector, decision, motivo, d, detalle) {
  await db.ejecutar(
    `INSERT INTO decisiones (sector_id, motivo_id, decision, humedad, umbral, eto_mm, etc_loc_mm, deficit_mm,
       lluvia_prevista_mm, prob_lluvia, humedad_pred_24h, detalle, fecha) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [sector.id, await motivoId(motivo), decision, r3(d.humedad), r3(d.umbral), r2(d.eto), r2(d.etcLoc), r2(sector.deficit_mm),
     r2(d.lluvia), r2(d.prob), r3(d.pred24), detalle ? detalle.slice(0, 300) : null, ahora()]);
}

/** Calcula la lámina, el volumen y el tiempo de riego del sector */
function calcularPlan(sector, humedad, etcLoc, cfg) {
  const zr = sector.prof_raiz_m * 1000;
  const lnSuelo = Math.max(0, (sector.theta_cc - humedad) * zr * sector.fraccion_humedecida);
  const ln = Math.min(Math.max(sector.deficit_mm, etcLoc, cfg.lamina_minima_mm || 1), Math.max(lnSuelo, cfg.lamina_minima_mm || 1));
  const lb = ln / sector.eficiencia;
  let litros = lb * sector.area_ha * 10000;
  const maxLitros = (sector.caudal_nominal_lh * (cfg.max_min_riego || 180)) / 60;
  litros = Math.min(litros, maxLitros);
  return { ln, lb, litros, minutos: (litros / sector.caudal_nominal_lh) * 60 };
}

/**
 * Evalúa un sector y decide: regar, no regar, posponer, esperar o suspender.
 * @param {number} id sector
 * @param {string} origen "horario" | "continuo" | "humedad_critica" | "manual"
 */
async function evaluarSector(id, origen = "continuo") {
  if (estado.enEvaluacion.has(id)) return null;
  estado.enEvaluacion.add(id);
  try {
    const cfg = await obtenerConfig();
    const reglas = await obtenerReglas();
    const sector = await cargarSector(id);
    if (!sector || !sector.activo) return null;
    if (!cfg.riego_automatico || sector.modo !== "automatico") return null;
    if (["regando", "falla", "mantenimiento"].includes(sector.estado)) return null;
    if (sector.estado === "pospuesto" && sector.pospuesto_hasta && parse(sector.pospuesto_hasta) > new Date()) return null;

    const st = estado.sectores.get(id);
    if (!st || st.humedad === null || st.humedad === undefined) return null;

    // Riego secuencial: un solo sector a la vez
    const otro = await riegoEnCurso();
    if (otro && otro.sector_id !== id) return null;

    const eto = await etoReferencia();
    const etcLoc = sector.kc * sector.factor_kc_ia * eto * sector.kr;
    const umbral = sector.umbral_humedad;
    const pron = await iaClima.resumen(24);
    const lluvia = pron ? pron.lluvia_mm : 0;
    const prob = pron ? pron.prob_max : 0;
    const pred24 = await iaSector.predecir(id, { humedad: st.humedad, etcLoc, temp: st.temp, lluvia, horas: await horasDesdeRiego(sector) });
    const modelo = await iaSector.modelo(id);
    const d = { humedad: st.humedad, umbral, eto, etcLoc, lluvia, prob, pred24 };

    // R: corte por lluvia en curso
    if (reglas.CORTE_LLUVIA && reglas.CORTE_LLUVIA.activa && estado.clima.lluvia_1h > reglas.CORTE_LLUVIA.valor) {
      await registrarDecision(sector, "suspender", "M-09", d, `Lluvia de ${estado.clima.lluvia_1h.toFixed(1)} mm en la última hora`);
      return "suspender";
    }

    let motivo = null, detalle = "";
    if (st.humedad < umbral && (!reglas.DISPARO_DEFICIT || reglas.DISPARO_DEFICIT.activa)) {
      motivo = "M-01"; detalle = `θ ${st.humedad.toFixed(3)} < umbral ${umbral.toFixed(3)}`;
    } else if (sector.deficit_mm >= Math.max(cfg.lamina_minima_mm || 1, etcLoc * 1.5) && st.humedad < sector.theta_cc - 0.02) {
      motivo = "M-02"; detalle = `déficit ${sector.deficit_mm.toFixed(2)} mm`;
    } else if (reglas.ANTICIPO_IA && reglas.ANTICIPO_IA.activa && modelo && modelo.fase === "adaptacion" &&
               pred24 !== null && pred24 < umbral - (reglas.ANTICIPO_IA.valor || 0) && lluvia < 1) {
      motivo = "M-03"; detalle = `IA prevé θ ${pred24.toFixed(3)} en 24 h`;
    }

    if (!motivo) {
      if (origen !== "humedad_critica") await registrarDecision(sector, "no_regar", "M-05", d, `θ ${st.humedad.toFixed(3)} ≥ umbral ${umbral.toFixed(3)}`);
      if (sector.estado !== "reposo") await db.ejecutar("UPDATE sectores SET estado = 'reposo', pospuesto_hasta = NULL WHERE id = ?", [id]);
      return "no_regar";
    }

    const plan = calcularPlan(sector, st.humedad, etcLoc, cfg);
    const pe = lluvia > 2 ? 0.75 * (lluvia - 2) : 0;
    const probMin = reglas.POSPONER_PRONOST && reglas.POSPONER_PRONOST.activa ? reglas.POSPONER_PRONOST.valor : 101;
    if (pe >= plan.ln && prob >= probMin) {
      const horas = (cfg.posponer_horas || 6) / (config.simulador ? config.acel : 1);
      await db.ejecutar("UPDATE sectores SET estado = 'pospuesto', pospuesto_hasta = ? WHERE id = ?", [dentro(horas * 60), id]);
      await registrarDecision(sector, "posponer", "M-06", d, `Lluvia efectiva prevista ${pe.toFixed(1)} mm ≥ lámina ${plan.ln.toFixed(1)} mm (prob. ${Math.round(prob)} %)`);
      await notificar(["agricultor", "admin"], `Riego pospuesto · ${sector.codigo}`,
        `${sector.nombre}: se prevén ${lluvia.toFixed(1)} mm de lluvia en 24 h (prob. ${Math.round(prob)} %). Se reevaluará en ${cfg.posponer_horas || 6} h.`, "info", { sector_id: id });
      emitir("sector", { id });
      return "posponer";
    }

    // Verificación del volumen del tanque
    const tq = await db.uno("SELECT * FROM tanques WHERE id = 1");
    const reservaPct = reglas.BLOQUEO_TANQUE && reglas.BLOQUEO_TANQUE.activa ? reglas.BLOQUEO_TANQUE.valor : 0;
    const disponible = tq.nivel_l - (tq.capacidad_l * reservaPct) / 100;
    if (disponible < plan.litros) {
      await db.ejecutar("UPDATE sectores SET estado = 'esperando_agua' WHERE id = ?", [id]);
      await registrarDecision(sector, "esperar", "M-07", d, `Requiere ${Math.round(plan.litros)} L; disponibles ${Math.round(Math.max(0, disponible))} L`);
      if (!tq.llenando) {
        await enviarComando(await nodoTanque(), "llenar");
        await db.ejecutar("UPDATE tanques SET llenando = 1, llenado_desde = ?, nivel_inicio_llenado = nivel_l WHERE id = 1", [ahora()]);
      }
      await crearAlerta("A-01", { mensaje: `Tanque con ${Math.round(tq.nivel_l).toLocaleString("es-BO")} L: no alcanza para regar ${sector.codigo} (${Math.round(plan.litros).toLocaleString("es-BO")} L). Llenado iniciado.` });
      emitir("sector", { id });
      return "esperar";
    }

    await registrarDecision(sector, "regar", motivo, d, `${detalle}; ${Math.round(plan.litros)} L, ${Math.round(plan.minutos)} min`);
    await iniciarRiego(sector, { tipo: "automatico", motivo, litros: plan.litros, lamina_mm: r2(plan.lb), max_min: cfg.max_min_riego || 180, detalleMotivo: detalle });
    return "regar";
  } finally {
    estado.enEvaluacion.delete(id);
  }
}

async function horasDesdeRiego(sector) {
  if (!sector.ultimo_riego) return 72;
  const h = (Date.now() - parse(sector.ultimo_riego).getTime()) / 3600000 * (config.simulador ? config.acel : 1);
  return Math.min(72, h);
}

async function evaluarTodos(origen) {
  const ids = await db.q("SELECT id FROM sectores WHERE activo = 1 ORDER BY id");
  const res = {};
  for (const { id } of ids) res[id] = await evaluarSector(id, origen);
  return res;
}

module.exports = { evaluarSector, evaluarTodos, calcularPlan, horasDesdeRiego };

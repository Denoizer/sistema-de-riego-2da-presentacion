// Simulador de campo: reemplaza a los nodos ESP32, la estación y el tanque
// cuando no hay hardware conectado (SIMULADOR=1 en .env).
const db = require("../db");
const config = require("../config");
const ingesta = require("./ingesta");
const { registrarEjecutorSimulado } = require("./comandos");

const TICK_S = 5; // cada 5 s reales se envían lecturas
const rnd = (a, b) => a + Math.random() * (b - a);
const gauss = (s = 1) => (Math.random() + Math.random() + Math.random() - 1.5) * s;

const planta = {
  sectores: new Map(), // id -> { theta, offs:[], temp, valvula, objetivo, litros, maxSeg, segAbierta, bateria, rssi }
  tanque: { nivel: 34600, capacidad: 50000, llenando: false },
  lluvia: { activa: false, intensidad: 0 },
  fallas: { valvula: new Set(), fuga: new Set(), nodo: new Set(), bateria: new Set(), sensor: new Set(), llenado: false },
  params: new Map(),
};

async function recargar() {
  const nodos = await db.q("SELECT id, tipo, sector_id FROM nodos");
  planta.nodoSector = new Map(nodos.filter(n => n.tipo === "sector").map(n => [n.id, n.sector_id]));
  planta.nodoTanque = (nodos.find(n => n.tipo === "tanque") || {}).id;
  const sectores = await db.q(
    `SELECT s.id, s.activo, s.area_ha, s.caudal_nominal_lh, s.eficiencia, s.fraccion_humedecida, s.umbral_humedad,
            c.kc_medio kc, c.kr, c.prof_raiz_m FROM sectores s JOIN cultivos c ON c.id = s.cultivo_id`);
  const inicial = { 1: 0.258, 2: 0.272, 3: 0.262, 4: 0.284 };
  for (const s of sectores) {
    planta.params.set(s.id, s);
    if (planta.sectores.has(s.id)) continue;
    const ult = await db.uno("SELECT humedad_prom FROM lecturas_sector WHERE sector_id = ? AND humedad_prom IS NOT NULL ORDER BY fecha DESC LIMIT 1", [s.id]);
    const n = await db.uno("SELECT bateria_v, rssi_dbm FROM nodos WHERE sector_id = ?", [s.id]);
    planta.sectores.set(s.id, {
      theta: ult ? ult.humedad_prom : inicial[s.id] || 0.27, offs: [gauss(0.004), gauss(0.004), gauss(0.004)],
      temp: 18, valvula: false, objetivo: 0, litros: 0, maxSeg: 0, segAbierta: 0,
      bateria: n && n.bateria_v ? n.bateria_v : 12.9, rssi: n && n.rssi_dbm ? n.rssi_dbm : -95,
    });
  }
}

async function iniciar() {
  await recargar();
  const tq = await db.uno("SELECT nivel_l, capacidad_l, llenando FROM tanques WHERE id = 1");
  Object.assign(planta.tanque, { nivel: tq.nivel_l, capacidad: tq.capacidad_l, llenando: !!tq.llenando });
  registrarEjecutorSimulado(ejecutarComando);
  setInterval(() => tick().catch(e => console.error("[simulador]", e.message)), TICK_S * 1000);
  console.log(`[simulador] activo · aceleración ×${config.acel} · escenario ${config.escenario}`);
}

/** Ejecuta en la "planta" un comando enviado a un nodo */
function ejecutarComando(cmd) {
  if (planta.nodoSector.has(cmd.nodo_id)) {
    const s = planta.sectores.get(planta.nodoSector.get(cmd.nodo_id));
    if (!s) return;
    if (cmd.accion === "abrir") Object.assign(s, { valvula: true, objetivo: cmd.litros || 0, litros: 0, maxSeg: (cmd.minutos || 180) * 60, segAbierta: 0 });
    if (cmd.accion === "cerrar") s.valvula = false;
  } else if (cmd.nodo_id === planta.nodoTanque) {
    if (cmd.accion === "llenar") planta.tanque.llenando = true;
    if (cmd.accion === "detener_llenado") planta.tanque.llenando = false;
  }
}

function clima(dtCampo) {
  const d = new Date();
  const h = d.getHours() + d.getMinutes() / 60;
  const sol = Math.max(0, Math.sin((Math.PI * (h - 6)) / 12));
  const prob = config.escenario === "lluvioso" ? 0.05 : 0.006; // probabilidad de inicio de lluvia por hora de campo
  if (!planta.lluvia.activa && Math.random() < prob * (dtCampo / 3600)) planta.lluvia = { activa: true, intensidad: rnd(1, config.escenario === "lluvioso" ? 12 : 5) };
  else if (planta.lluvia.activa && Math.random() < 0.35 * (dtCampo / 3600)) planta.lluvia = { activa: false, intensidad: 0 };
  const nubes = planta.lluvia.activa ? 0.35 : 1;
  return {
    temp_c: +(19 + 5 * Math.sin((Math.PI * (h - 9)) / 12) - (planta.lluvia.activa ? 2 : 0) + gauss(0.3)).toFixed(2),
    hr_pct: +Math.min(99, 76 - 16 * Math.sin((Math.PI * (h - 9)) / 12) + (planta.lluvia.activa ? 18 : 0) + gauss(1.5)).toFixed(1),
    presion_kpa: +(82.75 + gauss(0.08) - (planta.lluvia.activa ? 0.3 : 0)).toFixed(2),
    viento_ms: +Math.max(0.2, 1.5 + 0.8 * sol + gauss(0.3)).toFixed(2),
    radiacion_wm2: +Math.max(0, 560 * sol * nubes + gauss(15) * sol).toFixed(1),
    lluvia_mm: planta.lluvia.activa ? +((planta.lluvia.intensidad * dtCampo) / 3600).toFixed(3) : 0,
  };
}

async function tick() {
  const dt = TICK_S * config.acel; // segundos de campo transcurridos
  const c = clima(dt);
  await ingesta.lecturaEstacion(c);
  const etoDia = 2.8 * (1 + 0.04 * (c.temp_c - 19));
  let salidaTotal = 0;

  for (const [id, s] of planta.sectores) {
    const p = planta.params.get(id);
    if (!p || p.activo === 0) continue;
    const zrPw = p.prof_raiz_m * 1000 * p.fraccion_humedecida;
    // Secado por evapotranspiración del cultivo (ETc localizada)
    s.theta -= ((p.kc * p.kr * etoDia) / zrPw) * (dt / 86400);
    // Lluvia (moja toda la superficie)
    if (c.lluvia_mm > 0) s.theta += (c.lluvia_mm * 0.8) / (p.prof_raiz_m * 1000);
    // Riego
    let caudal = 0;
    if (s.valvula) {
      s.segAbierta += dt;
      const sinAgua = planta.tanque.nivel <= 0;
      caudal = planta.fallas.valvula.has(id) || sinAgua ? 0 : (p.caudal_nominal_lh / 60) * rnd(0.97, 1.03);
      const litros = (caudal * dt) / 60;
      s.litros += litros;
      salidaTotal += caudal;
      planta.tanque.nivel = Math.max(0, planta.tanque.nivel - litros);
      s.theta += ((litros / (p.area_ha * 10000)) * p.eficiencia) / zrPw;
      if ((s.objetivo && s.litros >= s.objetivo) || s.segAbierta >= s.maxSeg) {
        s.valvula = false;
        caudal = 0; // la válvula se cerró en este ciclo
        if (!planta.fallas.nodo.has(id)) await ingesta.eventoSector({ sector_id: id, tipo: "FIN_RIEGO", litros: Math.round(s.litros) });
      }
    } else if (planta.fallas.fuga.has(id)) {
      caudal = rnd(3, 4.5);
      planta.tanque.nivel = Math.max(0, planta.tanque.nivel - (caudal * dt) / 60);
      salidaTotal += caudal;
    }
    s.theta = Math.min(0.42, Math.max(0.1, s.theta));
    s.temp = +(c.temp_c - 2.5 + gauss(0.2)).toFixed(2);
    s.bateria = planta.fallas.bateria.has(id) ? +(11.5 + gauss(0.05)).toFixed(2) : +Math.min(13.2, Math.max(12.4, s.bateria + gauss(0.01))).toFixed(2);
    if (planta.fallas.nodo.has(id)) continue; // nodo caído: no transmite
    const h = s.offs.map(o => +(s.theta + o + gauss(0.002)).toFixed(3));
    if (planta.fallas.sensor.has(id)) h[1] = 0.61;
    await ingesta.lecturaSector({ sector_id: id, h, temp: s.temp, caudal: +caudal.toFixed(2), litros: Math.round(s.litros), bateria: s.bateria, rssi: s.rssi + Math.round(gauss(2)) });
  }

  // Tanque: entrada desde la vertiente (1,2 L/s)
  if (planta.tanque.llenando && !planta.fallas.llenado) planta.tanque.nivel = Math.min(planta.tanque.capacidad, planta.tanque.nivel + 1.2 * dt);
  await ingesta.lecturaTanque({ nivel_l: planta.tanque.nivel, caudal_salida: salidaTotal });
}

/** Inyección de fallas para pruebas (rol técnico/administrador) */
function inyectarFalla(tipo, sector_id) {
  if (tipo === "llenado") { planta.fallas.llenado = true; return; }
  if (!planta.fallas[tipo]) throw new Error("Tipo de falla no válido");
  planta.fallas[tipo].add(Number(sector_id));
}
function limpiarFallas() {
  for (const k of ["valvula", "fuga", "nodo", "bateria", "sensor"]) planta.fallas[k].clear();
  planta.fallas.llenado = false;
}
function fallasActivas() {
  const f = {};
  for (const k of ["valvula", "fuga", "nodo", "bateria", "sensor"]) f[k] = [...planta.fallas[k]];
  f.llenado = planta.fallas.llenado;
  return f;
}
/** Permite al técnico simular la lluvia o secar un sector para pruebas */
function forzarLluvia(mmHora) { planta.lluvia = mmHora > 0 ? { activa: true, intensidad: mmHora } : { activa: false, intensidad: 0 }; }

module.exports = { iniciar, recargar, inyectarFalla, limpiarFallas, fallasActivas, forzarLluvia, planta };

// Ingesta de datos de campo (nodos reales vía /api/iot o el simulador)
const db = require("../db");
const config = require("../config");
const { ahora, parse } = require("../util/tiempo");
const estado = require("./estado");
const { crearAlerta, resolverAutomaticamente } = require("../servicios/alertas");
const { emitir } = require("../servicios/notificador");
const { obtenerConfig, obtenerReglas } = require("../servicios/config");
const { riegoEnCurso, finalizarRiego } = require("./riego");
const { enviarComando, nodoDeSector, nodoTanque } = require("./comandos");

const r3 = v => Math.round(v * 1000) / 1000;
const seg = s => s / (config.simulador ? config.acel : 1); // segundos de campo -> segundos reales

let decision = null; // se resuelve tarde para evitar dependencia circular
const motor = () => decision || (decision = require("./decision"));

function debePersistir(clave, cadaSegReales) {
  if (!config.simulador) return true;
  const ult = estado.ultimaPersistencia.get(clave) || 0;
  if (Date.now() - ult >= cadaSegReales * 1000) { estado.ultimaPersistencia.set(clave, Date.now()); return true; }
  return false;
}

/** Valida los sensores de humedad: fuera de rango o muy distintos de la mediana -> falla */
async function validarSensores(sector_id, nodo_id, h) {
  const sensores = await db.q("SELECT id, posicion, rango_min, rango_max, estado FROM sensores WHERE nodo_id = ? AND tipo = 'humedad' ORDER BY posicion", [nodo_id]);
  const validos = h.filter(v => v !== null && v !== undefined);
  const med = [...validos].sort((a, b) => a - b)[Math.floor(validos.length / 2)];
  const buenos = [];
  for (let i = 0; i < sensores.length; i++) {
    const s = sensores[i], v = h[i];
    const malo = v === null || v === undefined || v < s.rango_min || v > s.rango_max || Math.abs(v - med) > 0.10;
    if (malo && s.estado === "ok") {
      await db.ejecutar("UPDATE sensores SET estado = 'falla', ultimo_valor = ? WHERE id = ?", [v ?? null, s.id]);
      const sec = await db.uno("SELECT codigo FROM sectores WHERE id = ?", [sector_id]);
      await crearAlerta("A-06", { sector_id, nodo_id, mensaje: `Sensor de humedad ${s.posicion} del ${sec.codigo} con lectura anómala (${v === null || v === undefined ? "sin dato" : v.toFixed(3)} m³/m³). Se excluye del promedio.` });
    } else if (!malo && s.estado === "falla") {
      await db.ejecutar("UPDATE sensores SET estado = 'ok' WHERE id = ?", [s.id]);
      const quedan = await db.uno("SELECT COUNT(*) n FROM sensores WHERE nodo_id = ? AND estado = 'falla'", [nodo_id]);
      if (!quedan.n) await resolverAutomaticamente("A-06", { sector_id }, "El sensor volvió a reportar valores válidos");
    }
    if (!malo) buenos.push(v);
  }
  return buenos.length ? buenos.reduce((a, b) => a + b, 0) / buenos.length : null;
}

/**
 * Lectura de un nodo de sector.
 * @param {object} l { sector_id, h:[h1,h2,h3], temp, caudal (L/min), litros (acumulados del riego), bateria, rssi }
 */
async function lecturaSector(l) {
  const cfg = await obtenerConfig();
  const reglas = await obtenerReglas();
  const nodo_id = await nodoDeSector(l.sector_id);
  estado.nodosVistos.set(nodo_id, Date.now());
  const humedad = await validarSensores(l.sector_id, nodo_id, l.h || []);
  const st = estado.sectores.get(l.sector_id) || {};
  Object.assign(st, { humedad, h: l.h, temp: l.temp, caudal: l.caudal || 0, litros: l.litros || 0, bateria: l.bateria, rssi: l.rssi, ultimaVez: Date.now() });
  estado.sectores.set(l.sector_id, st);

  if (debePersistir("sector" + l.sector_id, 60)) {
    const [h1, h2, h3] = (l.h || []).map(v => (v === null || v === undefined ? null : r3(v)));
    await db.ejecutar(
      "INSERT INTO lecturas_sector (sector_id, humedad_prom, humedad_1, humedad_2, humedad_3, temp_suelo, caudal_lmin, bateria_v, fecha) VALUES (?,?,?,?,?,?,?,?,?)",
      [l.sector_id, humedad === null ? null : r3(humedad), h1, h2, h3, l.temp, Math.round((l.caudal || 0) * 10) / 10, l.bateria, ahora()]);
    await db.ejecutar("UPDATE nodos SET bateria_v = ?, rssi_dbm = ?, en_linea = 1, ultima_conexion = ? WHERE id = ?", [l.bateria, l.rssi ?? null, ahora(), nodo_id]);
    const sensoresH = await db.q("SELECT id FROM sensores WHERE nodo_id = ? AND tipo = 'humedad' ORDER BY posicion", [nodo_id]);
    for (let i = 0; i < sensoresH.length; i++) if (l.h && l.h[i] !== undefined && l.h[i] !== null)
      await db.ejecutar("UPDATE sensores SET ultimo_valor = ? WHERE id = ?", [r3(l.h[i]), sensoresH[i].id]);
    await db.ejecutar("UPDATE sensores SET ultimo_valor = ? WHERE nodo_id = ? AND tipo = 'temp_suelo'", [l.temp, nodo_id]);
    await db.ejecutar("UPDATE sensores SET ultimo_valor = ? WHERE nodo_id = ? AND tipo = 'caudal'", [l.caudal || 0, nodo_id]);
  }

  // Batería baja (A-07)
  if (l.bateria !== undefined && l.bateria < cfg.bateria_min_v) {
    const sec = await db.uno("SELECT codigo FROM sectores WHERE id = ?", [l.sector_id]);
    await crearAlerta("A-07", { sector_id: l.sector_id, nodo_id, mensaje: `Batería baja en el nodo del ${sec.codigo}: ${l.bateria.toFixed(2)} V (mínimo ${cfg.bateria_min_v} V).` });
  } else if (l.bateria !== undefined && l.bateria > cfg.bateria_min_v + 0.3) {
    await resolverAutomaticamente("A-07", { nodo_id }, "Tensión de batería normalizada");
  }

  const riego = await riegoEnCurso(l.sector_id);
  if (riego) {
    if (l.litros > riego.litros_reales) await db.ejecutar("UPDATE riegos SET litros_reales = ? WHERE id = ?", [Math.round(l.litros), riego.id]);
    // Válvula abierta sin caudal durante 60 s de campo -> falla (A-03)
    if ((l.caudal || 0) < 0.5 && st.inicioValvula && Date.now() - st.inicioValvula > seg(60) * 1000) await fallaSinCaudal(l.sector_id, nodo_id);
  } else {
    // Caudal con válvula cerrada -> posible fuga (A-04)
    const umbralFuga = reglas.DETECCION_FUGA && reglas.DETECCION_FUGA.activa ? reglas.DETECCION_FUGA.valor : Infinity;
    const recienCerrada = st.finRiego && Date.now() - st.finRiego < seg(120) * 1000; // caudal residual tras cerrar
    if ((l.caudal || 0) > umbralFuga && !recienCerrada) {
      const sec = await db.uno("SELECT codigo FROM sectores WHERE id = ?", [l.sector_id]);
      await crearAlerta("A-04", { sector_id: l.sector_id, nodo_id, mensaje: `${sec.codigo}: se detecta caudal de ${l.caudal.toFixed(1)} L/min con la válvula cerrada. Revise laterales y válvula.` });
    }
  }

  emitir("lectura", { tipo: "sector", sector_id: l.sector_id, humedad, caudal: l.caudal || 0, litros: l.litros || 0 });

  // Humedad crítica -> evaluación inmediata
  if (humedad !== null) {
    const s = await db.uno("SELECT estado, modo, umbral_humedad FROM sectores WHERE id = ?", [l.sector_id]);
    if (s.modo === "automatico" && ["reposo", "evaluando"].includes(s.estado) && humedad < s.umbral_humedad)
      motor().evaluarSector(l.sector_id, "humedad_critica").catch(e => console.error("[motor]", e.message));
  }
}

async function fallaSinCaudal(sector_id, nodo_id) {
  const st = estado.sectores.get(sector_id);
  if (st) st.inicioValvula = null;
  await enviarComando(nodo_id, "cerrar");
  await finalizarRiego(sector_id, "fallido", st ? st.litros : 0);
  const sec = await db.uno("SELECT codigo, nombre FROM sectores WHERE id = ?", [sector_id]);
  await db.ejecutar("INSERT INTO decisiones (sector_id, motivo_id, decision, detalle, fecha) VALUES (?, (SELECT id FROM motivos WHERE codigo = 'M-08'), 'suspender', ?, ?)",
    [sector_id, "Válvula abierta sin caudal durante 60 s", ahora()]);
  await crearAlerta("A-03", { sector_id, nodo_id, mensaje: `${sec.nombre}: válvula abierta sin caudal durante 60 s. Se cerró por seguridad. Revise válvula, filtro y tubería.` });
}

/** Evento enviado por el nodo (p. ej. FIN_RIEGO cuando completa el volumen) */
async function eventoSector({ sector_id, tipo, litros }) {
  const nodo_id = await nodoDeSector(sector_id);
  estado.nodosVistos.set(nodo_id, Date.now());
  if (tipo === "FIN_RIEGO") {
    const st = estado.sectores.get(sector_id);
    if (st) { st.litros = litros; st.caudal = 0; }
    await finalizarRiego(sector_id, "completado", litros);
    setTimeout(() => motor().evaluarTodos("continuo").catch(() => {}), 1500);
  } else if (tipo === "SIN_CAUDAL") {
    await fallaSinCaudal(sector_id, nodo_id);
  }
}

/** Lectura del nodo del tanque */
async function lecturaTanque({ nivel_l, caudal_salida = 0 }) {
  const nodo_id = await nodoTanque();
  estado.nodosVistos.set(nodo_id, Date.now());
  const tq = await db.uno("SELECT * FROM tanques WHERE id = 1");
  const reglas = await obtenerReglas();
  const pct = (nivel_l / tq.capacidad_l) * 100;
  Object.assign(estado.tanque, { nivel_l, porcentaje: pct, llenando: !!tq.llenando, caudal_salida });
  await db.ejecutar("UPDATE tanques SET nivel_l = ?, actualizado_en = ? WHERE id = 1", [Math.round(nivel_l * 10) / 10, ahora()]);
  if (debePersistir("tanque", 60))
    await db.ejecutar("INSERT INTO lecturas_tanque (tanque_id, nivel_l, porcentaje, caudal_salida_lmin, llenando, fecha) VALUES (1,?,?,?,?,?)",
      [Math.round(nivel_l), Math.round(pct * 100) / 100, Math.round(caudal_salida * 10) / 10, tq.llenando, ahora()]);
  if (debePersistir("tanque_nodo", 60))
    await db.ejecutar("UPDATE nodos SET en_linea = 1, ultima_conexion = ? WHERE id = ?", [ahora(), nodo_id]);

  const auto = !reglas.LLENADO_AUTO || reglas.LLENADO_AUTO.activa;
  const minPct = reglas.LLENADO_AUTO && reglas.LLENADO_AUTO.valor ? reglas.LLENADO_AUTO.valor : tq.umbral_min_pct;
  if (!tq.llenando && auto && pct < minPct) {
    await enviarComando(nodo_id, "llenar");
    await db.ejecutar("UPDATE tanques SET llenando = 1, llenado_desde = ?, nivel_inicio_llenado = ? WHERE id = 1", [ahora(), nivel_l]);
    await crearAlerta("A-01", { mensaje: `Tanque con ${Math.round(nivel_l).toLocaleString("es-BO")} L (${pct.toFixed(1)} %), bajo el mínimo de ${minPct} %. Se abrió la válvula de llenado.` });
  } else if (tq.llenando && pct >= tq.umbral_max_pct) {
    await enviarComando(nodo_id, "detener_llenado");
    await db.ejecutar("UPDATE tanques SET llenando = 0, llenado_desde = NULL WHERE id = 1");
    await resolverAutomaticamente("A-01", {}, `Tanque lleno (${pct.toFixed(1)} %)`);
    await resolverAutomaticamente("A-02", {}, "El llenado se completó");
    const { notificar } = require("../servicios/notificador");
    await notificar(["agricultor", "admin"], "Tanque lleno", `El tanque alcanzó ${Math.round(nivel_l).toLocaleString("es-BO")} L (${pct.toFixed(1)} %). Llenado detenido.`, "info");
    // Sectores que esperaban agua vuelven a evaluarse
    const esperando = await db.q("SELECT id FROM sectores WHERE estado = 'esperando_agua'");
    for (const s of esperando) {
      await db.ejecutar("UPDATE sectores SET estado = 'reposo' WHERE id = ?", [s.id]);
      motor().evaluarSector(s.id, "continuo").catch(() => {});
    }
  } else if (tq.llenando && tq.llenado_desde) {
    // Falla en el llenado: 30 min de campo sin subir el nivel (A-02)
    const transcurrido = (Date.now() - parse(tq.llenado_desde).getTime()) / 1000;
    if (transcurrido > seg(30 * 60) && nivel_l <= (tq.nivel_inicio_llenado || 0) + 50)
      await crearAlerta("A-02", { nodo_id, mensaje: `La válvula de llenado está abierta hace 30 min y el nivel no sube (${Math.round(nivel_l)} L). Revise la toma de la vertiente.` });
  }
  emitir("lectura", { tipo: "tanque", nivel_l, porcentaje: pct, llenando: !!tq.llenando, caudal_salida });
}

/** Lectura de la estación meteorológica de la unidad central */
async function lecturaEstacion(c) {
  const nodo = await db.uno("SELECT id FROM nodos WHERE tipo = 'central' LIMIT 1");
  if (nodo) estado.nodosVistos.set(nodo.id, Date.now());
  const ahoraMs = Date.now();
  estado.lluviaReciente.push({ t: ahoraMs, mm: c.lluvia_mm || 0 });
  estado.lluviaReciente = estado.lluviaReciente.filter(x => ahoraMs - x.t < seg(3600) * 1000);
  const lluvia1h = estado.lluviaReciente.reduce((a, x) => a + x.mm, 0);
  Object.assign(estado.clima, { ...c, lluvia_1h: lluvia1h, fecha: ahora() });

  // Lluvia efectiva reduce el déficit de los sectores
  if (c.lluvia_mm > 0) {
    const sectores = await db.q("SELECT id, deficit_mm FROM sectores");
    for (const s of sectores)
      await db.ejecutar("UPDATE sectores SET deficit_mm = ? WHERE id = ?", [Math.max(0, Math.round((s.deficit_mm - c.lluvia_mm * 0.75) * 100) / 100), s.id]);
  }
  if (debePersistir("estacion", 60)) {
    const acum = config.simulador ? estado.lluviaAcumulada || 0 : c.lluvia_mm || 0;
    estado.lluviaAcumulada = 0;
    await db.ejecutar(
      "INSERT INTO lecturas_estacion (temp_c, hr_pct, presion_kpa, viento_ms, radiacion_wm2, lluvia_mm, fecha) VALUES (?,?,?,?,?,?,?)",
      [c.temp_c, c.hr_pct, c.presion_kpa, c.viento_ms, c.radiacion_wm2, Math.round((acum + (config.simulador ? c.lluvia_mm || 0 : 0)) * 100) / 100, ahora()]);
    if (nodo) await db.ejecutar("UPDATE nodos SET en_linea = 1, ultima_conexion = ? WHERE id = ?", [ahora(), nodo.id]);
  } else if (config.simulador) {
    estado.lluviaAcumulada = (estado.lluviaAcumulada || 0) + (c.lluvia_mm || 0);
  }
  emitir("lectura", { tipo: "clima", ...estado.clima });
}

module.exports = { lecturaSector, eventoSector, lecturaTanque, lecturaEstacion };

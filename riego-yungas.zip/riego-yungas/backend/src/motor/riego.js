// Inicio, seguimiento y cierre de eventos de riego
const db = require("../db");
const { ahora, parse } = require("../util/tiempo");
const { enviarComando, nodoDeSector } = require("./comandos");
const { notificar, emitir } = require("../servicios/notificador");
const { crearAlerta } = require("../servicios/alertas");
const estado = require("./estado");

/** Sector con parámetros de cultivo y suelo */
async function cargarSector(id) {
  return db.uno(
    `SELECT s.*, c.nombre AS cultivo, c.kc_medio AS kc, c.kr, c.prof_raiz_m, c.p_agotamiento,
            su.theta_cc, su.theta_pmp
       FROM sectores s JOIN cultivos c ON c.id = s.cultivo_id JOIN suelos su ON su.id = s.suelo_id
      WHERE s.id = ?`, [id]);
}

async function riegoEnCurso(sector_id = null) {
  return sector_id === null
    ? db.uno("SELECT * FROM riegos WHERE estado = 'en_curso' ORDER BY inicio LIMIT 1")
    : db.uno("SELECT * FROM riegos WHERE estado = 'en_curso' AND sector_id = ? LIMIT 1", [sector_id]);
}

const motivoId = async codigo => (await db.uno("SELECT id FROM motivos WHERE codigo = ?", [codigo])).id;

/**
 * Inicia un riego: registra el evento, abre la válvula y notifica el motivo.
 */
async function iniciarRiego(sector, { tipo, motivo, litros, lamina_mm, max_min, usuario_id = null, detalleMotivo = "", programado_id = null }) {
  const minutosPlan = (litros / sector.caudal_nominal_lh) * 60;
  const r = await db.ejecutar(
    `INSERT INTO riegos (sector_id, usuario_id, tipo, programado_id, motivo_id, lamina_mm, litros_plan, duracion_plan_min, inicio, estado)
     VALUES (?,?,?,?,?,?,?,?,?, 'en_curso')`,
    [sector.id, usuario_id, tipo, programado_id, await motivoId(motivo), lamina_mm, Math.round(litros), Math.round(minutosPlan * 10) / 10, ahora()]);
  await db.ejecutar("UPDATE sectores SET estado = 'regando', pospuesto_hasta = NULL WHERE id = ?", [sector.id]);
  const st = estado.sectores.get(sector.id) || {};
  st.inicioValvula = Date.now();
  estado.sectores.set(sector.id, st);
  const nodo = await nodoDeSector(sector.id);
  await enviarComando(nodo, "abrir", { litros: Math.round(litros), minutos: Math.ceil(Math.min(minutosPlan * 1.3, max_min)), usuario_id });
  const m = await db.uno("SELECT descripcion FROM motivos WHERE codigo = ?", [motivo]);
  await notificar(["agricultor", "admin"], `Riego iniciado · ${sector.codigo}`,
    `${sector.nombre}: ${Math.round(litros).toLocaleString("es-BO")} L en ≈ ${Math.round(minutosPlan)} min. Motivo ${motivo}: ${m.descripcion}${detalleMotivo ? " (" + detalleMotivo + ")" : ""}.`, "info", { sector_id: sector.id });
  emitir("sector", { id: sector.id });
  return r.insertId;
}

/**
 * Cierra el riego en curso de un sector.
 * @param {"completado"|"cancelado"|"fallido"} final
 */
async function finalizarRiego(sector_id, final, litrosReales = null) {
  const riego = await riegoEnCurso(sector_id);
  if (!riego) return null;
  const sector = await cargarSector(sector_id);
  const litros = litrosReales !== null ? litrosReales : riego.litros_reales;
  const minutos = (Date.now() - parse(riego.inicio).getTime()) / 60000;
  await db.ejecutar(
    "UPDATE riegos SET estado = ?, fin = ?, litros_reales = ?, caudal_prom_lmin = ? WHERE id = ?",
    [final, ahora(), Math.round(litros), minutos > 0 ? Math.round((litros / Math.max(minutos, 0.01)) * 10) / 10 : null, riego.id]);
  const laminaAplicada = (litros / (sector.area_ha * 10000)) * sector.eficiencia;
  await db.ejecutar(
    "UPDATE sectores SET estado = ?, deficit_mm = ?, ultimo_riego = ? WHERE id = ?",
    [final === "fallido" ? "falla" : sector.modo === "mantenimiento" ? "mantenimiento" : "reposo",
     Math.round(Math.max(0, sector.deficit_mm - laminaAplicada) * 100) / 100, ahora(), sector_id]);
  const st = estado.sectores.get(sector_id);
  if (st) { st.inicioValvula = null; st.finRiego = Date.now(); }
  if (final === "completado") {
    await notificar(["agricultor", "admin"], `Riego finalizado · ${sector.codigo}`,
      `${sector.nombre}: se aplicaron ${Math.round(litros).toLocaleString("es-BO")} L (${laminaAplicada.toFixed(2)} mm efectivos).`, "info", { sector_id });
    if (litros > riego.litros_plan * 1.2)
      await crearAlerta("A-09", { sector_id, mensaje: `${sector.codigo}: consumo de ${Math.round(litros)} L supera en más de 20 % lo planificado (${Math.round(riego.litros_plan)} L).` });
  } else if (final === "cancelado") {
    await notificar(["agricultor", "admin"], `Riego detenido · ${sector.codigo}`, `${sector.nombre}: riego detenido con ${Math.round(litros).toLocaleString("es-BO")} L aplicados.`, "media", { sector_id });
  }
  emitir("sector", { id: sector_id });
  return riego.id;
}

/** Detiene manualmente un riego (cierra la válvula) */
async function detenerRiego(sector_id, usuario_id) {
  const nodo = await nodoDeSector(sector_id);
  await enviarComando(nodo, "cerrar", { usuario_id });
  const st = estado.sectores.get(sector_id);
  return finalizarRiego(sector_id, "cancelado", st && st.litros ? st.litros : null);
}

module.exports = { cargarSector, riegoEnCurso, iniciarRiego, finalizarRiego, detenerRiego, motivoId };

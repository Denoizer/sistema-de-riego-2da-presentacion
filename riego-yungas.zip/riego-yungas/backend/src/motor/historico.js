// Genera 14 días de histórico la primera vez que se inicia el sistema, para que
// los paneles, reportes y modelos de IA tengan datos desde el primer momento.
const db = require("../db");
const { fmt, fecha } = require("../util/tiempo");
const { guardarDia } = require("./eto");
const iaSector = require("../ia/sector");

const DIAS = 14, PASO_MIN = 10;

let semilla = 42;
const azar = () => { semilla = (semilla * 16807) % 2147483647; return (semilla - 1) / 2147483646; };
const gauss = (s = 1) => (azar() + azar() + azar() - 1.5) * s;

async function insertarLotes(tabla, columnas, filas, tam = 400) {
  for (let i = 0; i < filas.length; i += tam) {
    const lote = filas.slice(i, i + tam);
    await db.ejecutar(`INSERT INTO ${tabla} (${columnas.join(",")}) VALUES ` + lote.map(() => `(${columnas.map(() => "?").join(",")})`).join(","), lote.flat());
  }
}

async function generarSiFalta() {
  const hay = await db.uno("SELECT COUNT(*) n FROM lecturas_estacion");
  if (hay.n > 0) return false;
  console.log("[histórico] generando 14 días de datos de ejemplo…");

  const sectores = await db.q(
    `SELECT s.*, c.kc_medio kc, c.kr, c.prof_raiz_m, su.theta_cc FROM sectores s
       JOIN cultivos c ON c.id = s.cultivo_id JOIN suelos su ON su.id = s.suelo_id ORDER BY s.id`);
  const motivos = Object.fromEntries((await db.q("SELECT id, codigo FROM motivos")).map(m => [m.codigo, m.id]));
  const tq = await db.uno("SELECT * FROM tanques WHERE id = 1");

  const fin = new Date(); fin.setSeconds(0, 0); fin.setMinutes(fin.getMinutes() - (fin.getMinutes() % PASO_MIN));
  const inicio = new Date(fin.getTime() - DIAS * 86400000);
  const theta = { 1: 0.272, 2: 0.268, 3: 0.262, 4: 0.281 };
  const offs = Object.fromEntries(sectores.map(s => [s.id, [gauss(0.004), gauss(0.004), gauss(0.004)]]));
  let tanque = 41000, llenando = false, lluvia = 0;
  const est = [], lsec = [], ltq = [], riegos = [], decisiones = [], muestras = [];
  const serieTheta = new Map(sectores.map(s => [s.id, []]));
  const eventosLluvia = [3.3, 8.7]; // días con lluvia (aprox.)

  for (let t = new Date(inicio); t <= fin; t = new Date(t.getTime() + PASO_MIN * 60000)) {
    const dia = (t - inicio) / 86400000;
    const h = t.getHours() + t.getMinutes() / 60;
    const sol = Math.max(0, Math.sin((Math.PI * (h - 6)) / 12));
    lluvia = eventosLluvia.some(d => dia >= d && dia < d + 0.12) ? 3 + azar() * 4 : 0;
    const temp = 19 + 5 * Math.sin((Math.PI * (h - 9)) / 12) + Math.sin(dia / 2) * 0.8 - (lluvia ? 2 : 0) + gauss(0.3);
    const hr = Math.min(99, 76 - 16 * Math.sin((Math.PI * (h - 9)) / 12) + (lluvia ? 18 : 0) + gauss(1.5));
    const rad = Math.max(0, 560 * sol * (lluvia ? 0.35 : 1) * (0.9 + azar() * 0.15));
    const lluviaPaso = (lluvia * PASO_MIN) / 60;
    est.push([+temp.toFixed(2), +hr.toFixed(1), +(82.75 + gauss(0.08)).toFixed(2), +Math.max(0.2, 1.5 + 0.8 * sol + gauss(0.3)).toFixed(2), +rad.toFixed(1), +lluviaPaso.toFixed(2), fmt(t)]);

    let salida = 0;
    for (const s of sectores) {
      const zrPw = s.prof_raiz_m * 1000 * s.fraccion_humedecida;
      theta[s.id] -= ((s.kc * s.kr * 2.8 * (1 + 0.04 * (temp - 19))) / zrPw) * (PASO_MIN / 1440);
      theta[s.id] += (lluviaPaso * 0.8) / (s.prof_raiz_m * 1000);
      // Evaluaciones de las 05:00 y 17:00
      if ((t.getHours() === 5 || t.getHours() === 17) && t.getMinutes() === 0) {
        const etcLoc = s.kc * s.kr * 2.78;

        const litros = Math.round(((etcLoc / s.eficiencia) * s.area_ha * 10000));
        if (theta[s.id] < s.umbral_humedad && !lluvia && tanque - litros < tq.capacidad_l * 0.1) {
          decisiones.push([s.id, motivos["M-07"], "esperar", +theta[s.id].toFixed(3), s.umbral_humedad, 2.78, +etcLoc.toFixed(2), `Requiere ${litros} L; tanque insuficiente`, fmt(t)]);
          llenando = true;
        } else if (theta[s.id] < s.umbral_humedad && !lluvia) {
          const minutos = (litros / s.caudal_nominal_lh) * 60;
          const fin = new Date(t.getTime() + minutos * 60000 * (0.98 + azar() * 0.04));
          const reales = Math.round(litros * (0.98 + azar() * 0.04));
          riegos.push([s.id, null, "automatico", motivos["M-01"], +(etcLoc / s.eficiencia).toFixed(2), litros, reales, +(reales / minutos).toFixed(1), +minutos.toFixed(1), fmt(t), fmt(fin), "completado"]);
          decisiones.push([s.id, motivos["M-01"], "regar", +theta[s.id].toFixed(3), s.umbral_humedad, 2.78, +etcLoc.toFixed(2), `θ bajo umbral; ${litros} L`, fmt(t)]);
          theta[s.id] += ((reales / (s.area_ha * 10000)) * s.eficiencia) / zrPw;
          tanque -= reales;
          salida += reales;
        } else {
          decisiones.push([s.id, motivos[lluvia ? "M-09" : "M-05"], lluvia ? "suspender" : "no_regar", +theta[s.id].toFixed(3), s.umbral_humedad, 2.78, +etcLoc.toFixed(2), lluvia ? "Lluvia en curso" : "Humedad suficiente", fmt(t)]);
        }
      }
      const hs = offs[s.id].map(o => +(theta[s.id] + o + gauss(0.002)).toFixed(3));
      lsec.push([s.id, +(hs.reduce((a, b) => a + b) / 3).toFixed(3), ...hs, +(temp - 2.5 + gauss(0.2)).toFixed(2), 0, +(12.9 + gauss(0.05)).toFixed(2), fmt(t)]);
      if (t.getMinutes() === 0 && t.getHours() % 3 === 0) serieTheta.get(s.id).push({ t, theta: theta[s.id], temp: temp - 2.5 });
    }
    // Tanque: llenado desde la vertiente
    const pct = (tanque / tq.capacidad_l) * 100;
    if (!llenando && pct < 80) llenando = true; // la vertiente repone el agua del día
    if (llenando) tanque = Math.min(tq.capacidad_l, tanque + 1.2 * PASO_MIN * 60);
    if (llenando && (tanque / tq.capacidad_l) * 100 >= tq.umbral_max_pct) llenando = false;
    if (t.getMinutes() % 30 === 0) ltq.push([1, Math.round(tanque), +((tanque / tq.capacidad_l) * 100).toFixed(2), salida ? +(salida / PASO_MIN).toFixed(1) : 0, llenando ? 1 : 0, fmt(t)]);
  }

  // Muestras de aprendizaje (cada 3 h, objetivo 24 h después)
  for (const s of sectores) {
    const serie = serieTheta.get(s.id);
    for (let i = 0; i + 8 < serie.length; i++) {
      const a = serie[i], b = serie[i + 8];
      const ult = riegos.filter(r => r[0] === s.id && r[9] <= fmt(a.t)).pop();
      const horas = ult ? (a.t - new Date(ult[9].replace(" ", "T"))) / 3600000 : 72;
      muestras.push([s.id, +a.theta.toFixed(3), +(s.kc * s.kr * 2.78).toFixed(2), +a.temp.toFixed(2), 0, +Math.min(horas, 999).toFixed(1), +b.theta.toFixed(3), fmt(a.t), fmt(b.t)]);
    }
  }

  await insertarLotes("lecturas_estacion", ["temp_c", "hr_pct", "presion_kpa", "viento_ms", "radiacion_wm2", "lluvia_mm", "fecha"], est);
  await insertarLotes("lecturas_sector", ["sector_id", "humedad_prom", "humedad_1", "humedad_2", "humedad_3", "temp_suelo", "caudal_lmin", "bateria_v", "fecha"], lsec);
  await insertarLotes("lecturas_tanque", ["tanque_id", "nivel_l", "porcentaje", "caudal_salida_lmin", "llenando", "fecha"], ltq);
  await insertarLotes("riegos", ["sector_id", "usuario_id", "tipo", "motivo_id", "lamina_mm", "litros_plan", "litros_reales", "caudal_prom_lmin", "duracion_plan_min", "inicio", "fin", "estado"], riegos);
  await insertarLotes("decisiones", ["sector_id", "motivo_id", "decision", "humedad", "umbral", "eto_mm", "etc_loc_mm", "detalle", "fecha"], decisiones);
  await insertarLotes("muestras_ia", ["sector_id", "humedad", "etc_loc_mm", "temp_suelo", "lluvia_prev_mm", "horas_desde_riego", "humedad_objetivo", "fecha", "fecha_objetivo"], muestras);

  for (let d = 0; d <= DIAS; d++) await guardarDia(fecha(new Date(inicio.getTime() + d * 86400000)));

  // Estado final coherente con el histórico
  await db.ejecutar("UPDATE tanques SET nivel_l = ?, llenando = ?, actualizado_en = ? WHERE id = 1", [Math.round(tanque), llenando ? 1 : 0, fmt(fin)]);
  for (const s of sectores) {
    const ult = riegos.filter(r => r[0] === s.id).pop();
    await db.ejecutar("UPDATE sectores SET ultimo_riego = ?, deficit_mm = ? WHERE id = ?", [ult ? ult[10] : null, 0.8, s.id]);
  }
  for (const s of sectores) {
    await iaSector.reentrenar(s.id);
    const n = muestras.filter(m => m[0] === s.id).length;
    await db.ejecutar("UPDATE modelos_ia SET n_muestras = ?, fase = ? WHERE tipo = 'sector' AND sector_id = ?", [n, n >= 120 ? "adaptacion" : n >= 30 ? "recomendacion" : "observacion", s.id]);
  }

  // Alertas y mantenimientos históricos (ya atendidos)
  const d = n => fmt(new Date(fin.getTime() - n * 86400000));
  await insertarLotes("alertas", ["tipo_alerta_id", "sector_id", "nodo_id", "mensaje", "atendida", "atendida_por", "atendida_en", "nota_atencion", "fecha"], [
    [7, 2, 2, "Batería baja en el nodo del S2: 11,62 V (mínimo 11,8 V).", 1, 3, d(9.8), "Se limpió el panel solar y se ajustó el regulador.", d(10)],
    [1, null, 5, "Tanque con 11 820 L (23,6 %), bajo el mínimo de 25 %. Se abrió la válvula de llenado.", 1, 2, d(6.9), "Llenado completado automáticamente.", d(7)],
    [6, 3, 3, "Sensor de humedad H2 del S3 con lectura anómala (0,612 m³/m³). Se excluye del promedio.", 1, 3, d(3.7), "Sensor reinstalado y recalibrado.", d(4)],
  ]);
  await insertarLotes("mantenimientos", ["nodo_id", "sector_id", "tecnico_id", "tipo", "descripcion", "fecha"], [
    [null, null, 3, "preventivo", "Limpieza de filtros de los 4 sectores y revisión de goteros.", d(12)],
    [2, 2, 3, "correctivo", "Limpieza del panel solar del nodo S2 y ajuste del regulador de carga.", d(9.8)],
    [3, 3, 3, "calibracion", "Recalibración del sensor H2 del S3 (seco 3195 / saturado 1385).", d(3.7)],
  ]);
  const hsens = await db.q("SELECT id, adc_seco, adc_saturado FROM sensores WHERE tipo = 'humedad'");
  await insertarLotes("calibraciones", ["sensor_id", "tecnico_id", "adc_seco", "adc_saturado", "factor", "observacion", "fecha"],
    hsens.map(s => [s.id, 3, s.adc_seco, s.adc_saturado, 1, "Calibración inicial con suelo de la finca (método gravimétrico)", d(13)]));
  await db.ejecutar("UPDATE sensores SET ultima_calibracion = ? WHERE tipo = 'humedad'", [d(13)]);
  console.log(`[histórico] listo: ${est.length} lecturas de estación, ${lsec.length} de sectores, ${riegos.length} riegos.`);
  return true;
}

module.exports = { generarSiFalta };

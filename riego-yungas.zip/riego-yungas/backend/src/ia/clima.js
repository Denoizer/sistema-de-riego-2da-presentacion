// Módulo de IA – predicción climática local de 72 h fusionada con Open-Meteo
// Modelo local: perfil horario (regresión por hora del día sobre 7 días) + persistencia
// de la anomalía actual con decaimiento exponencial + probabilidad de lluvia por
// frecuencia horaria, humedad relativa y tendencia de presión.
const db = require("../db");
const config = require("../config");
const { fmt, ahora, parse } = require("../util/tiempo");
const { etoReferencia } = require("../motor/eto");
const { obtenerConfig } = require("../servicios/config");

let ultimoOpenMeteo = { ok: null, fecha: null };

async function pronosticoOpenMeteo() {
  const f = await db.uno("SELECT latitud, longitud FROM fincas WHERE id = 1");
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${f.latitud}&longitude=${f.longitud}` +
    "&hourly=temperature_2m,relative_humidity_2m,precipitation,precipitation_probability,et0_fao_evapotranspiration" +
    "&forecast_days=4&timezone=America%2FLa_Paz";
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 6000);
  try {
    const r = await fetch(url, { signal: ctrl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const j = await r.json();
    ultimoOpenMeteo = { ok: true, fecha: ahora() };
    const mapa = new Map();
    j.hourly.time.forEach((t, i) => mapa.set(t.replace("T", " ") + ":00", {
      temp_c: j.hourly.temperature_2m[i], hr_pct: j.hourly.relative_humidity_2m[i], lluvia_mm: j.hourly.precipitation[i],
      prob_lluvia: j.hourly.precipitation_probability[i], eto_mm: j.hourly.et0_fao_evapotranspiration[i],
    }));
    return mapa;
  } catch (e) {
    ultimoOpenMeteo = { ok: false, fecha: ahora(), error: e.message };
    return null;
  } finally { clearTimeout(t); }
}

// Clima real del momento en la finca según Open-Meteo (caché de 10 min)
let cacheActual = { t: 0, datos: null };
async function actualExterno() {
  const cfg = await obtenerConfig();
  if (!cfg.usar_open_meteo) return null;
  if (Date.now() - cacheActual.t < 10 * 60000) return cacheActual.datos;
  const f = await db.uno("SELECT latitud, longitud FROM fincas WHERE id = 1");
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${f.latitud}&longitude=${f.longitud}` +
    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,cloud_cover,wind_speed_10m,is_day" +
    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,et0_fao_evapotranspiration" +
    "&forecast_days=4&timezone=America%2FLa_Paz&wind_speed_unit=ms";
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 6000);
  try {
    const r = await fetch(url, { signal: ctrl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const j = await r.json();
    const c = j.current;
    cacheActual = { t: Date.now(), datos: {
      fecha: c.time.replace("T", " "), temp_c: c.temperature_2m, sensacion_c: c.apparent_temperature, hr_pct: c.relative_humidity_2m,
      lluvia_mm: c.precipitation, nubosidad_pct: c.cloud_cover, viento_ms: c.wind_speed_10m, codigo: c.weather_code, es_dia: !!c.is_day,
      dias: j.daily.time.map((d, i) => ({ fecha: d, codigo: j.daily.weather_code[i], tmax: j.daily.temperature_2m_max[i], tmin: j.daily.temperature_2m_min[i],
        lluvia_mm: j.daily.precipitation_sum[i], prob_lluvia: j.daily.precipitation_probability_max[i], eto_mm: j.daily.et0_fao_evapotranspiration[i] })),
    } };
    ultimoOpenMeteo = { ok: true, fecha: ahora() };
  } catch (e) {
    cacheActual = { t: Date.now() - 8 * 60000, datos: null }; // reintenta en 2 min
    ultimoOpenMeteo = { ok: false, fecha: ahora(), error: e.message };
  } finally { clearTimeout(t); }
  return cacheActual.datos;
}

/** Resumen diario de la predicción (hoy, mañana, pasado mañana) */
async function porDia() {
  const s = await serie();
  const dias = new Map();
  for (const h of s.horas) {
    const d = String(h.fecha_objetivo).slice(0, 10);
    if (!dias.has(d)) dias.set(d, { fecha: d, tmax: -99, tmin: 99, lluvia_mm: 0, prob_lluvia: 0, eto_mm: 0, horas: 0 });
    const x = dias.get(d);
    x.tmax = Math.max(x.tmax, h.temp_c); x.tmin = Math.min(x.tmin, h.temp_c);
    x.lluvia_mm += h.lluvia_mm || 0; x.prob_lluvia = Math.max(x.prob_lluvia, h.prob_lluvia || 0); x.eto_mm += h.eto_mm || 0; x.horas++;
  }
  return [...dias.values()];
}

/** Error medio absoluto de temperatura de las predicciones pasadas frente a la estación */
async function errorReciente(fuente) {
  const filas = await db.q(
    `SELECT p.temp_c pred, p.fecha_objetivo FROM predicciones p
      WHERE p.fuente = ? AND p.fecha_objetivo <= ? AND p.fecha_objetivo >= ? AND p.horizonte_h <= 6
      ORDER BY p.fecha_objetivo DESC LIMIT 60`, [fuente, ahora(), fmt(new Date(Date.now() - 2 * 86400000))]);
  if (!filas.length) return null;
  let suma = 0, n = 0;
  for (const f of filas) {
    const t = parse(f.fecha_objetivo);
    const real = await db.uno("SELECT AVG(temp_c) t FROM lecturas_estacion WHERE fecha >= ? AND fecha < ?",
      [fmt(new Date(t.getTime() - 30 * 60000)), fmt(new Date(t.getTime() + 30 * 60000))]);
    if (real && real.t !== null) { suma += Math.abs(real.t - f.pred); n++; }
  }
  return n ? suma / n : null;
}

/** Genera la predicción horaria de 72 h y la guarda en la tabla predicciones */
async function generar() {
  const desde = fmt(new Date(Date.now() - 7 * 86400000));
  const filas = await db.q("SELECT temp_c, hr_pct, presion_kpa, lluvia_mm, fecha FROM lecturas_estacion WHERE fecha >= ? ORDER BY fecha", [desde]);
  if (filas.length < 24) return null;

  // Perfil horario medio (24 h) y frecuencia de lluvia por hora
  const perfil = Array.from({ length: 24 }, () => ({ t: 0, hr: 0, n: 0, lluvia: 0, mm: 0 }));
  for (const f of filas) {
    const h = parse(f.fecha).getHours();
    perfil[h].t += f.temp_c; perfil[h].hr += f.hr_pct; perfil[h].n++;
    if (f.lluvia_mm > 0.05) { perfil[h].lluvia++; perfil[h].mm += f.lluvia_mm; }
  }
  for (const p of perfil) if (p.n) { p.t /= p.n; p.hr /= p.n; }
  const ult = filas[filas.length - 1];
  const hAct = parse(ult.fecha).getHours();
  const anomT = ult.temp_c - (perfil[hAct].t || ult.temp_c);
  const anomHR = ult.hr_pct - (perfil[hAct].hr || ult.hr_pct);
  const presAnt = filas.find(f => parse(f.fecha) >= new Date(Date.now() - 6 * 3600000));
  const tendenciaP = presAnt && ult.presion_kpa && presAnt.presion_kpa ? ult.presion_kpa - presAnt.presion_kpa : 0;
  const lluvia24 = filas.filter(f => parse(f.fecha) >= new Date(Date.now() - 86400000)).reduce((a, f) => a + f.lluvia_mm, 0);
  const etoDia = await etoReferencia();

  const cfg = await obtenerConfig();
  const usarOM = cfg.usar_open_meteo && (!config.simulador || config.simUsarOpenMeteo);
  const om = usarOM ? await pronosticoOpenMeteo() : null;
  const maeLocal = await errorReciente("local");
  const maeOM = om ? await errorReciente("open_meteo") : null;
  const wLocal = om ? (maeLocal && maeOM ? maeOM / (maeLocal + maeOM) : 0.5) : 1;

  const generado = ahora();
  const base = new Date(); base.setMinutes(0, 0, 0);
  const valores = [];
  for (let k = 1; k <= 72; k++) {
    const t = new Date(base.getTime() + k * 3600000);
    const h = t.getHours();
    const p = perfil[h].n ? perfil[h] : { t: ult.temp_c, hr: ult.hr_pct, n: 1, lluvia: 0, mm: 0 };
    const decae = Math.exp(-k / 8);
    const temp = p.t + anomT * decae;
    const hr = Math.min(100, Math.max(20, p.hr + anomHR * decae));
    const frec = p.n ? p.lluvia / Math.max(1, p.n) : 0;
    const logit = -3.2 + 4 * frec + 0.06 * (hr - 75) - 2.2 * tendenciaP + 0.08 * Math.min(lluvia24, 20) * decae;
    const prob = 100 / (1 + Math.exp(-logit));
    const sol = Math.max(0, Math.sin((Math.PI * (h - 6)) / 12));
    const local = { temp_c: temp, hr_pct: hr, prob_lluvia: prob, lluvia_mm: (prob / 100) * (p.lluvia ? (p.mm / p.lluvia) * 0.6 : 0.8), eto_mm: (etoDia * sol) / 7.64 };
    const fObj = fmt(t);
    valores.push([generado, k, fObj, local, "local"]);
    const o = om && om.get(fObj);
    if (o) {
      valores.push([generado, k, fObj, o, "open_meteo"]);
      const mix = (a, b) => (a === null || a === undefined ? b : wLocal * b + (1 - wLocal) * a);
      valores.push([generado, k, fObj, {
        temp_c: mix(o.temp_c, local.temp_c), hr_pct: mix(o.hr_pct, local.hr_pct), prob_lluvia: mix(o.prob_lluvia, local.prob_lluvia),
        lluvia_mm: mix(o.lluvia_mm, local.lluvia_mm), eto_mm: mix(o.eto_mm, local.eto_mm),
      }, "fusion"]);
    }
  }
  const r2 = v => (v === null || v === undefined || Number.isNaN(v) ? null : Math.round(v * 100) / 100);
  for (let i = 0; i < valores.length; i += 100) {
    const lote = valores.slice(i, i + 100);
    await db.ejecutar(
      "INSERT INTO predicciones (generado_en, horizonte_h, fecha_objetivo, temp_c, hr_pct, lluvia_mm, prob_lluvia, eto_mm, fuente) VALUES " +
      lote.map(() => "(?,?,?,?,?,?,?,?,?)").join(","),
      lote.flatMap(([g, k, f, v, fuente]) => [g, k, f, r2(v.temp_c), r2(v.hr_pct), r2(v.lluvia_mm), r2(v.prob_lluvia), r2(v.eto_mm), fuente]));
  }
  await db.ejecutar("DELETE FROM predicciones WHERE generado_en < ?", [fmt(new Date(Date.now() - 3 * 86400000))]);
  await db.ejecutar(
    "UPDATE modelos_ia SET mae = ?, n_muestras = ?, entrenado_en = ?, parametros = ?, fase = ? WHERE tipo = 'clima'",
    [maeLocal === null ? null : Math.round(maeLocal * 1000) / 1000, filas.length, generado,
     JSON.stringify({ peso_local: Math.round(wLocal * 100) / 100, mae_open_meteo: maeOM, open_meteo: ultimoOpenMeteo }),
     maeLocal === null ? "observacion" : maeLocal <= 1.5 ? "adaptacion" : "recomendacion"]);
  return { generado, fuente: om ? "fusion" : "local", peso_local: wLocal };
}

/** Serie horaria más reciente (fusión si existe, si no local) */
async function serie() {
  const g = await db.uno("SELECT MAX(generado_en) g FROM predicciones");
  if (!g || !g.g) return { generado_en: null, fuente: null, horas: [] };
  const hayFusion = await db.uno("SELECT COUNT(*) n FROM predicciones WHERE generado_en = ? AND fuente = 'fusion'", [g.g]);
  const fuente = hayFusion.n ? "fusion" : "local";
  const horas = await db.q("SELECT horizonte_h, fecha_objetivo, temp_c, hr_pct, lluvia_mm, prob_lluvia, eto_mm FROM predicciones WHERE generado_en = ? AND fuente = ? ORDER BY horizonte_h", [g.g, fuente]);
  return { generado_en: g.g, fuente, horas, open_meteo: ultimoOpenMeteo };
}

/** Resumen para un horizonte (6, 24, 48 o 72 h) */
async function resumen(h = 24) {
  const s = await serie();
  if (!s.horas.length) return null;
  const tramo = s.horas.filter(x => x.horizonte_h <= h);
  return {
    horizonte_h: h,
    lluvia_mm: tramo.reduce((a, x) => a + (x.lluvia_mm || 0), 0),
    prob_max: Math.max(...tramo.map(x => x.prob_lluvia || 0)),
    eto_mm: tramo.reduce((a, x) => a + (x.eto_mm || 0), 0),
    tmax: Math.max(...tramo.map(x => x.temp_c)), tmin: Math.min(...tramo.map(x => x.temp_c)),
    fuente: s.fuente, generado_en: s.generado_en,
  };
}

module.exports = { generar, serie, resumen, actualExterno, porDia };

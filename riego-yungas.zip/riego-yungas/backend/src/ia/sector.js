// Módulo de IA – aprendizaje progresivo por sector
// Modelo: regresión lineal entrenada en línea (descenso de gradiente estocástico)
// que predice el cambio de humedad del suelo en 24 h de campo. Además calibra un
// factor de corrección del Kc observando el secado real del suelo.
// Fases (3.15.2): observación (<30 muestras) -> recomendación (<120) -> adaptación.
const db = require("../db");
const config = require("../config");
const { ahora, fmt, parse } = require("../util/tiempo");
const estado = require("../motor/estado");

const FASE_RECOMENDACION = 30, FASE_ADAPTACION = 120;
const TASA = 0.05;
const h24 = () => (24 * 3600 * 1000) / (config.simulador ? config.acel : 1); // 24 h de campo en ms reales

const vector = ({ humedad, etcLoc, temp, lluvia, horas }) =>
  [1, humedad, etcLoc / 4, (temp ?? 18) / 30, Math.min(lluvia ?? 0, 20) / 10, Math.min(horas ?? 72, 72) / 72];

async function modelo(sector_id) {
  const m = await db.uno("SELECT * FROM modelos_ia WHERE tipo = 'sector' AND sector_id = ? AND activo = 1", [sector_id]);
  if (!m) return null;
  let p = {};
  try { p = m.parametros ? JSON.parse(m.parametros) : {}; } catch { p = {}; }
  if (!p.w) p.w = [0, 0, -0.0133, 0, 0.004, 0]; // prior físico: Δθ ≈ −ETc/(Zr·Pw)
  if (p.ratioKc === undefined) p.ratioKc = 1;
  return { ...m, p };
}

async function predecir(sector_id, f) {
  const m = await modelo(sector_id);
  if (!m || f.humedad === null || f.humedad === undefined) return null;
  const x = vector(f);
  const delta = x.reduce((a, xi, i) => a + xi * m.p.w[i], 0);
  return Math.max(0.05, Math.min(0.45, f.humedad + delta));
}

/** Toma una "foto" del estado de cada sector para aprender 24 h después */
async function registrarMuestras(etcPorSector) {
  const objetivo = fmt(new Date(Date.now() + h24()));
  const pron = await require("./clima").resumen(24);
  let n = 0;
  for (const [id, st] of estado.sectores) {
    if (st.humedad === null || st.humedad === undefined) continue;
    n++;
    const s = await db.uno("SELECT ultimo_riego FROM sectores WHERE id = ?", [id]);
    const horas = s && s.ultimo_riego ? ((Date.now() - parse(s.ultimo_riego).getTime()) / 3600000) * (config.simulador ? config.acel : 1) : 72;
    await db.ejecutar(
      "INSERT INTO muestras_ia (sector_id, humedad, etc_loc_mm, temp_suelo, lluvia_prev_mm, horas_desde_riego, fecha, fecha_objetivo) VALUES (?,?,?,?,?,?,?,?)",
      [id, Math.round(st.humedad * 1000) / 1000, Math.round((etcPorSector[id] || 0) * 100) / 100, st.temp ?? null,
       pron ? Math.round(pron.lluvia_mm * 100) / 100 : 0, Math.round(Math.min(horas, 999) * 10) / 10, ahora(), objetivo]);
  }
  return n;
}

/** Completa las muestras vencidas con la humedad real y entrena el modelo */
async function aprender() {
  const pendientes = await db.q("SELECT * FROM muestras_ia WHERE humedad_objetivo IS NULL AND fecha_objetivo <= ? ORDER BY fecha LIMIT 200", [ahora()]);
  const tocados = new Set();
  for (const mu of pendientes) {
    const st = estado.sectores.get(mu.sector_id);
    if (!st || st.humedad === null || st.humedad === undefined) continue;
    await db.ejecutar("UPDATE muestras_ia SET humedad_objetivo = ? WHERE id = ?", [Math.round(st.humedad * 1000) / 1000, mu.id]);
    const m = await modelo(mu.sector_id);
    const x = vector({ humedad: mu.humedad, etcLoc: mu.etc_loc_mm, temp: mu.temp_suelo, lluvia: mu.lluvia_prev_mm, horas: mu.horas_desde_riego });
    const real = st.humedad - mu.humedad;
    const pred = x.reduce((a, xi, i) => a + xi * m.p.w[i], 0);
    const err = real - pred;
    m.p.w = m.p.w.map((w, i) => w + TASA * err * x[i]);
    m.p.maeEma = m.p.maeEma === undefined ? Math.abs(err) : 0.9 * m.p.maeEma + 0.1 * Math.abs(err);
    m.p.rmseEma = m.p.rmseEma === undefined ? err * err : 0.9 * m.p.rmseEma + 0.1 * err * err;

    // Calibración del Kc: solo en ventanas sin riego ni lluvia
    const sec = await db.uno("SELECT s.ultimo_riego, c.prof_raiz_m, s.fraccion_humedecida FROM sectores s JOIN cultivos c ON c.id = s.cultivo_id WHERE s.id = ?", [mu.sector_id]);
    const llovio = await db.uno("SELECT COALESCE(SUM(lluvia_mm),0) mm FROM lecturas_estacion WHERE fecha >= ? AND fecha <= ?", [mu.fecha, mu.fecha_objetivo]);
    const huboRiego = sec.ultimo_riego && sec.ultimo_riego >= mu.fecha;
    if (!huboRiego && llovio.mm < 0.5 && mu.etc_loc_mm > 0.2 && real < 0) {
      const esperado = mu.etc_loc_mm / (sec.prof_raiz_m * 1000 * sec.fraccion_humedecida);
      const ratio = Math.min(1.5, Math.max(0.5, -real / esperado));
      m.p.ratioKc = 0.95 * m.p.ratioKc + 0.05 * ratio;
    }
    const n = m.n_muestras + 1;
    const fase = n >= FASE_ADAPTACION ? "adaptacion" : n >= FASE_RECOMENDACION ? "recomendacion" : "observacion";
    await db.ejecutar("UPDATE modelos_ia SET n_muestras = ?, fase = ?, mae = ?, rmse = ?, parametros = ?, entrenado_en = ? WHERE id = ?",
      [n, fase, Math.round(m.p.maeEma * 10000) / 10000, Math.round(Math.sqrt(m.p.rmseEma) * 10000) / 10000, JSON.stringify(m.p), ahora(), m.id]);
    tocados.add(mu.sector_id);
  }
  for (const id of tocados) await adaptar(id);
  return pendientes.length;
}

/** En fase de adaptación ajusta el factor de Kc y el umbral dentro de ±10 % */
async function adaptar(sector_id) {
  const m = await modelo(sector_id);
  if (!m || m.fase !== "adaptacion") return;
  const s = await db.uno("SELECT umbral_base, umbral_humedad FROM sectores WHERE id = ?", [sector_id]);
  const factor = Math.min(1.1, Math.max(0.9, m.p.ratioKc));
  const st = estado.sectores.get(sector_id);
  let umbral = s.umbral_humedad;
  if (st && st.humedad !== null && st.humedad !== undefined) {
    const pred = await predecir(sector_id, { humedad: st.humedad, etcLoc: 2, temp: st.temp, lluvia: 0, horas: 24 });
    umbral = umbral + 0.1 * (s.umbral_base - pred) * 0.1;
  }
  umbral = Math.min(s.umbral_base * 1.1, Math.max(s.umbral_base * 0.9, umbral));
  await db.ejecutar("UPDATE sectores SET factor_kc_ia = ?, umbral_humedad = ? WHERE id = ?",
    [Math.round(factor * 1000) / 1000, Math.round(umbral * 1000) / 1000, sector_id]);
}

/** Reentrenamiento completo (por lotes) con todas las muestras completas del sector */
async function reentrenar(sector_id) {
  const muestras = await db.q("SELECT * FROM muestras_ia WHERE sector_id = ? AND humedad_objetivo IS NOT NULL ORDER BY fecha", [sector_id]);
  const m = await modelo(sector_id);
  if (!m) return null;
  let w = [0, 0, -0.0133, 0, 0.004, 0];
  for (let epoca = 0; epoca < 30; epoca++)
    for (const mu of muestras) {
      const x = vector({ humedad: mu.humedad, etcLoc: mu.etc_loc_mm, temp: mu.temp_suelo, lluvia: mu.lluvia_prev_mm, horas: mu.horas_desde_riego });
      const err = (mu.humedad_objetivo - mu.humedad) - x.reduce((a, xi, i) => a + xi * w[i], 0);
      w = w.map((wi, i) => wi + TASA * err * x[i]);
    }
  let sae = 0, sse = 0;
  for (const mu of muestras) {
    const x = vector({ humedad: mu.humedad, etcLoc: mu.etc_loc_mm, temp: mu.temp_suelo, lluvia: mu.lluvia_prev_mm, horas: mu.horas_desde_riego });
    const err = (mu.humedad_objetivo - mu.humedad) - x.reduce((a, xi, i) => a + xi * w[i], 0);
    sae += Math.abs(err); sse += err * err;
  }
  const n = muestras.length || 1;
  m.p.w = w; m.p.maeEma = sae / n; m.p.rmseEma = sse / n;
  await db.ejecutar("UPDATE modelos_ia SET version = version + 1, mae = ?, rmse = ?, parametros = ?, entrenado_en = ? WHERE id = ?",
    [Math.round((sae / n) * 10000) / 10000, Math.round(Math.sqrt(sse / n) * 10000) / 10000, JSON.stringify(m.p), ahora(), m.id]);
  return { muestras: muestras.length, mae: sae / n };
}

module.exports = { modelo, predecir, registrarMuestras, aprender, reentrenar };

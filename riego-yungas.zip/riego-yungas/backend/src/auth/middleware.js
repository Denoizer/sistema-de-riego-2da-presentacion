// Autenticación (JWT) y autorización por permisos del rol
const { verificar } = require("./jwt");
const { HttpError } = require("../http/app");
const db = require("../db");

const cachePermisos = new Map(); // rol_id -> Set(permisos)

async function permisosDeRol(rolId) {
  if (!cachePermisos.has(rolId)) {
    const filas = await db.q(
      "SELECT p.codigo FROM rol_permiso rp JOIN permisos p ON p.id = rp.permiso_id WHERE rp.rol_id = ?", [rolId]);
    cachePermisos.set(rolId, new Set(filas.map(f => f.codigo)));
  }
  return cachePermisos.get(rolId);
}

/** Exige un token válido (cabecera Authorization: Bearer <token> o ?token=) */
async function autenticar(req) {
  const cab = req.headers.authorization || "";
  const token = cab.startsWith("Bearer ") ? cab.slice(7) : req.query.token;
  const datos = verificar(token);
  if (!datos) throw new HttpError(401, "Sesión no válida o expirada");
  const u = await db.uno(
    "SELECT u.id, u.usuario, u.nombre, u.apellido, u.activo, u.rol_id, r.codigo AS rol, r.nombre AS rol_nombre FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE u.id = ?",
    [datos.id]);
  if (!u || !u.activo) throw new HttpError(401, "Usuario desactivado");
  u.permisos = [...(await permisosDeRol(u.rol_id))];
  req.usuario = u;
}

/** Middleware: exige al menos uno de los permisos indicados */
const requiere = (...permisos) => async req => {
  if (!req.usuario) await autenticar(req);
  if (permisos.length && !permisos.some(p => req.usuario.permisos.includes(p)))
    throw new HttpError(403, "No tiene permiso para esta acción");
};

const tiene = (req, permiso) => req.usuario && req.usuario.permisos.includes(permiso);

module.exports = { autenticar, requiere, tiene, permisosDeRol };

// Cifrado de contraseñas con scrypt (módulo crypto de Node.js)
const crypto = require("crypto");

const N = 16384, r = 8, p = 1, LARGO = 64;

function hashPassword(clave) {
  const sal = crypto.randomBytes(16);
  const hash = crypto.scryptSync(clave, sal, LARGO, { N, r, p });
  return `scrypt$${N}$${r}$${p}$${sal.toString("base64")}$${hash.toString("base64")}`;
}

function verificarPassword(clave, almacenado) {
  try {
    const [alg, n, rr, pp, salB64, hashB64] = String(almacenado).split("$");
    if (alg !== "scrypt") return false;
    const esperado = Buffer.from(hashB64, "base64");
    const calculado = crypto.scryptSync(clave, Buffer.from(salB64, "base64"), esperado.length, { N: +n, r: +rr, p: +pp });
    return crypto.timingSafeEqual(esperado, calculado);
  } catch {
    return false;
  }
}

/** Política mínima: 8 caracteres, una mayúscula, una minúscula y un número */
function claveValida(clave) {
  return typeof clave === "string" && clave.length >= 8 && /[A-Z]/.test(clave) && /[a-z]/.test(clave) && /\d/.test(clave);
}

module.exports = { hashPassword, verificarPassword, claveValida };

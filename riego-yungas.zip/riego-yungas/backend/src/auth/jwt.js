// JSON Web Token HS256 implementado con crypto (sin dependencias)
const crypto = require("crypto");
const config = require("../config");

const b64url = buf => Buffer.from(buf).toString("base64url");

function firmar(payload) {
  const cab = b64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const exp = Math.floor(Date.now() / 1000) + config.jwtHoras * 3600;
  const cuerpo = b64url(JSON.stringify({ ...payload, exp }));
  const firma = crypto.createHmac("sha256", config.jwtSecreto).update(`${cab}.${cuerpo}`).digest("base64url");
  return `${cab}.${cuerpo}.${firma}`;
}

function verificar(token) {
  if (!token || token.split(".").length !== 3) return null;
  const [cab, cuerpo, firma] = token.split(".");
  const esperada = crypto.createHmac("sha256", config.jwtSecreto).update(`${cab}.${cuerpo}`).digest("base64url");
  if (firma.length !== esperada.length || !crypto.timingSafeEqual(Buffer.from(firma), Buffer.from(esperada))) return null;
  const datos = JSON.parse(Buffer.from(cuerpo, "base64url").toString());
  if (datos.exp < Date.now() / 1000) return null;
  return datos;
}

module.exports = { firmar, verificar };

// Acceso por sector: el agricultor solo opera los sectores que tiene a su cargo
const db = require("../db");
const { HttpError } = require("../http/app");

/** null = todos los sectores; arreglo = solo esos ids */
async function sectoresPermitidos(req) {
  if (!req.usuario || req.usuario.rol !== "agricultor") return null;
  const f = await db.q("SELECT sector_id FROM usuario_sector WHERE usuario_id = ?", [req.usuario.id]);
  return f.length ? f.map(x => x.sector_id) : null;
}

async function exigirSector(req, sector_id) {
  const p = await sectoresPermitidos(req);
  if (p && !p.includes(Number(sector_id))) throw new HttpError(403, "Este sector no está a su cargo");
}

/** Fragmento SQL "AND col IN (...)" para filtrar listas */
async function filtroSql(req, columna) {
  const p = await sectoresPermitidos(req);
  return p ? ` AND ${columna} IN (${p.map(Number).join(",")})` : "";
}

module.exports = { sectoresPermitidos, exigirSector, filtroSql };

// Punto de entrada: API REST + panel web + motor de riego + simulador
const path = require("path");
const config = require("./config");
const db = require("./db");
const { App } = require("./http/app");

const app = new App();
require("./routes/auth")(app);
require("./routes/sectores")(app);
require("./routes/clima")(app);
require("./routes/historial")(app);
require("./routes/alertas")(app);
require("./routes/dispositivos")(app);
require("./routes/admin")(app);
require("./routes/iot")(app);
require("./routes/programados")(app);
app.get("/api/salud", async (req, res) => {
  const r = await db.uno("SELECT COUNT(*) n FROM sectores");
  res.json({ ok: true, sectores: r.n, simulador: config.simulador });
});
app.servirEstatico(path.join(__dirname, "..", "public"));

async function arrancar() {
  try {
    await db.uno("SELECT 1 AS ok");
  } catch (e) {
    console.error("\n✖ No se pudo conectar a MySQL:", e.message);
    console.error("  Verifique que ejecutó database/01, 02 y 03 en MySQL Workbench y revise backend/.env\n");
    process.exit(1);
  }
  await require("./motor/historico").generarSiFalta();
  if (config.simulador) await require("./motor/simulador").iniciar();
  require("./motor/supervisor").iniciar();
  app.escuchar(config.puerto, () => {
    console.log(`\n🌱 Riego Yungas IA en http://localhost:${config.puerto}`);
    console.log("   admin / Admin2026!   ·   agricultor / Agro2026!   ·   tecnico / Tecnico2026!\n");
  });
}

arrancar();

// Notificaciones en tiempo real (Server-Sent Events) y notificaciones persistentes
const db = require("../db");
const { ahora } = require("../util/tiempo");

const clientes = new Set(); // { res, usuario }

function registrarCliente(res, usuario) {
  res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" });
  res.write(`event: hola\ndata: ${JSON.stringify({ usuario: usuario.usuario })}\n\n`);
  const c = { res, usuario };
  clientes.add(c);
  const latido = setInterval(() => res.write(": ping\n\n"), 25000);
  res.on("close", () => { clearInterval(latido); clientes.delete(c); });
}

/** Envía un evento a todos los clientes conectados (opcionalmente filtrado por roles) */
function emitir(evento, datos, roles = null) {
  const msg = `event: ${evento}\ndata: ${JSON.stringify(datos)}\n\n`;
  for (const c of clientes) if (!roles || roles.includes(c.usuario.rol)) c.res.write(msg);
}

/**
 * Destinatarios: usuarios activos de los roles indicados. Si la notificación es de un
 * sector, el agricultor solo la recibe si ese sector está a su cargo (tabla usuario_sector);
 * un agricultor sin sectores asignados recibe las de todos los sectores.
 */
async function destinatarios(roles, sector_id = null) {
  const usuarios = await db.q(
    `SELECT u.id, r.codigo AS rol FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE u.activo = 1 AND r.codigo IN (${roles.map(() => "?").join(",")})`,
    roles);
  if (sector_id === null || sector_id === undefined) return usuarios;
  const asign = await db.q("SELECT usuario_id, sector_id FROM usuario_sector");
  return usuarios.filter(u => {
    if (u.rol !== "agricultor") return true;
    const mios = asign.filter(a => a.usuario_id === u.id).map(a => a.sector_id);
    return !mios.length || mios.includes(Number(sector_id));
  });
}

/** Guarda una notificación para cada destinatario y la empuja por SSE solo a ellos */
async function notificar(roles, titulo, mensaje, nivel = "info", { sector_id = null } = {}) {
  const usuarios = await destinatarios(roles, sector_id);
  const fecha = ahora();
  for (const u of usuarios)
    await db.ejecutar("INSERT INTO notificaciones (usuario_id, titulo, mensaje, nivel, fecha) VALUES (?,?,?,?,?)", [u.id, titulo, mensaje, nivel, fecha]);
  const ids = new Set(usuarios.map(u => u.id));
  const msg = `event: notificacion\ndata: ${JSON.stringify({ titulo, mensaje, nivel, fecha, sector_id })}\n\n`;
  for (const c of clientes) if (ids.has(c.usuario.id)) c.res.write(msg);
}

module.exports = { registrarCliente, emitir, notificar, destinatarios, clientes };

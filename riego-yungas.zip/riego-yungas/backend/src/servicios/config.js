// Lectura de la tabla configuracion y de las reglas de automatización
const db = require("../db");

async function obtenerConfig() {
  const filas = await db.q("SELECT clave, valor, tipo FROM configuracion");
  const c = {};
  for (const f of filas) c[f.clave] = f.tipo === "texto" ? f.valor : Number(f.valor);
  return c;
}

async function obtenerReglas() {
  const filas = await db.q("SELECT codigo, activa, valor FROM reglas_automatizacion");
  const r = {};
  for (const f of filas) r[f.codigo] = { activa: !!f.activa, valor: f.valor === null ? null : Number(f.valor) };
  return r;
}

module.exports = { obtenerConfig, obtenerReglas };

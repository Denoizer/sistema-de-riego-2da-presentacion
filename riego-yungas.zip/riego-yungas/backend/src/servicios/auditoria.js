const db = require("../db");
const { ahora } = require("../util/tiempo");

async function auditar(req, accion, entidad = null, entidad_id = null, detalle = null) {
  await db.ejecutar(
    "INSERT INTO auditoria (usuario_id, accion, entidad, entidad_id, detalle, ip, fecha) VALUES (?,?,?,?,?,?,?)",
    [req && req.usuario ? req.usuario.id : null, accion, entidad, entidad_id === null ? null : String(entidad_id),
     detalle ? String(detalle).slice(0, 500) : null, req ? req.ip_cliente : null, ahora()]);
}

module.exports = { auditar };

// Generación de alertas del catálogo A-01..A-11 con control de duplicados
const db = require("../db");
const { ahora } = require("../util/tiempo");
const { notificar, emitir } = require("./notificador");

/**
 * Crea una alerta si no existe otra igual sin atender (mismo tipo, sector y nodo).
 * @returns {Promise<number|null>} id de la alerta creada o null si era duplicada
 */
async function crearAlerta(codigo, { sector_id = null, nodo_id = null, mensaje }) {
  const tipo = await db.uno("SELECT * FROM tipos_alerta WHERE codigo = ?", [codigo]);
  if (!tipo) throw new Error(`Tipo de alerta desconocido: ${codigo}`);
  const dup = await db.uno(
    `SELECT id FROM alertas WHERE tipo_alerta_id = ? AND atendida = 0
       AND ${sector_id === null ? "sector_id IS NULL" : "sector_id = ?"}
       AND ${nodo_id === null ? "nodo_id IS NULL" : "nodo_id = ?"}`,
    [tipo.id, ...(sector_id === null ? [] : [sector_id]), ...(nodo_id === null ? [] : [nodo_id])]);
  if (dup) return null;
  const r = await db.ejecutar(
    "INSERT INTO alertas (tipo_alerta_id, sector_id, nodo_id, mensaje, fecha) VALUES (?,?,?,?,?)",
    [tipo.id, sector_id, nodo_id, mensaje, ahora()]);
  await notificar(tipo.destinatarios.split(","), `${tipo.codigo} · ${tipo.nombre}`, mensaje, tipo.severidad, { sector_id });
  emitir("alertas", { id: r.insertId });
  return r.insertId;
}

/** Marca como atendidas, de forma automática, las alertas que ya se resolvieron solas */
async function resolverAutomaticamente(codigo, { sector_id = null, nodo_id = null }, nota) {
  const tipo = await db.uno("SELECT id FROM tipos_alerta WHERE codigo = ?", [codigo]);
  const r = await db.ejecutar(
    `UPDATE alertas SET atendida = 1, atendida_en = ?, nota_atencion = ?
      WHERE tipo_alerta_id = ? AND atendida = 0
        AND ${sector_id === null ? "1 = 1" : "sector_id = " + Number(sector_id)}
        AND ${nodo_id === null ? "1 = 1" : "nodo_id = " + Number(nodo_id)}`,
    [ahora(), nota || "Resuelta automáticamente por el sistema", tipo.id]);
  if (r.affectedRows) emitir("alertas", {});
}

module.exports = { crearAlerta, resolverAutomaticamente };

// Autenticación: inicio de sesión con bloqueo tras 5 intentos (HU-01)
const db = require("../db");
const { firmar } = require("../auth/jwt");
const { verificarPassword, hashPassword, claveValida } = require("../auth/password");
const { requiere, permisosDeRol } = require("../auth/middleware");
const { HttpError } = require("../http/app");
const { ahora, dentro, parse } = require("../util/tiempo");
const { auditar } = require("../servicios/auditoria");

module.exports = app => {
  app.post("/api/auth/login", async (req, res) => {
    const { usuario, clave } = req.body;
    if (!usuario || !clave) throw new HttpError(400, "Ingrese usuario y contraseña");
    const u = await db.uno(
      "SELECT u.*, r.codigo AS rol, r.nombre AS rol_nombre FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE u.usuario = ? OR u.correo = ?",
      [String(usuario).trim().toLowerCase(), String(usuario).trim().toLowerCase()]);
    if (!u) throw new HttpError(401, "Usuario o contraseña incorrectos");
    if (!u.activo) throw new HttpError(403, "El usuario está desactivado. Contacte al administrador.");
    if (u.bloqueado_hasta && parse(u.bloqueado_hasta) > new Date())
      throw new HttpError(423, "Demasiados intentos. Intente nuevamente en 5 minutos.");
    if (!verificarPassword(clave, u.password_hash)) {
      const intentos = u.intentos_fallidos + 1;
      await db.ejecutar("UPDATE usuarios SET intentos_fallidos = ?, bloqueado_hasta = ? WHERE id = ?",
        [intentos >= 5 ? 0 : intentos, intentos >= 5 ? dentro(5) : null, u.id]);
      await auditar({ usuario: { id: u.id }, ip_cliente: req.ip_cliente }, "LOGIN_FALLIDO", "usuarios", u.id, `Intento ${intentos}`);
      throw new HttpError(intentos >= 5 ? 423 : 401, intentos >= 5 ? "Demasiados intentos. Intente nuevamente en 5 minutos." : "Usuario o contraseña incorrectos");
    }
    await db.ejecutar("UPDATE usuarios SET intentos_fallidos = 0, bloqueado_hasta = NULL, ultimo_acceso = ? WHERE id = ?", [ahora(), u.id]);
    await auditar({ usuario: { id: u.id }, ip_cliente: req.ip_cliente }, "LOGIN", "usuarios", u.id);
    const permisos = [...(await permisosDeRol(u.rol_id))];
    res.json({
      token: firmar({ id: u.id, rol: u.rol }),
      usuario: { id: u.id, usuario: u.usuario, nombre: u.nombre, apellido: u.apellido, rol: u.rol, rol_nombre: u.rol_nombre, permisos },
    });
  });

  app.get("/api/auth/me", requiere(), async (req, res) => {
    const u = req.usuario;
    res.json({ id: u.id, usuario: u.usuario, nombre: u.nombre, apellido: u.apellido, rol: u.rol, rol_nombre: u.rol_nombre, permisos: u.permisos });
  });

  app.put("/api/auth/clave", requiere(), async (req, res) => {
    const { actual, nueva } = req.body;
    const u = await db.uno("SELECT password_hash FROM usuarios WHERE id = ?", [req.usuario.id]);
    if (!verificarPassword(actual || "", u.password_hash)) throw new HttpError(400, "La contraseña actual no es correcta");
    if (!claveValida(nueva)) throw new HttpError(400, "La nueva contraseña debe tener al menos 8 caracteres, una mayúscula, una minúscula y un número");
    await db.ejecutar("UPDATE usuarios SET password_hash = ? WHERE id = ?", [hashPassword(nueva), req.usuario.id]);
    await auditar(req, "CAMBIO_CLAVE", "usuarios", req.usuario.id);
    res.json({ ok: true });
  });

  app.post("/api/auth/logout", requiere(), async (req, res) => {
    await auditar(req, "LOGOUT", "usuarios", req.usuario.id);
    res.json({ ok: true });
  });
};

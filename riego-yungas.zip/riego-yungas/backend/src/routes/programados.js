// Riegos programados por litros (una vez o todos los días)
const db = require("../db");
const { requiere } = require("../auth/middleware");
const { HttpError } = require("../http/app");
const { ahora, fmt, fecha } = require("../util/tiempo");
const { exigirSector, filtroSql } = require("../auth/acceso");
const { obtenerConfig } = require("../servicios/config");
const { auditar } = require("../servicios/auditoria");
const { emitir } = require("../servicios/notificador");

/** Próxima fecha/hora de ejecución a partir de "HH:MM" y una fecha opcional */
function proxima(hora, dia = null) {
  const [h, m] = hora.split(":").map(Number);
  const d = dia ? new Date(dia + "T00:00:00") : new Date();
  d.setHours(h, m, 0, 0);
  if (!dia && d <= new Date()) d.setDate(d.getDate() + 1);
  return d;
}

async function validar(b, sector) {
  const cfg = await obtenerConfig();
  const maxL = Math.floor((sector.caudal_nominal_lh * (cfg.max_min_riego || 180)) / 60);
  const litros = Number(b.litros);
  if (!Number.isFinite(litros) || litros < 100 || litros > maxL) throw new HttpError(400, `Los litros deben estar entre 100 y ${maxL.toLocaleString("es-BO")} L para ${sector.codigo}`);
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(b.hora || "")) throw new HttpError(400, "Ingrese una hora válida (HH:MM)");
  if (!["una_vez", "diario"].includes(b.repetir || "una_vez")) throw new HttpError(400, "Repetición no válida");
  if (b.fecha && !/^\d{4}-\d{2}-\d{2}$/.test(b.fecha)) throw new HttpError(400, "Fecha no válida");
  const p = proxima(b.hora, b.repetir === "diario" ? null : b.fecha || null);
  if (p <= new Date()) throw new HttpError(400, "La fecha y hora deben ser futuras");
  return { litros, proxima: fmt(p) };
}

module.exports = app => {
  app.get("/api/programados", requiere("riego.programar", "riego.manual", "sensores.ver"), async (req, res) => {
    const filas = await db.q(
      `SELECT p.id, p.sector_id, s.codigo sector, s.nombre sector_nombre, s.caudal_nominal_lh, p.litros, p.hora, p.repetir, p.proxima_ejecucion,
              p.activo, p.nota, p.ultima_ejecucion, p.creado_en, CONCAT(u.nombre, ' ', u.apellido) creado_por
         FROM riegos_programados p JOIN sectores s ON s.id = p.sector_id LEFT JOIN usuarios u ON u.id = p.usuario_id
        WHERE 1 = 1 ${await filtroSql(req, "p.sector_id")} ORDER BY p.activo DESC, p.proxima_ejecucion`);
    for (const f of filas) f.minutos_estimados = Math.round((f.litros / f.caudal_nominal_lh) * 600) / 10;
    res.json(filas);
  });

  app.post("/api/programados", requiere("riego.programar"), async (req, res) => {
    const b = req.body;
    const sector = await db.uno("SELECT * FROM sectores WHERE id = ?", [Number(b.sector_id)]);
    if (!sector) throw new HttpError(400, "Seleccione un sector");
    await exigirSector(req, sector.id);
    const v = await validar(b, sector);
    const r = await db.ejecutar(
      "INSERT INTO riegos_programados (sector_id, usuario_id, litros, hora, proxima_ejecucion, repetir, activo, nota, creado_en) VALUES (?,?,?,?,?,?,1,?,?)",
      [sector.id, req.usuario.id, v.litros, b.hora + ":00", v.proxima, b.repetir || "una_vez", (b.nota || "").slice(0, 200) || null, ahora()]);
    await auditar(req, "PROGRAMAR_RIEGO", "riegos_programados", r.insertId, `${sector.codigo} ${v.litros} L ${b.hora} ${b.repetir || "una_vez"}`);
    emitir("programados", {});
    res.json({ ok: true, id: r.insertId, proxima_ejecucion: v.proxima, minutos_estimados: Math.round((v.litros / sector.caudal_nominal_lh) * 600) / 10 });
  });

  app.put("/api/programados/:id", requiere("riego.programar"), async (req, res) => {
    const p = await db.uno("SELECT * FROM riegos_programados WHERE id = ?", [Number(req.params.id)]);
    if (!p) throw new HttpError(404, "Programación no encontrada");
    await exigirSector(req, p.sector_id);
    const b = req.body;
    if (b.litros !== undefined || b.hora !== undefined || b.repetir !== undefined) {
      const sector = await db.uno("SELECT * FROM sectores WHERE id = ?", [p.sector_id]);
      const datos = { litros: b.litros ?? p.litros, hora: b.hora ?? String(p.hora).slice(0, 5), repetir: b.repetir ?? p.repetir, fecha: b.fecha || (p.repetir === "una_vez" ? fecha(new Date(p.proxima_ejecucion.replace(" ", "T"))) : null) };
      if (datos.repetir === "una_vez" && datos.fecha && new Date(datos.fecha + "T" + datos.hora) <= new Date()) datos.fecha = null;
      const v = await validar(datos, sector);
      await db.ejecutar("UPDATE riegos_programados SET litros = ?, hora = ?, repetir = ?, proxima_ejecucion = ? WHERE id = ?", [v.litros, datos.hora + ":00", datos.repetir, v.proxima, p.id]);
    }
    if (b.activo !== undefined) {
      let prox = p.proxima_ejecucion;
      if (b.activo && new Date(prox.replace(" ", "T")) <= new Date()) prox = fmt(proxima(String(p.hora).slice(0, 5)));
      await db.ejecutar("UPDATE riegos_programados SET activo = ?, proxima_ejecucion = ? WHERE id = ?", [b.activo ? 1 : 0, prox, p.id]);
    }
    await auditar(req, "EDITAR_PROGRAMACION", "riegos_programados", p.id, JSON.stringify(b));
    emitir("programados", {});
    res.json({ ok: true });
  });

  app.delete("/api/programados/:id", requiere("riego.programar"), async (req, res) => {
    const p = await db.uno("SELECT * FROM riegos_programados WHERE id = ?", [Number(req.params.id)]);
    if (!p) throw new HttpError(404, "Programación no encontrada");
    await exigirSector(req, p.sector_id);
    await db.ejecutar("DELETE FROM riegos_programados WHERE id = ?", [p.id]);
    await auditar(req, "ELIMINAR_PROGRAMACION", "riegos_programados", p.id);
    emitir("programados", {});
    res.json({ ok: true });
  });
};

module.exports.proxima = proxima;

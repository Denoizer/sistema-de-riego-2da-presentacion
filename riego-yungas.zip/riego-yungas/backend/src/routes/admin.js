// Administración: usuarios, roles, configuración, horarios, reglas, IA y auditoría
const db = require("../db");
const config = require("../config");
const { requiere, tiene } = require("../auth/middleware");
const { HttpError } = require("../http/app");
const { ahora } = require("../util/tiempo");
const { hashPassword, claveValida } = require("../auth/password");
const { auditar } = require("../servicios/auditoria");
const iaSector = require("../ia/sector");
const iaClima = require("../ia/clima");
const crypto = require("crypto");

const CORREO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

module.exports = app => {
  // ------------------------------ USUARIOS -----------------------------
  app.get("/api/usuarios", requiere("usuarios.gestionar"), async (req, res) => {
    const usuarios = await db.q(
      `SELECT u.id, u.usuario, u.nombre, u.apellido, u.correo, u.telefono, u.activo, u.ultimo_acceso, u.creado_en, u.rol_id, r.codigo rol, r.nombre rol_nombre
         FROM usuarios u JOIN roles r ON r.id = u.rol_id ORDER BY r.id, u.id`);
    const asign = await db.q("SELECT us.usuario_id, us.sector_id, s.codigo FROM usuario_sector us JOIN sectores s ON s.id = us.sector_id ORDER BY s.id");
    for (const u of usuarios) {
      const mios = asign.filter(a => a.usuario_id === u.id);
      u.sectores = mios.map(a => a.sector_id);
      u.sectores_codigos = mios.map(a => a.codigo);
    }
    res.json(usuarios);
  });

  async function guardarSectores(usuario_id, rol_id, sectores) {
    await db.ejecutar("DELETE FROM usuario_sector WHERE usuario_id = ?", [usuario_id]);
    const rol = await db.uno("SELECT codigo FROM roles WHERE id = ?", [rol_id]);
    if (rol.codigo !== "agricultor" || !Array.isArray(sectores)) return;
    const validos = (await db.q("SELECT id FROM sectores")).map(x => x.id);
    for (const sid of [...new Set(sectores.map(Number))].filter(x => validos.includes(x)))
      await db.ejecutar("INSERT INTO usuario_sector (usuario_id, sector_id) VALUES (?, ?)", [usuario_id, sid]);
  }

  app.get("/api/roles", requiere("usuarios.gestionar"), async (req, res) => {
    const roles = await db.q("SELECT * FROM roles ORDER BY id");
    const permisos = await db.q("SELECT * FROM permisos ORDER BY modulo, id");
    const rp = await db.q("SELECT rol_id, permiso_id FROM rol_permiso");
    res.json({ roles, permisos, matriz: rp });
  });

  app.post("/api/usuarios", requiere("usuarios.gestionar"), async (req, res) => {
    const b = req.body;
    const usuario = String(b.usuario || "").trim().toLowerCase();
    if (!/^[a-z0-9._-]{3,40}$/.test(usuario)) throw new HttpError(400, "El usuario debe tener 3–40 caracteres (letras, números, punto o guion)");
    if (!b.nombre || !b.apellido) throw new HttpError(400, "Ingrese nombre y apellido");
    if (!CORREO.test(b.correo || "")) throw new HttpError(400, "Ingrese un correo válido");
    if (!claveValida(b.clave)) throw new HttpError(400, "La contraseña debe tener al menos 8 caracteres, una mayúscula, una minúscula y un número");
    const rol = await db.uno("SELECT id FROM roles WHERE id = ?", [Number(b.rol_id)]);
    if (!rol) throw new HttpError(400, "Rol no válido");
    const dup = await db.uno("SELECT id FROM usuarios WHERE usuario = ? OR correo = ?", [usuario, b.correo.toLowerCase()]);
    if (dup) throw new HttpError(409, "Ya existe un usuario con este nombre de usuario o correo");
    const r = await db.ejecutar(
      "INSERT INTO usuarios (rol_id, usuario, nombre, apellido, correo, telefono, password_hash, creado_en, actualizado_en) VALUES (?,?,?,?,?,?,?,?,?)",
      [rol.id, usuario, b.nombre.trim(), b.apellido.trim(), b.correo.toLowerCase(), b.telefono || null, hashPassword(b.clave), ahora(), ahora()]);
    await guardarSectores(r.insertId, rol.id, b.sectores);
    await auditar(req, "CREAR_USUARIO", "usuarios", r.insertId, usuario);
    res.json({ ok: true, id: r.insertId });
  });

  app.put("/api/usuarios/:id", requiere("usuarios.gestionar"), async (req, res) => {
    const id = Number(req.params.id);
    const u = await db.uno("SELECT * FROM usuarios WHERE id = ?", [id]);
    if (!u) throw new HttpError(404, "Usuario no encontrado");
    const b = req.body;
    if (b.correo !== undefined && !CORREO.test(b.correo)) throw new HttpError(400, "Ingrese un correo válido");
    if (id === req.usuario.id && (b.activo === false || (b.rol_id && Number(b.rol_id) !== u.rol_id)))
      throw new HttpError(409, "No puede desactivarse ni cambiar su propio rol");
    if (b.correo && (await db.uno("SELECT id FROM usuarios WHERE correo = ? AND id <> ?", [b.correo.toLowerCase(), id])))
      throw new HttpError(409, "Ya existe un usuario con este correo");
    await db.ejecutar("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, telefono = ?, rol_id = ?, activo = ?, actualizado_en = ? WHERE id = ?",
      [b.nombre ?? u.nombre, b.apellido ?? u.apellido, (b.correo ?? u.correo).toLowerCase(), b.telefono ?? u.telefono,
       b.rol_id ? Number(b.rol_id) : u.rol_id, b.activo === undefined ? u.activo : b.activo ? 1 : 0, ahora(), id]);
    if (b.clave) {
      if (!claveValida(b.clave)) throw new HttpError(400, "La contraseña debe tener al menos 8 caracteres, una mayúscula, una minúscula y un número");
      await db.ejecutar("UPDATE usuarios SET password_hash = ?, intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id = ?", [hashPassword(b.clave), id]);
    }
    if (b.sectores !== undefined || b.rol_id) await guardarSectores(id, b.rol_id ? Number(b.rol_id) : u.rol_id, b.sectores);
    await auditar(req, "EDITAR_USUARIO", "usuarios", id, JSON.stringify({ ...b, clave: b.clave ? "***" : undefined }));
    res.json({ ok: true });
  });

  app.delete("/api/usuarios/:id", requiere("usuarios.gestionar"), async (req, res) => {
    const id = Number(req.params.id);
    if (id === req.usuario.id) throw new HttpError(409, "No puede eliminar su propia cuenta");
    const u = await db.uno("SELECT u.usuario, r.codigo rol FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE u.id = ?", [id]);
    if (!u) throw new HttpError(404, "Usuario no encontrado");
    if (u.rol === "admin") {
      const n = await db.uno("SELECT COUNT(*) n FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE r.codigo = 'admin' AND u.activo = 1");
      if (n.n <= 1) throw new HttpError(409, "Debe quedar al menos un administrador activo");
    }
    await db.ejecutar("DELETE FROM usuarios WHERE id = ?", [id]);
    await auditar(req, "ELIMINAR_USUARIO", "usuarios", id, u.usuario);
    res.json({ ok: true });
  });

  // --------------------------- CONFIGURACIÓN ---------------------------
  app.get("/api/config", requiere("riego.configurar", "sectores.configurar"), async (req, res) => {
    const filas = await db.q("SELECT * FROM configuracion ORDER BY clave");
    const horarios = await db.q("SELECT id, hora, activo FROM horarios_riego ORDER BY hora");
    const cultivos = await db.q("SELECT * FROM cultivos ORDER BY id");
    const tanque = await db.uno("SELECT capacidad_l, umbral_min_pct, umbral_max_pct, caudal_entrada_ls FROM tanques WHERE id = 1");
    const esAdmin = tiene(req, "sectores.configurar");
    res.json({ parametros: filas.map(f => ({ ...f, editable: esAdmin || f.editable_por === "agricultor" })), horarios, cultivos, tanque, simulador: config.simulador, aceleracion: config.acel });
  });

  app.put("/api/config", requiere("riego.configurar", "sectores.configurar"), async (req, res) => {
    const esAdmin = tiene(req, "sectores.configurar");
    const cambios = req.body.parametros || {};
    const limites = { max_min_riego: [5, 600], evaluacion_continua_min: [1, 240], lamina_minima_mm: [0.1, 20], posponer_horas: [1, 48], lluvia_intensa_mm: [5, 200], bateria_min_v: [10, 13], nodo_timeout_min: [1, 120] };
    for (const [clave, valor] of Object.entries(cambios)) {
      const f = await db.uno("SELECT * FROM configuracion WHERE clave = ?", [clave]);
      if (!f) throw new HttpError(400, `Parámetro desconocido: ${clave}`);
      if (!esAdmin && f.editable_por !== "agricultor") throw new HttpError(403, `Solo el administrador puede cambiar «${clave}»`);
      let v = String(valor);
      if (f.tipo === "booleano") v = valor === true || valor === "1" || valor === 1 ? "1" : "0";
      if (f.tipo === "numero") {
        const n = Number(valor);
        if (!Number.isFinite(n)) throw new HttpError(400, `Valor inválido para ${clave}`);
        if (limites[clave] && (n < limites[clave][0] || n > limites[clave][1])) throw new HttpError(400, `${clave} debe estar entre ${limites[clave][0]} y ${limites[clave][1]}`);
        v = String(n);
      }
      await db.ejecutar("UPDATE configuracion SET valor = ? WHERE clave = ?", [v, clave]);
    }
    if (req.body.horarios) {
      const hs = req.body.horarios;
      if (!Array.isArray(hs) || hs.length > 4) throw new HttpError(400, "Se permiten hasta 4 horarios de evaluación");
      for (const h of hs) if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(h)) throw new HttpError(400, `Hora inválida: ${h}`);
      await db.ejecutar("DELETE FROM horarios_riego");
      for (const h of hs) await db.ejecutar("INSERT INTO horarios_riego (hora, activo) VALUES (?, 1)", [h + ":00"]);
    }
    if (req.body.tanque) {
      if (!esAdmin) throw new HttpError(403, "Solo el administrador configura el tanque");
      const t = req.body.tanque;
      if (!(t.umbral_min_pct >= 5 && t.umbral_max_pct <= 100 && t.umbral_min_pct < t.umbral_max_pct)) throw new HttpError(400, "Umbrales del tanque no válidos");
      await db.ejecutar("UPDATE tanques SET umbral_min_pct = ?, umbral_max_pct = ? WHERE id = 1", [t.umbral_min_pct, t.umbral_max_pct]);
      await db.ejecutar("UPDATE reglas_automatizacion SET valor = ? WHERE codigo = 'LLENADO_AUTO'", [t.umbral_min_pct]);
    }
    await auditar(req, "CAMBIAR_CONFIG", "configuracion", null, JSON.stringify(req.body));
    res.json({ ok: true });
  });

  // Cultivos (Kc FAO-56)
  app.put("/api/cultivos/:id", requiere("sectores.configurar"), async (req, res) => {
    const b = req.body;
    for (const k of ["kc_inicial", "kc_medio", "kc_final"]) if (!(Number(b[k]) >= 0.2 && Number(b[k]) <= 1.3)) throw new HttpError(400, "Kc debe estar entre 0,2 y 1,3");
    if (!(Number(b.kr) >= 0.1 && Number(b.kr) <= 1)) throw new HttpError(400, "Kr debe estar entre 0,1 y 1,0");
    if (!(Number(b.prof_raiz_m) > 0.1 && Number(b.p_agotamiento) > 0 && Number(b.p_agotamiento) < 0.8)) throw new HttpError(400, "Profundidad radicular o fracción p no válida");
    await db.ejecutar("UPDATE cultivos SET kc_inicial=?, kc_medio=?, kc_final=?, kr=?, prof_raiz_m=?, p_agotamiento=? WHERE id = ?",
      [b.kc_inicial, b.kc_medio, b.kc_final, b.kr, b.prof_raiz_m, b.p_agotamiento, Number(req.params.id)]);
    // Recalcula el umbral agronómico de los sectores con ese cultivo
    const sectores = await db.q("SELECT s.id, su.theta_cc, su.theta_pmp FROM sectores s JOIN suelos su ON su.id = s.suelo_id WHERE s.cultivo_id = ?", [Number(req.params.id)]);
    for (const s of sectores) {
      const u = Math.round((s.theta_cc - b.p_agotamiento * (s.theta_cc - s.theta_pmp)) * 1000) / 1000;
      await db.ejecutar("UPDATE sectores SET umbral_base = ?, umbral_humedad = ? WHERE id = ?", [u, u, s.id]);
    }
    await auditar(req, "EDITAR_CULTIVO", "cultivos", req.params.id, JSON.stringify(b));
    res.json({ ok: true });
  });

  // Nuevo sector (RNF-09: escalable sin modificar código)
  app.post("/api/sectores", requiere("sectores.configurar"), async (req, res) => {
    const b = req.body;
    const cultivo = await db.uno("SELECT * FROM cultivos WHERE id = ?", [Number(b.cultivo_id)]);
    if (!cultivo) throw new HttpError(400, "Cultivo no válido");
    if (!(b.area_ha > 0 && b.n_plantas > 0 && b.goteros_por_planta > 0 && b.caudal_gotero_lh > 0)) throw new HttpError(400, "Área, plantas, goteros y caudal deben ser mayores a cero");
    const n = await db.uno("SELECT COUNT(*) n FROM sectores");
    const codigo = "S" + (n.n + 1);
    const suelo = await db.uno("SELECT * FROM suelos WHERE id = 1");
    const umbral = Math.round((suelo.theta_cc - cultivo.p_agotamiento * (suelo.theta_cc - suelo.theta_pmp)) * 1000) / 1000;
    const caudal = b.n_plantas * b.goteros_por_planta * b.caudal_gotero_lh;
    const r = await db.ejecutar(
      `INSERT INTO sectores (finca_id, codigo, nombre, cultivo_id, suelo_id, area_ha, n_plantas, goteros_por_planta, caudal_gotero_lh, caudal_nominal_lh, eficiencia, fraccion_humedecida, umbral_base, umbral_humedad)
       VALUES (1,?,?,?,1,?,?,?,?,?,0.90,0.50,?,?)`,
      [codigo, b.nombre || `Sector ${n.n + 1} – ${cultivo.nombre}`, cultivo.id, b.area_ha, b.n_plantas, b.goteros_por_planta, b.caudal_gotero_lh, caudal, umbral, umbral]);
    const nodo = await db.ejecutar("INSERT INTO nodos (codigo, tipo, sector_id, descripcion, api_key, firmware, en_linea) VALUES (?, 'sector', ?, ?, ?, 'v1.0.3', 0)",
      [`N-${codigo}`, r.insertId, `Nodo ESP32 + LoRa – ${codigo}`, crypto.randomBytes(12).toString("hex")]);
    for (const pos of ["H1", "H2", "H3"])
      await db.ejecutar("INSERT INTO sensores (nodo_id, tipo, posicion, modelo, unidad, adc_seco, adc_saturado, rango_min, rango_max) VALUES (?, 'humedad', ?, 'Capacitivo v1.2', 'm³/m³', 3200, 1380, 0.05, 0.50)", [nodo.insertId, pos]);
    await db.ejecutar("INSERT INTO sensores (nodo_id, tipo, posicion, modelo, unidad, rango_min, rango_max) VALUES (?, 'temp_suelo', 'T1', 'DS18B20', '°C', -5, 50)", [nodo.insertId]);
    await db.ejecutar("INSERT INTO sensores (nodo_id, tipo, posicion, modelo, unidad, rango_min, rango_max) VALUES (?, 'caudal', 'Q1', 'YF-DN40', 'L/min', 0, 400)", [nodo.insertId]);
    await db.ejecutar("INSERT INTO modelos_ia (tipo, sector_id, algoritmo, version, fase) VALUES ('sector', ?, 'Regresión lineal en línea (SGD)', 1, 'observacion')", [r.insertId]);
    await auditar(req, "CREAR_SECTOR", "sectores", r.insertId, codigo);
    if (config.simulador) await require("../motor/simulador").recargar();
    res.json({ ok: true, id: r.insertId, codigo });
  });

  // ------------------------- REGLAS (AUTOMATIZACIÓN) -------------------
  app.get("/api/reglas", requiere("automatizacion.gestionar"), async (req, res) => {
    res.json(await db.q("SELECT * FROM reglas_automatizacion ORDER BY id"));
  });
  app.put("/api/reglas/:id", requiere("automatizacion.gestionar"), async (req, res) => {
    const id = Number(req.params.id);
    const r = await db.uno("SELECT * FROM reglas_automatizacion WHERE id = ?", [id]);
    if (!r) throw new HttpError(404, "Regla no encontrada");
    const activa = req.body.activa === undefined ? r.activa : req.body.activa ? 1 : 0;
    let valor = r.valor;
    if (req.body.valor !== undefined && r.valor !== null) {
      valor = Number(req.body.valor);
      if (!Number.isFinite(valor) || valor < 0) throw new HttpError(400, "Valor no válido");
      if (r.unidad === "%" && valor > 100) throw new HttpError(400, "El porcentaje no puede superar 100");
    }
    await db.ejecutar("UPDATE reglas_automatizacion SET activa = ?, valor = ?, actualizado_en = ? WHERE id = ?", [activa, valor, ahora(), id]);
    await auditar(req, "EDITAR_REGLA", "reglas_automatizacion", id, `${r.codigo}: activa=${activa}, valor=${valor}`);
    res.json({ ok: true });
  });

  // -------------------------------- IA ---------------------------------
  app.get("/api/ia/modelos", requiere("ia.ver"), async (req, res) => {
    const modelos = await db.q("SELECT m.*, s.codigo sector FROM modelos_ia m LEFT JOIN sectores s ON s.id = m.sector_id ORDER BY m.tipo, m.sector_id");
    const muestras = await db.q("SELECT sector_id, COUNT(*) n, SUM(CASE WHEN humedad_objetivo IS NULL THEN 1 ELSE 0 END) pendientes FROM muestras_ia GROUP BY sector_id");
    const ultimas = await db.q(
      `SELECT mu.sector_id, mu.fecha, mu.humedad, mu.humedad_objetivo FROM muestras_ia mu
        WHERE mu.humedad_objetivo IS NOT NULL ORDER BY mu.fecha DESC LIMIT 200`);
    for (const m of modelos) {
      try { m.parametros = m.parametros ? JSON.parse(m.parametros) : null; } catch { m.parametros = null; }
      const mu = muestras.find(x => x.sector_id === m.sector_id);
      m.muestras_total = mu ? mu.n : 0; m.muestras_pendientes = mu ? mu.pendientes : 0;
    }
    res.json({ modelos, ultimas: ultimas.reverse() });
  });
  app.post("/api/ia/reentrenar", requiere("ia.reentrenar"), async (req, res) => {
    const sectores = await db.q("SELECT id FROM sectores WHERE activo = 1");
    const r = {};
    for (const s of sectores) r[s.id] = await iaSector.reentrenar(s.id);
    r.clima = await iaClima.generar();
    await auditar(req, "REENTRENAR_IA", "modelos_ia");
    res.json(r);
  });

  // ----------------------------- AUDITORÍA -----------------------------
  app.get("/api/auditoria", requiere("auditoria.ver"), async (req, res) => {
    res.json(await db.q(
      `SELECT a.id, a.accion, a.entidad, a.entidad_id, a.detalle, a.ip, a.fecha, u.usuario
         FROM auditoria a LEFT JOIN usuarios u ON u.id = a.usuario_id ORDER BY a.fecha DESC, a.id DESC LIMIT 300`));
  });
};

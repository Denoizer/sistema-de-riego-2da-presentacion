// API para el hardware real (nodos ESP32 / unidad central). Autenticación por
// cabecera X-Api-Key con la clave de cada nodo (tabla nodos.api_key).
const db = require("../db");
const { HttpError } = require("../http/app");
const { ahora } = require("../util/tiempo");
const ingesta = require("../motor/ingesta");

async function nodoPorClave(req) {
  const clave = req.headers["x-api-key"];
  const n = clave ? await db.uno("SELECT * FROM nodos WHERE api_key = ?", [clave]) : null;
  if (!n) throw new HttpError(401, "Clave de dispositivo no válida");
  return n;
}

module.exports = app => {
  // Nodo de sector: { h:[0.25,0.26,0.25], temp: 18.2, caudal: 0, litros: 0, bateria: 12.8, rssi: -95 }
  // Nodo de tanque: { nivel_l: 34600, caudal_salida: 0 }
  // Unidad central: { temp_c, hr_pct, presion_kpa, viento_ms, radiacion_wm2, lluvia_mm }
  app.post("/api/iot/lecturas", async (req, res) => {
    const n = await nodoPorClave(req);
    const b = req.body;
    if (n.tipo === "sector") {
      if (!Array.isArray(b.h)) throw new HttpError(400, "Se requiere el arreglo h con las humedades");
      await ingesta.lecturaSector({ sector_id: n.sector_id, h: b.h.map(Number), temp: Number(b.temp), caudal: Number(b.caudal) || 0, litros: Number(b.litros) || 0, bateria: Number(b.bateria), rssi: b.rssi === undefined ? null : Number(b.rssi) });
    } else if (n.tipo === "tanque") {
      await ingesta.lecturaTanque({ nivel_l: Number(b.nivel_l), caudal_salida: Number(b.caudal_salida) || 0 });
    } else {
      await ingesta.lecturaEstacion({ temp_c: Number(b.temp_c), hr_pct: Number(b.hr_pct), presion_kpa: Number(b.presion_kpa), viento_ms: Number(b.viento_ms), radiacion_wm2: Number(b.radiacion_wm2), lluvia_mm: Number(b.lluvia_mm) || 0 });
    }
    res.json({ ok: true, hora_servidor: ahora() });
  });

  // Eventos del nodo de sector: { tipo: "FIN_RIEGO" | "SIN_CAUDAL", litros }
  app.post("/api/iot/eventos", async (req, res) => {
    const n = await nodoPorClave(req);
    if (n.tipo !== "sector") throw new HttpError(400, "Solo los nodos de sector envían eventos");
    await ingesta.eventoSector({ sector_id: n.sector_id, tipo: req.body.tipo, litros: Number(req.body.litros) || 0 });
    res.json({ ok: true });
  });

  // El nodo consulta sus comandos pendientes
  app.get("/api/iot/comandos", async (req, res) => {
    const n = await nodoPorClave(req);
    const cmds = await db.q("SELECT id, accion, litros, minutos FROM comandos WHERE nodo_id = ? AND estado = 'pendiente' ORDER BY id", [n.id]);
    for (const c of cmds) await db.ejecutar("UPDATE comandos SET estado = 'enviado' WHERE id = ?", [c.id]);
    res.json(cmds);
  });

  app.post("/api/iot/comandos/:id/ack", async (req, res) => {
    const n = await nodoPorClave(req);
    await db.ejecutar("UPDATE comandos SET estado = 'ejecutado', ejecutado_en = ? WHERE id = ? AND nodo_id = ?", [ahora(), Number(req.params.id), n.id]);
    res.json({ ok: true });
  });
};

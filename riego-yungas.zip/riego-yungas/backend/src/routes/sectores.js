// Panel de control, sectores, tanque y riego manual
const db = require("../db");
const config = require("../config");
const { requiere, tiene } = require("../auth/middleware");
const { HttpError } = require("../http/app");
const { ahora, hace, fecha } = require("../util/tiempo");
const estado = require("../motor/estado");
const { cargarSector, riegoEnCurso, iniciarRiego, detenerRiego } = require("../motor/riego");
const { evaluarSector, calcularPlan } = require("../motor/decision");
const { enviarComando, nodoTanque } = require("../motor/comandos");
const { etoReferencia } = require("../motor/eto");
const { obtenerConfig } = require("../servicios/config");
const { auditar } = require("../servicios/auditoria");
const { emitir } = require("../servicios/notificador");
const iaClima = require("../ia/clima");
const iaSector = require("../ia/sector");
const { sectoresPermitidos, exigirSector } = require("../auth/acceso");

async function resumenSector(s, eto) {
  const st = estado.sectores.get(s.id) || {};
  const ult = st.humedad === undefined
    ? await db.uno("SELECT humedad_prom, temp_suelo, fecha FROM lecturas_sector WHERE sector_id = ? ORDER BY fecha DESC LIMIT 1", [s.id])
    : null;
  const riego = await riegoEnCurso(s.id);
  const nodo = await db.uno("SELECT id, codigo, bateria_v, rssi_dbm, en_linea, ultima_conexion FROM nodos WHERE sector_id = ? AND tipo = 'sector'", [s.id]);
  const etcLoc = s.kc * s.factor_kc_ia * eto * s.kr;
  const humedad = st.humedad !== undefined ? st.humedad : ult ? ult.humedad_prom : null;
  let progreso = null;
  if (riego) {
    const litros = Math.max(riego.litros_reales, st.litros || 0);
    const caudal = st.caudal || 0;
    progreso = {
      id: riego.id, tipo: riego.tipo, inicio: riego.inicio, motivo: riego.motivo_codigo, motivo_desc: riego.motivo_desc,
      litros, litros_plan: riego.litros_plan, caudal_lmin: caudal,
      min_restantes: caudal > 0 ? Math.max(0, (riego.litros_plan - litros) / caudal) : null,
      duracion_plan_min: riego.duracion_plan_min, pct: Math.min(100, (litros / riego.litros_plan) * 100),
    };
  }
  const ultDecision = await db.uno(
    "SELECT d.decision, d.detalle, d.fecha, m.codigo, m.descripcion FROM decisiones d JOIN motivos m ON m.id = d.motivo_id WHERE d.sector_id = ? ORDER BY d.fecha DESC, d.id DESC LIMIT 1", [s.id]);
  return {
    id: s.id, codigo: s.codigo, nombre: s.nombre, cultivo: s.cultivo, area_ha: s.area_ha, modo: s.modo, estado: s.estado,
    humedad, h: st.h || null, temp_suelo: st.temp ?? (ult ? ult.temp_suelo : null), caudal_lmin: st.caudal || 0,
    umbral: s.umbral_humedad, umbral_base: s.umbral_base, theta_cc: s.theta_cc, theta_pmp: s.theta_pmp,
    deficit_mm: s.deficit_mm, etc_loc_mm: etcLoc, kc: s.kc, kr: s.kr, factor_kc_ia: s.factor_kc_ia,
    caudal_nominal_lh: s.caudal_nominal_lh, pospuesto_hasta: s.pospuesto_hasta, ultimo_riego: s.ultimo_riego,
    nodo, riego: progreso, ultima_decision: ultDecision,
  };
}

async function listaSectores(req = null) {
  const eto = await etoReferencia();
  const permitidos = req ? await sectoresPermitidos(req) : null;
  const todos = await db.q(
    `SELECT s.*, c.nombre AS cultivo, c.kc_medio AS kc, c.kr, c.prof_raiz_m, su.theta_cc, su.theta_pmp
       FROM sectores s JOIN cultivos c ON c.id = s.cultivo_id JOIN suelos su ON su.id = s.suelo_id WHERE s.activo = 1 ORDER BY s.id`);
  const sectores = permitidos ? todos.filter(s => permitidos.includes(s.id)) : todos;
  const res = [];
  for (const s of sectores) res.push(await resumenSector(s, eto));
  return res;
}

async function sqlRiegoEnCurso() {
  return db.q(`SELECT r.*, m.codigo motivo_codigo, m.descripcion motivo_desc FROM riegos r JOIN motivos m ON m.id = r.motivo_id WHERE r.estado = 'en_curso'`);
}

async function datosTanque() {
  const t = await db.uno("SELECT * FROM tanques WHERE id = 1");
  const pct = (t.nivel_l / t.capacidad_l) * 100;
  const hace1h = await db.uno("SELECT nivel_l FROM lecturas_tanque WHERE fecha <= ? ORDER BY fecha DESC LIMIT 1", [hace(config.simulador ? 2 : 60)]);
  const tendencia = hace1h ? t.nivel_l - hace1h.nivel_l : 0;
  return {
    ...t, porcentaje: pct, caudal_salida_lmin: estado.tanque.caudal_salida || 0,
    tendencia: tendencia > 50 ? "subiendo" : tendencia < -50 ? "bajando" : "estable",
    situacion: pct < t.umbral_min_pct ? "REQUIERE LLENADO" : t.llenando ? "LLENANDO" : "NORMAL",
  };
}

module.exports = app => {
  // ------------------------------- PANEL -------------------------------
  app.get("/api/panel", requiere("dashboard.ver"), async (req, res) => {
    const enCurso = await sqlRiegoEnCurso();
    const sectores = await listaSectores(req);
    for (const s of sectores) if (s.riego) {
      const r = enCurso.find(x => x.sector_id === s.id);
      if (r) { s.riego.motivo = r.motivo_codigo; s.riego.motivo_desc = r.motivo_desc; }
    }
    const pron = await iaClima.resumen(24);
    const hoy = fecha(new Date());
    const consumo = await db.uno("SELECT COALESCE(SUM(litros_reales),0) litros, COUNT(*) n FROM riegos WHERE inicio >= ?", [hoy + " 00:00:00"]);
    const alertas = await db.q(
      `SELECT t.severidad, COUNT(*) n FROM alertas a JOIN tipos_alerta t ON t.id = a.tipo_alerta_id WHERE a.atendida = 0 GROUP BY t.severidad`);
    // Fallas activas del sistema de riego (visibles para admin, técnico y el agricultor a cargo)
    const permitidos = await sectoresPermitidos(req);
    const fallas = (await db.q(
      `SELECT a.id, t.codigo, t.nombre, t.severidad, a.mensaje, a.fecha, a.sector_id, s.codigo sector, n.codigo nodo
         FROM alertas a JOIN tipos_alerta t ON t.id = a.tipo_alerta_id LEFT JOIN sectores s ON s.id = a.sector_id LEFT JOIN nodos n ON n.id = a.nodo_id
        WHERE a.atendida = 0 AND t.codigo IN ('A-02','A-03','A-04','A-05','A-06','A-07','A-08') ORDER BY a.fecha DESC`))
      .filter(f => !permitidos || f.sector_id === null || permitidos.includes(f.sector_id));
    const responsables = await db.q("SELECT us.sector_id, CONCAT(u.nombre, ' ', u.apellido) nombre FROM usuario_sector us JOIN usuarios u ON u.id = us.usuario_id WHERE u.activo = 1");
    for (const f of fallas) f.agricultores = responsables.filter(r => r.sector_id === f.sector_id).map(r => r.nombre).join(", ");
    const nodos = await db.q("SELECT id, codigo, tipo, sector_id, bateria_v, rssi_dbm, en_linea, ultima_conexion, firmware FROM nodos ORDER BY id");
    const cfg = await obtenerConfig();
    const diario = await db.q("SELECT fecha, eto_mm, lluvia_mm, tmax, tmin FROM clima_diario ORDER BY fecha DESC LIMIT 7");
    res.json({
      fecha: ahora(), simulador: config.simulador, aceleracion: config.simulador ? config.acel : 1,
      riego_automatico: !!cfg.riego_automatico,
      tanque: await datosTanque(),
      clima: { ...estado.clima, eto_ref: await etoReferencia(), diario: diario.reverse() },
      pronostico_24h: pron, clima_externo: await iaClima.actualExterno(),
      sectores, consumo_hoy: consumo, fallas,
      alertas: Object.fromEntries(alertas.map(a => [a.severidad, a.n])),
      nodos: tiene(req, "sensores.ver") ? nodos : undefined,
      nodos_en_linea: nodos.filter(n => n.en_linea).length, nodos_total: nodos.length,
    });
  });

  // ------------------------------ SECTORES -----------------------------
  app.get("/api/sectores", requiere("sectores.ver"), async (req, res) => {
    const enCurso = await sqlRiegoEnCurso();
    const sectores = await listaSectores(req);
    for (const s of sectores) if (s.riego) {
      const r = enCurso.find(x => x.sector_id === s.id);
      if (r) { s.riego.motivo = r.motivo_codigo; s.riego.motivo_desc = r.motivo_desc; }
    }
    res.json(sectores);
  });

  app.get("/api/sectores/:id", requiere("sectores.ver"), async (req, res) => {
    const id = Number(req.params.id);
    await exigirSector(req, id);
    const s = await db.uno(
      `SELECT s.*, c.nombre AS cultivo, c.kc_medio AS kc, c.kr, c.prof_raiz_m, c.p_agotamiento, su.theta_cc, su.theta_pmp, su.textura
         FROM sectores s JOIN cultivos c ON c.id = s.cultivo_id JOIN suelos su ON su.id = s.suelo_id WHERE s.id = ?`, [id]);
    if (!s) throw new HttpError(404, "Sector no encontrado");
    const eto = await etoReferencia();
    const resumen = await resumenSector(s, eto);
    const enCurso = (await sqlRiegoEnCurso()).find(x => x.sector_id === id);
    if (resumen.riego && enCurso) { resumen.riego.motivo = enCurso.motivo_codigo; resumen.riego.motivo_desc = enCurso.motivo_desc; }
    const horas = Math.min(168, Number(req.query.horas) || 48);
    const serie = await db.q("SELECT fecha, humedad_prom, humedad_1, humedad_2, humedad_3, temp_suelo, caudal_lmin FROM lecturas_sector WHERE sector_id = ? AND fecha >= ? ORDER BY fecha", [id, hace(horas * 60)]);
    const riegos = await db.q(
      `SELECT r.id, r.tipo, r.inicio, r.fin, r.litros_plan, r.litros_reales, r.duracion_plan_min, r.estado, m.codigo motivo, m.descripcion motivo_desc
         FROM riegos r JOIN motivos m ON m.id = r.motivo_id WHERE r.sector_id = ? ORDER BY r.inicio DESC LIMIT 10`, [id]);
    const decisiones = await db.q(
      `SELECT d.fecha, d.decision, d.humedad, d.umbral, d.etc_loc_mm, d.lluvia_prevista_mm, d.prob_lluvia, d.humedad_pred_24h, d.detalle, m.codigo
         FROM decisiones d JOIN motivos m ON m.id = d.motivo_id WHERE d.sector_id = ? ORDER BY d.fecha DESC, d.id DESC LIMIT 15`, [id]);
    const sensores = await db.q("SELECT se.id, se.tipo, se.posicion, se.modelo, se.unidad, se.ultimo_valor, se.estado, se.ultima_calibracion FROM sensores se JOIN nodos n ON n.id = se.nodo_id WHERE n.sector_id = ?", [id]);
    const cfg = await obtenerConfig();
    const plan = resumen.humedad !== null ? calcularPlan({ ...s, deficit_mm: s.deficit_mm }, resumen.humedad, resumen.etc_loc_mm, cfg) : null;
    const modelo = await iaSector.modelo(id);
    const pred24 = resumen.humedad !== null ? await iaSector.predecir(id, { humedad: resumen.humedad, etcLoc: resumen.etc_loc_mm, temp: resumen.temp_suelo, lluvia: 0, horas: 24 }) : null;
    res.json({
      ...resumen, textura: s.textura, prof_raiz_m: s.prof_raiz_m, p_agotamiento: s.p_agotamiento, n_plantas: s.n_plantas,
      goteros_por_planta: s.goteros_por_planta, caudal_gotero_lh: s.caudal_gotero_lh, eficiencia: s.eficiencia,
      fraccion_humedecida: s.fraccion_humedecida, eto_ref: eto, plan,
      ia: modelo ? { fase: modelo.fase, n_muestras: modelo.n_muestras, mae: modelo.mae, version: modelo.version, humedad_pred_24h: pred24 } : null,
      serie, riegos, decisiones, sensores,
    });
  });

  // Riego manual (HU-13): por litros o por minutos
  app.post("/api/sectores/:id/riego-manual", requiere("riego.manual"), async (req, res) => {
    const id = Number(req.params.id);
    await exigirSector(req, id);
    const s = await cargarSector(id);
    if (!s) throw new HttpError(404, "Sector no encontrado");
    const cfg = await obtenerConfig();
    const maxMin = cfg.max_min_riego || 180;
    let litros, minutos;
    if (req.body.litros !== undefined && req.body.litros !== null && req.body.litros !== "") {
      litros = Number(req.body.litros);
      const maxL = Math.floor((s.caudal_nominal_lh * maxMin) / 60);
      if (!Number.isFinite(litros) || litros < 100 || litros > maxL) throw new HttpError(400, `Los litros deben estar entre 100 y ${maxL.toLocaleString("es-BO")} L (máximo ${maxMin} min con ${s.caudal_nominal_lh.toLocaleString("es-BO")} L/h)`);
      minutos = (litros / s.caudal_nominal_lh) * 60;
    } else {
      minutos = Number(req.body.minutos);
      if (!Number.isFinite(minutos) || minutos < 5 || minutos > maxMin) throw new HttpError(400, `La duración debe estar entre 5 y ${maxMin} minutos`);
      litros = (s.caudal_nominal_lh * minutos) / 60;
    }
    if (s.modo === "mantenimiento" || s.estado === "mantenimiento") throw new HttpError(409, "El sector está en mantenimiento");
    if (s.estado === "falla") throw new HttpError(409, "El sector tiene una falla sin resolver. El técnico debe atender la alerta.");
    if (await riegoEnCurso(id)) throw new HttpError(409, "El sector ya se está regando");
    if (await riegoEnCurso()) throw new HttpError(409, "Otro sector se está regando. El riego es secuencial; espere a que termine o deténgalo.");
    const tq = await db.uno("SELECT nivel_l FROM tanques WHERE id = 1");
    if (tq.nivel_l < litros) throw new HttpError(409, `El tanque no tiene agua suficiente (disponible: ${Math.round(tq.nivel_l).toLocaleString("es-BO")} L, requerido: ${Math.round(litros).toLocaleString("es-BO")} L)`);
    const riegoId = await iniciarRiego(s, { tipo: "manual", motivo: "M-04", litros, lamina_mm: Math.round((litros / (s.area_ha * 10000)) * 100) / 100, max_min: Math.ceil(minutos * 1.3) + 1, usuario_id: req.usuario.id, detalleMotivo: `por ${req.usuario.nombre} ${req.usuario.apellido}` });
    await auditar(req, "RIEGO_MANUAL", "sectores", id, `${Math.round(litros)} L, ${Math.round(minutos)} min`);
    res.json({ ok: true, riego_id: riegoId, litros: Math.round(litros), minutos: Math.round(minutos * 10) / 10 });
  });

  app.post("/api/sectores/:id/detener", requiere("riego.manual"), async (req, res) => {
    const id = Number(req.params.id);
    await exigirSector(req, id);
    if (!(await riegoEnCurso(id))) throw new HttpError(409, "El sector no se está regando");
    await detenerRiego(id, req.usuario.id);
    await auditar(req, "DETENER_RIEGO", "sectores", id);
    res.json({ ok: true });
  });

  app.post("/api/sectores/:id/evaluar", requiere("riego.manual", "riego.configurar"), async (req, res) => {
    const id = Number(req.params.id);
    await exigirSector(req, id);
    const s = await cargarSector(id);
    if (s.estado === "pospuesto") await db.ejecutar("UPDATE sectores SET estado = 'reposo', pospuesto_hasta = NULL WHERE id = ?", [id]);
    const r = await evaluarSector(id, "manual");
    res.json({ decision: r || "sin_cambios" });
  });

  // Umbral y modo del sector (HU-16) – agricultor y administrador
  app.put("/api/sectores/:id/riego", requiere("riego.configurar"), async (req, res) => {
    const id = Number(req.params.id);
    await exigirSector(req, id);
    const s = await cargarSector(id);
    if (!s) throw new HttpError(404, "Sector no encontrado");
    const { umbral_humedad, modo } = req.body;
    if (umbral_humedad !== undefined) {
      const u = Number(umbral_humedad);
      if (!(u > s.theta_pmp && u < s.theta_cc)) throw new HttpError(400, `El umbral debe estar entre ${s.theta_pmp} (PMP) y ${s.theta_cc} (capacidad de campo)`);
      await db.ejecutar("UPDATE sectores SET umbral_humedad = ?, umbral_base = ? WHERE id = ?", [u, u, id]);
    }
    if (modo !== undefined) {
      if (!["automatico", "manual"].includes(modo)) throw new HttpError(400, "Modo no válido");
      if (s.modo === "mantenimiento") throw new HttpError(409, "El sector está en mantenimiento; solo el técnico puede rehabilitarlo");
      await db.ejecutar("UPDATE sectores SET modo = ? WHERE id = ?", [modo, id]);
    }
    await auditar(req, "CONFIG_RIEGO_SECTOR", "sectores", id, JSON.stringify(req.body));
    emitir("sector", { id });
    res.json({ ok: true });
  });

  // Configuración agronómica del sector (RF-27) – administrador
  app.put("/api/sectores/:id", requiere("sectores.configurar"), async (req, res) => {
    const id = Number(req.params.id);
    const b = req.body;
    const s = await db.uno("SELECT * FROM sectores WHERE id = ?", [id]);
    if (!s) throw new HttpError(404, "Sector no encontrado");
    const v = { ...s, ...b };
    if (!(v.area_ha > 0 && v.n_plantas > 0 && v.goteros_por_planta > 0 && v.caudal_gotero_lh > 0)) throw new HttpError(400, "Área, plantas, goteros y caudal deben ser mayores a cero");
    if (!(v.eficiencia > 0.5 && v.eficiencia <= 1)) throw new HttpError(400, "La eficiencia debe estar entre 0,5 y 1");
    const caudal = v.n_plantas * v.goteros_por_planta * v.caudal_gotero_lh;
    await db.ejecutar(
      "UPDATE sectores SET nombre = ?, cultivo_id = ?, area_ha = ?, n_plantas = ?, goteros_por_planta = ?, caudal_gotero_lh = ?, caudal_nominal_lh = ?, eficiencia = ?, fraccion_humedecida = ? WHERE id = ?",
      [v.nombre, v.cultivo_id, v.area_ha, v.n_plantas, v.goteros_por_planta, v.caudal_gotero_lh, caudal, v.eficiencia, v.fraccion_humedecida, id]);
    await auditar(req, "CONFIG_SECTOR", "sectores", id, JSON.stringify(b));
    if (config.simulador) await require("../motor/simulador").recargar();
    res.json({ ok: true, caudal_nominal_lh: caudal });
  });

  // ------------------------------- TANQUE ------------------------------
  app.get("/api/tanque", requiere("tanque.ver"), async (req, res) => {
    const horas = Math.min(168, Number(req.query.horas) || 24);
    const serie = await db.q("SELECT fecha, nivel_l, porcentaje, caudal_salida_lmin, llenando FROM lecturas_tanque WHERE fecha >= ? ORDER BY fecha", [hace(horas * 60)]);
    const hoy = fecha(new Date());
    const porSector = await db.q(
      `SELECT s.codigo, s.nombre, COALESCE(SUM(r.litros_reales),0) litros, COUNT(r.id) riegos,
              COALESCE(SUM(r.duracion_plan_min),0) minutos
         FROM sectores s LEFT JOIN riegos r ON r.sector_id = s.id AND r.inicio >= ? GROUP BY s.id, s.codigo, s.nombre ORDER BY s.id`, [hoy + " 00:00:00"]);
    res.json({ ...(await datosTanque()), serie, distribucion_hoy: porSector });
  });

  app.post("/api/tanque/llenado", requiere("tanque.operar"), async (req, res) => {
    const iniciar = !!req.body.iniciar;
    const tq = await db.uno("SELECT * FROM tanques WHERE id = 1");
    if (iniciar && tq.nivel_l >= tq.capacidad_l * (tq.umbral_max_pct / 100)) throw new HttpError(409, "El tanque ya está lleno");
    await enviarComando(await nodoTanque(), iniciar ? "llenar" : "detener_llenado", { usuario_id: req.usuario.id });
    await db.ejecutar("UPDATE tanques SET llenando = ?, llenado_desde = ?, nivel_inicio_llenado = ? WHERE id = 1",
      [iniciar ? 1 : 0, iniciar ? ahora() : null, iniciar ? tq.nivel_l : null]);
    await auditar(req, iniciar ? "LLENADO_MANUAL" : "DETENER_LLENADO", "tanques", 1);
    emitir("lectura", { tipo: "tanque" });
    res.json({ ok: true });
  });
};

module.exports.listaSectores = listaSectores;

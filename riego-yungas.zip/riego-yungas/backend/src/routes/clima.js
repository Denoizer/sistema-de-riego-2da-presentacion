// Clima actual, histórico diario, predicción IA y calculadora de ETo
const db = require("../db");
const { requiere } = require("../auth/middleware");
const { HttpError } = require("../http/app");
const { hace, diaDelAnio, parse } = require("../util/tiempo");
const estado = require("../motor/estado");
const { penmanMonteith, etoReferencia } = require("../motor/eto");
const iaClima = require("../ia/clima");
const { auditar } = require("../servicios/auditoria");

module.exports = app => {
  app.get("/api/clima", requiere("clima.ver"), async (req, res) => {
    const horas = Math.min(168, Number(req.query.horas) || 24);
    const serie = await db.q("SELECT fecha, temp_c, hr_pct, viento_ms, radiacion_wm2, lluvia_mm FROM lecturas_estacion WHERE fecha >= ? ORDER BY fecha", [hace(horas * 60)]);
    const diario = await db.q("SELECT * FROM clima_diario ORDER BY fecha DESC LIMIT 14");
    res.json({ actual: estado.clima, externo: await iaClima.actualExterno(), eto_ref: await etoReferencia(), serie, diario: diario.reverse() });
  });

  app.get("/api/clima/prediccion", requiere("clima.ver"), async (req, res) => {
    const s = await iaClima.serie();
    const resumenes = {};
    for (const h of [6, 24, 48, 72]) resumenes[h] = await iaClima.resumen(h);
    const modelo = await db.uno("SELECT algoritmo, version, fase, n_muestras, mae, parametros, entrenado_en FROM modelos_ia WHERE tipo = 'clima'");
    res.json({ ...s, resumenes, modelo, dias: await iaClima.porDia() });
  });

  app.post("/api/clima/prediccion/generar", requiere("ia.reentrenar"), async (req, res) => {
    const r = await iaClima.generar();
    await auditar(req, "GENERAR_PREDICCION", "predicciones");
    res.json(r || { error: "Datos insuficientes" });
  });

  // Calculadora FAO Penman-Monteith (validación 3.20.6)
  app.post("/api/clima/eto-calculo", requiere("clima.ver"), async (req, res) => {
    const f = await db.uno("SELECT latitud, altitud_m FROM fincas WHERE id = 1");
    const b = req.body;
    const n = k => { const v = Number(b[k]); if (!Number.isFinite(v)) throw new HttpError(400, `Valor inválido: ${k}`); return v; };
    const fechaRef = b.fecha ? parse(b.fecha + " 12:00:00") : new Date();
    const r = penmanMonteith({
      tmax: n("tmax"), tmin: n("tmin"), hrmax: n("hrmax"), hrmin: n("hrmin"), u2: n("u2"), rs: n("rs"),
      z: b.z !== undefined ? Number(b.z) : f.altitud_m, lat: b.lat !== undefined ? Number(b.lat) : f.latitud, J: diaDelAnio(fechaRef),
    });
    res.json(r);
  });
};

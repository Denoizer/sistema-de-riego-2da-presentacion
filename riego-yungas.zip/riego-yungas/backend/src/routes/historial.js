// Historial de riegos, consumo por sector, decisiones y exportación CSV (HU-14)
const db = require("../db");
const { requiere } = require("../auth/middleware");
const { fecha } = require("../util/tiempo");
const { auditar } = require("../servicios/auditoria");
const { sectoresPermitidos } = require("../auth/acceso");

async function filtros(req) {
  const hasta = req.query.hasta || fecha(new Date());
  const desde = req.query.desde || fecha(new Date(Date.now() - 7 * 86400000));
  const cond = ["r.inicio >= ?", "r.inicio <= ?"];
  const params = [desde + " 00:00:00", hasta + " 23:59:59"];
  if (req.query.sector) { cond.push("r.sector_id = ?"); params.push(Number(req.query.sector)); }
  if (req.query.tipo) { cond.push("r.tipo = ?"); params.push(req.query.tipo); }
  const permitidos = await sectoresPermitidos(req);
  if (permitidos) cond.push(`r.sector_id IN (${permitidos.map(Number).join(",")})`);
  return { desde, hasta, where: cond.join(" AND "), params, permitidos };
}

const SQL_RIEGOS = `SELECT r.id, s.codigo sector, s.nombre sector_nombre, c.nombre cultivo, r.tipo, m.codigo motivo, m.descripcion motivo_desc,
  r.lamina_mm, r.litros_plan, r.litros_reales, r.duracion_plan_min, r.caudal_prom_lmin, r.inicio, r.fin, r.estado,
  CONCAT_WS(' ', u.nombre, u.apellido) usuario
  FROM riegos r JOIN sectores s ON s.id = r.sector_id JOIN cultivos c ON c.id = s.cultivo_id JOIN motivos m ON m.id = r.motivo_id
  LEFT JOIN usuarios u ON u.id = r.usuario_id`;

module.exports = app => {
  app.get("/api/riegos", requiere("historial.ver"), async (req, res) => {
    const f = await filtros(req);
    const filas = await db.q(`${SQL_RIEGOS} WHERE ${f.where} ORDER BY r.inicio DESC LIMIT 500`, f.params);
    const porSector = await db.q(
      `SELECT s.id, s.codigo, c.nombre cultivo, COUNT(r.id) n, COALESCE(SUM(r.litros_reales),0) litros
         FROM sectores s JOIN cultivos c ON c.id = s.cultivo_id
         LEFT JOIN riegos r ON r.sector_id = s.id AND r.inicio >= ? AND r.inicio <= ?
        GROUP BY s.id, s.codigo, c.nombre ORDER BY s.id`, [f.desde + " 00:00:00", f.hasta + " 23:59:59"]);
    const porDia = await db.q(
      `SELECT DATE(r.inicio) dia, s.codigo, SUM(r.litros_reales) litros FROM riegos r JOIN sectores s ON s.id = r.sector_id
        WHERE ${f.where} GROUP BY DATE(r.inicio), s.codigo ORDER BY dia`, f.params);
    if (f.permitidos) porSector.splice(0, porSector.length, ...porSector.filter(x => f.permitidos.includes(x.id)));
    res.json({ desde: f.desde, hasta: f.hasta, riegos: filas, por_sector: porSector, por_dia: porDia });
  });

  app.get("/api/riegos/exportar.csv", requiere("reportes.exportar"), async (req, res) => {
    const f = await filtros(req);
    const filas = await db.q(`${SQL_RIEGOS} WHERE ${f.where} ORDER BY r.inicio`, f.params);
    const cols = ["id", "sector", "cultivo", "tipo", "motivo", "motivo_desc", "lamina_mm", "litros_plan", "litros_reales", "duracion_plan_min", "caudal_prom_lmin", "inicio", "fin", "estado", "usuario"];
    const esc = v => (v === null || v === undefined ? "" : /[;"\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v));
    const csv = "﻿" + cols.join(";") + "\n" + filas.map(r => cols.map(c => esc(r[c])).join(";")).join("\n");
    await auditar(req, "EXPORTAR_CSV", "riegos", null, `${f.desde} a ${f.hasta}`);
    res.texto(csv, "text/csv; charset=utf-8", { "Content-Disposition": `attachment; filename="riegos_${f.desde}_${f.hasta}.csv"` });
  });

  app.get("/api/decisiones", requiere("historial.ver", "sensores.ver"), async (req, res) => {
    const lim = Math.min(200, Number(req.query.limite) || 50);
    const filas = await db.q(
      `SELECT d.id, s.codigo sector, d.decision, m.codigo motivo, m.descripcion motivo_desc, d.humedad, d.umbral, d.eto_mm, d.etc_loc_mm,
              d.deficit_mm, d.lluvia_prevista_mm, d.prob_lluvia, d.humedad_pred_24h, d.detalle, d.fecha
         FROM decisiones d JOIN sectores s ON s.id = d.sector_id JOIN motivos m ON m.id = d.motivo_id
        ${req.query.sector ? "WHERE d.sector_id = " + Number(req.query.sector) : ""}
        ORDER BY d.fecha DESC, d.id DESC LIMIT ?`, [lim]);
    res.json(filas);
  });
};

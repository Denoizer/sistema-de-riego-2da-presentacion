// Nodos, sensores, calibración, mantenimiento y pruebas de falla (rol técnico)
const db = require("../db");
const config = require("../config");
const { requiere } = require("../auth/middleware");
const { HttpError } = require("../http/app");
const { ahora, hace } = require("../util/tiempo");
const estado = require("../motor/estado");
const { riegoEnCurso, detenerRiego } = require("../motor/riego");
const { auditar } = require("../servicios/auditoria");
const { emitir, notificar } = require("../servicios/notificador");

const TIPO = { preventivo: "preventivo", correctivo: "correctivo", calibracion: "de calibración" };

/** Avisa al agricultor a cargo del sector (o a todos si es general) y al administrador */
async function avisarMantenimiento(req, sector_id, titulo, mensaje) {
  const sec = sector_id ? await db.uno("SELECT codigo, nombre FROM sectores WHERE id = ?", [sector_id]) : null;
  await notificar(["agricultor", "admin"], `${titulo}${sec ? " · " + sec.codigo : ""}`,
    `${sec ? sec.nombre + ": " : "Finca (general): "}${mensaje} — Técnico: ${req.usuario.nombre} ${req.usuario.apellido}.`, "info", { sector_id: sector_id || null });
}

const simulador = () => require("../motor/simulador");

module.exports = app => {
  app.get("/api/nodos", requiere("sensores.ver"), async (req, res) => {
    const nodos = await db.q(
      `SELECT n.id, n.codigo, n.tipo, n.descripcion, n.firmware, n.bateria_v, n.rssi_dbm, n.en_linea, n.ultima_conexion,
              s.codigo sector, s.nombre sector_nombre, s.modo, s.estado sector_estado
         FROM nodos n LEFT JOIN sectores s ON s.id = n.sector_id ORDER BY n.id`);
    const sensores = await db.q("SELECT id, nodo_id, tipo, posicion, modelo, unidad, ultimo_valor, estado, adc_seco, adc_saturado, ultima_calibracion FROM sensores ORDER BY nodo_id, id");
    for (const n of nodos) {
      n.sensores = sensores.filter(s => s.nodo_id === n.id);
      const visto = estado.nodosVistos.get(n.id);
      n.segundos_desde_reporte = visto ? Math.round((Date.now() - visto) / 1000) : null;
    }
    const bateria = await db.q(
      `SELECT ls.sector_id, ls.fecha, ls.bateria_v FROM lecturas_sector ls WHERE ls.fecha >= ? ORDER BY ls.fecha`, [hace(24 * 60)]);
    res.json({ nodos, bateria, simulador: config.simulador, fallas: config.simulador ? simulador().fallasActivas() : null });
  });

  // Calibración de sensores de humedad (HU-18)
  app.post("/api/sensores/:id/calibrar", requiere("sensores.calibrar"), async (req, res) => {
    const id = Number(req.params.id);
    const s = await db.uno("SELECT * FROM sensores WHERE id = ?", [id]);
    if (!s) throw new HttpError(404, "Sensor no encontrado");
    const seco = Number(req.body.adc_seco), sat = Number(req.body.adc_saturado);
    if (s.tipo === "humedad") {
      if (!(seco > 0 && sat > 0 && seco <= 4095 && sat <= 4095)) throw new HttpError(400, "Los valores ADC deben estar entre 1 y 4095");
      if (seco <= sat) throw new HttpError(400, "El valor en seco debe ser mayor que el valor saturado (sensor capacitivo)");
    }
    const factor = req.body.factor !== undefined ? Number(req.body.factor) : 1;
    await db.ejecutar("UPDATE sensores SET adc_seco = ?, adc_saturado = ?, factor_calibracion = ?, estado = 'ok', ultima_calibracion = ? WHERE id = ?",
      [s.tipo === "humedad" ? seco : s.adc_seco, s.tipo === "humedad" ? sat : s.adc_saturado, factor, ahora(), id]);
    await db.ejecutar("INSERT INTO calibraciones (sensor_id, tecnico_id, adc_seco, adc_saturado, factor, observacion, fecha) VALUES (?,?,?,?,?,?,?)",
      [id, req.usuario.id, s.tipo === "humedad" ? seco : null, s.tipo === "humedad" ? sat : null, factor, String(req.body.observacion || "").slice(0, 255), ahora()]);
    const n = await db.uno("SELECT sector_id FROM nodos WHERE id = ?", [s.nodo_id]);
    await db.ejecutar("INSERT INTO mantenimientos (nodo_id, sector_id, tecnico_id, tipo, descripcion, fecha) VALUES (?,?,?,?,?,?)",
      [s.nodo_id, n ? n.sector_id : null, req.usuario.id, "calibracion", `Calibración del sensor ${s.tipo} ${s.posicion || ""} (seco ${seco || "-"} / saturado ${sat || "-"})`, ahora()]);
    await auditar(req, "CALIBRAR_SENSOR", "sensores", id);
    await avisarMantenimiento(req, n ? n.sector_id : null, "Sensor calibrado", `se calibró el sensor ${s.tipo} ${s.posicion || ""}.`);
    res.json({ ok: true });
  });

  app.get("/api/sensores/:id/calibraciones", requiere("sensores.ver"), async (req, res) => {
    res.json(await db.q(
      `SELECT c.*, CONCAT_WS(' ', u.nombre, u.apellido) tecnico FROM calibraciones c LEFT JOIN usuarios u ON u.id = c.tecnico_id WHERE c.sensor_id = ? ORDER BY c.fecha DESC`, [Number(req.params.id)]));
  });

  // Mantenimiento
  app.get("/api/mantenimientos", requiere("mantenimiento.gestionar", "sensores.ver"), async (req, res) => {
    res.json(await db.q(
      `SELECT m.id, m.tipo, m.descripcion, m.fecha, n.codigo nodo, s.codigo sector, CONCAT_WS(' ', u.nombre, u.apellido) tecnico
         FROM mantenimientos m LEFT JOIN nodos n ON n.id = m.nodo_id LEFT JOIN sectores s ON s.id = m.sector_id LEFT JOIN usuarios u ON u.id = m.tecnico_id
        ORDER BY m.fecha DESC LIMIT 100`));
  });

  app.post("/api/mantenimientos", requiere("mantenimiento.gestionar"), async (req, res) => {
    const { tipo, descripcion, sector_id, nodo_id } = req.body;
    if (!["preventivo", "correctivo", "calibracion"].includes(tipo)) throw new HttpError(400, "Tipo de mantenimiento no válido");
    if (!descripcion || String(descripcion).trim().length < 10) throw new HttpError(400, "Describa el trabajo realizado (mínimo 10 caracteres)");
    const r = await db.ejecutar("INSERT INTO mantenimientos (nodo_id, sector_id, tecnico_id, tipo, descripcion, fecha) VALUES (?,?,?,?,?,?)",
      [nodo_id || null, sector_id || null, req.usuario.id, tipo, String(descripcion).trim().slice(0, 400), ahora()]);
    await auditar(req, "REGISTRAR_MANTENIMIENTO", "mantenimientos", r.insertId);
    await avisarMantenimiento(req, sector_id || null, "Mantenimiento registrado", `mantenimiento ${TIPO[tipo]} – ${String(descripcion).trim().slice(0, 200)}`);
    emitir("mantenimientos", {});
    res.json({ ok: true, id: r.insertId });
  });

  // Poner / quitar un sector en mantenimiento (no riega automáticamente)
  app.put("/api/sectores/:id/mantenimiento", requiere("mantenimiento.gestionar"), async (req, res) => {
    const id = Number(req.params.id);
    const activar = !!req.body.activar;
    if (activar && (await riegoEnCurso(id))) await detenerRiego(id, req.usuario.id);
    await db.ejecutar("UPDATE sectores SET modo = ?, estado = ? WHERE id = ?", [activar ? "mantenimiento" : "automatico", activar ? "mantenimiento" : "reposo", id]);
    await db.ejecutar("INSERT INTO mantenimientos (sector_id, tecnico_id, tipo, descripcion, fecha) VALUES (?,?,?,?,?)",
      [id, req.usuario.id, "preventivo", activar ? "Sector puesto en mantenimiento (riego automático suspendido)" : "Sector rehabilitado tras mantenimiento", ahora()]);
    await auditar(req, activar ? "SECTOR_MANTENIMIENTO" : "SECTOR_REHABILITADO", "sectores", id);
    await avisarMantenimiento(req, id, activar ? "Sector en mantenimiento" : "Sector rehabilitado",
      activar ? "el riego automático queda suspendido mientras dura el mantenimiento." : "el mantenimiento terminó y el sector volvió al riego automático.");
    emitir("sector", { id });
    res.json({ ok: true });
  });

  // Pruebas de falla en modo simulación
  app.post("/api/simulacion/falla", requiere("simulacion.fallas"), async (req, res) => {
    if (!config.simulador) throw new HttpError(409, "Disponible solo en modo simulación (SIMULADOR=1)");
    const { tipo, sector_id } = req.body;
    try { simulador().inyectarFalla(tipo, sector_id); } catch (e) { throw new HttpError(400, e.message); }
    await auditar(req, "SIMULAR_FALLA", "simulacion", sector_id || null, tipo);
    res.json({ ok: true, fallas: simulador().fallasActivas() });
  });
  app.post("/api/simulacion/limpiar", requiere("simulacion.fallas"), async (req, res) => {
    if (!config.simulador) throw new HttpError(409, "Disponible solo en modo simulación");
    simulador().limpiarFallas();
    await auditar(req, "LIMPIAR_FALLAS", "simulacion");
    res.json({ ok: true, fallas: simulador().fallasActivas() });
  });
  app.post("/api/simulacion/lluvia", requiere("simulacion.fallas"), async (req, res) => {
    if (!config.simulador) throw new HttpError(409, "Disponible solo en modo simulación");
    simulador().forzarLluvia(Number(req.body.mm_hora) || 0);
    res.json({ ok: true });
  });
};

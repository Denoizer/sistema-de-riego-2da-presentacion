// Alertas (HU-12) y notificaciones del usuario
const db = require("../db");
const { requiere } = require("../auth/middleware");
const { HttpError } = require("../http/app");
const { ahora } = require("../util/tiempo");
const { auditar } = require("../servicios/auditoria");
const { emitir, registrarCliente, notificar } = require("../servicios/notificador");
const { autenticar } = require("../auth/middleware");
const { sectoresPermitidos } = require("../auth/acceso");

module.exports = app => {
  app.get("/api/alertas", requiere("alertas.ver"), async (req, res) => {
    const estadoF = req.query.estado || "activas";
    const cond = estadoF === "activas" ? "WHERE a.atendida = 0" : estadoF === "atendidas" ? "WHERE a.atendida = 1" : "";
    // Cada rol ve las alertas dirigidas a él
    const filas = await db.q(
      `SELECT a.id, a.sector_id, t.codigo, t.nombre, t.severidad, t.destinatarios, a.mensaje, a.atendida, a.atendida_en, a.nota_atencion, a.fecha,
              s.codigo sector, n.codigo nodo, CONCAT_WS(' ', u.nombre, u.apellido) atendida_por
         FROM alertas a JOIN tipos_alerta t ON t.id = a.tipo_alerta_id
         LEFT JOIN sectores s ON s.id = a.sector_id LEFT JOIN nodos n ON n.id = a.nodo_id LEFT JOIN usuarios u ON u.id = a.atendida_por
        ${cond} ORDER BY a.atendida, CASE t.severidad WHEN 'critica' THEN 1 WHEN 'alta' THEN 2 WHEN 'media' THEN 3 ELSE 4 END, a.fecha DESC LIMIT 200`);
    const permitidos = await sectoresPermitidos(req);
    res.json(filas.filter(a => a.destinatarios.split(",").includes(req.usuario.rol) && (!permitidos || a.sector_id === null || permitidos.includes(a.sector_id))));
  });

  app.post("/api/alertas/:id/atender", requiere("alertas.atender"), async (req, res) => {
    const id = Number(req.params.id);
    const a = await db.uno("SELECT a.*, t.codigo FROM alertas a JOIN tipos_alerta t ON t.id = a.tipo_alerta_id WHERE a.id = ?", [id]);
    if (!a) throw new HttpError(404, "Alerta no encontrada");
    if (a.atendida) throw new HttpError(409, "La alerta ya fue atendida");
    const nota = String(req.body.nota || "").trim();
    if (nota.length < 5) throw new HttpError(400, "Describa la acción realizada (mínimo 5 caracteres)");
    await db.ejecutar("UPDATE alertas SET atendida = 1, atendida_por = ?, atendida_en = ?, nota_atencion = ? WHERE id = ?", [req.usuario.id, ahora(), nota.slice(0, 300), id]);
    // Una falla de válvula deja el sector en "falla": al atenderla se rehabilita
    if (a.sector_id && ["A-03", "A-04"].includes(a.codigo)) {
      await db.ejecutar("UPDATE sectores SET estado = 'reposo' WHERE id = ? AND estado = 'falla'", [a.sector_id]);
      await db.ejecutar("INSERT INTO mantenimientos (nodo_id, sector_id, tecnico_id, tipo, descripcion, fecha) VALUES (?,?,?,?,?,?)",
        [a.nodo_id, a.sector_id, req.usuario.id, "correctivo", `Atención de alerta ${a.codigo}: ${nota}`.slice(0, 400), ahora()]);
    }
    await auditar(req, "ATENDER_ALERTA", "alertas", id, nota);
    // El agricultor a cargo y el administrador se enteran de que la falla fue atendida
    const sec = a.sector_id ? await db.uno("SELECT codigo, nombre FROM sectores WHERE id = ?", [a.sector_id]) : null;
    await notificar(["agricultor", "admin"], `Falla atendida · ${a.codigo}${sec ? " · " + sec.codigo : ""}`,
      `${sec ? sec.nombre + ": " : ""}${nota.slice(0, 200)} — Técnico: ${req.usuario.nombre} ${req.usuario.apellido}.`, "info", { sector_id: a.sector_id });
    emitir("alertas", { id });
    emitir("sector", { id: a.sector_id });
    res.json({ ok: true });
  });

  app.get("/api/notificaciones", requiere(), async (req, res) => {
    const filas = await db.q("SELECT id, titulo, mensaje, nivel, leida, fecha FROM notificaciones WHERE usuario_id = ? ORDER BY fecha DESC, id DESC LIMIT 50", [req.usuario.id]);
    const sin = await db.uno("SELECT COUNT(*) n FROM notificaciones WHERE usuario_id = ? AND leida = 0", [req.usuario.id]);
    res.json({ no_leidas: sin.n, notificaciones: filas });
  });

  app.post("/api/notificaciones/leer", requiere(), async (req, res) => {
    await db.ejecutar("UPDATE notificaciones SET leida = 1 WHERE usuario_id = ? AND leida = 0", [req.usuario.id]);
    res.json({ ok: true });
  });

  // Canal de eventos en tiempo real (Server-Sent Events)
  app.get("/api/stream", async (req, res) => {
    await autenticar(req);
    registrarCliente(res, req.usuario);
  });
};

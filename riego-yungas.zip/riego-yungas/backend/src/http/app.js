// Mini framework HTTP (enrutador, JSON, archivos estáticos) sobre node:http
const http = require("http");
const fs = require("fs");
const path = require("path");

class HttpError extends Error {
  constructor(status, mensaje) { super(mensaje); this.status = status; }
}

const MIME = {
  ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".json": "application/json", ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".ico": "image/x-icon",
  ".webmanifest": "application/manifest+json",
};

class App {
  constructor() { this.rutas = []; this.estatico = null; }

  agregar(metodo, ruta, ...handlers) {
    const nombres = [];
    const patron = new RegExp("^" + ruta.replace(/:(\w+)/g, (_, n) => { nombres.push(n); return "([^/]+)"; }) + "/?$");
    this.rutas.push({ metodo, patron, nombres, handlers });
  }
  get(r, ...h) { this.agregar("GET", r, ...h); }
  post(r, ...h) { this.agregar("POST", r, ...h); }
  put(r, ...h) { this.agregar("PUT", r, ...h); }
  delete(r, ...h) { this.agregar("DELETE", r, ...h); }
  servirEstatico(dir) { this.estatico = dir; }

  async manejar(req, res) {
    const url = new URL(req.url, "http://localhost");
    req.query = Object.fromEntries(url.searchParams);
    req.ruta = url.pathname;
    req.ip_cliente = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").toString().split(",")[0];

    res.json = (datos, status = 200) => {
      if (res.headersSent) return;
      res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
      res.end(JSON.stringify(datos));
    };
    res.texto = (texto, tipo = "text/plain; charset=utf-8", extra = {}) => {
      res.writeHead(200, { "Content-Type": tipo, ...extra });
      res.end(texto);
    };

    try {
      const ruta = this.rutas.find(r => r.metodo === req.method && r.patron.test(url.pathname));
      if (!ruta) {
        if (req.method === "GET" && !url.pathname.startsWith("/api/") && this.estatico) return this.archivo(url.pathname, res);
        throw new HttpError(404, "Ruta no encontrada");
      }
      const m = url.pathname.match(ruta.patron);
      req.params = Object.fromEntries(ruta.nombres.map((n, i) => [n, decodeURIComponent(m[i + 1])]));
      req.body = ["POST", "PUT", "DELETE"].includes(req.method) ? await leerCuerpo(req) : {};
      for (const h of ruta.handlers) {
        await h(req, res);
        if (res.writableEnded || res.headersSent) break;
      }
    } catch (e) {
      const status = e.status || 500;
      if (status === 500) console.error("[ERROR]", req.method, req.url, e);
      res.json({ error: status === 500 ? "Error interno del servidor" : e.message }, status);
    }
  }

  archivo(ruta, res) {
    let archivo = path.normalize(path.join(this.estatico, ruta));
    if (!archivo.startsWith(this.estatico)) { res.writeHead(403); return res.end(); }
    if (!fs.existsSync(archivo) || fs.statSync(archivo).isDirectory()) archivo = path.join(this.estatico, "index.html");
    res.writeHead(200, { "Content-Type": MIME[path.extname(archivo)] || "application/octet-stream" });
    fs.createReadStream(archivo).pipe(res);
  }

  escuchar(puerto, cb) {
    return http.createServer((req, res) => this.manejar(req, res)).listen(puerto, cb);
  }
}

function leerCuerpo(req) {
  return new Promise((resolve, reject) => {
    let datos = "";
    req.on("data", c => { datos += c; if (datos.length > 1e6) { reject(new HttpError(413, "Cuerpo demasiado grande")); req.destroy(); } });
    req.on("end", () => {
      if (!datos) return resolve({});
      try { resolve(JSON.parse(datos)); } catch { reject(new HttpError(400, "JSON inválido")); }
    });
    req.on("error", reject);
  });
}

module.exports = { App, HttpError };

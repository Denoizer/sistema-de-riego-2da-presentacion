// Utilidades de fecha/hora en formato MySQL (hora local de la finca)
const pad = n => String(n).padStart(2, "0");

function fmt(d) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
const fecha = d => fmt(d).slice(0, 10);
const ahora = () => fmt(new Date());
const hace = (min, base = new Date()) => fmt(new Date(base.getTime() - min * 60000));
const dentro = (min, base = new Date()) => fmt(new Date(base.getTime() + min * 60000));
const parse = s => (s ? new Date(String(s).replace(" ", "T")) : null);
const diaDelAnio = d => Math.floor((d - new Date(d.getFullYear(), 0, 0)) / 86400000);

module.exports = { fmt, fecha, ahora, hace, dentro, parse, diaDelAnio };

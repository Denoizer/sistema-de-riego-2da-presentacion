// Uso: npm run hash -- "MiClave2026!"   -> imprime el hash para la tabla usuarios
const { hashPassword } = require("../src/auth/password");
const clave = process.argv[2];
if (!clave) { console.log('Uso: npm run hash -- "MiClave2026!"'); process.exit(1); }
console.log(hashPassword(clave));

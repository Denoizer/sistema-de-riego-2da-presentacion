// Verifica la conexión a MySQL con los datos de backend/.env
const db = require("../src/db");
(async () => {
  try {
    const r = await db.uno("SELECT DATABASE() AS base, VERSION() AS version, (SELECT COUNT(*) FROM usuarios) AS usuarios");
    console.log("✔ Conexión correcta:", r);
  } catch (e) {
    console.error("✖ Error de conexión:", e.message);
  } finally { await db.pool.end(); }
})();

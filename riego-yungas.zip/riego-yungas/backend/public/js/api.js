// Cliente de la API REST y del canal de eventos en tiempo real
const CLAVE = "riego_sesion";

export const sesion = {
  get token() { return localStorage.getItem(CLAVE + "_token"); },
  get usuario() { try { return JSON.parse(localStorage.getItem(CLAVE + "_usuario")); } catch { return null; } },
  guardar(token, usuario) { localStorage.setItem(CLAVE + "_token", token); localStorage.setItem(CLAVE + "_usuario", JSON.stringify(usuario)); },
  cerrar() { localStorage.removeItem(CLAVE + "_token"); localStorage.removeItem(CLAVE + "_usuario"); },
  puede(...permisos) { const u = this.usuario; return !!u && permisos.some(p => u.permisos.includes(p)); },
};

export class ErrorApi extends Error { constructor(msg, status) { super(msg); this.status = status; } }

export async function api(ruta, { metodo = "GET", cuerpo } = {}) {
  const r = await fetch("/api" + ruta, {
    method: metodo,
    headers: { "Content-Type": "application/json", ...(sesion.token ? { Authorization: "Bearer " + sesion.token } : {}) },
    body: cuerpo ? JSON.stringify(cuerpo) : undefined,
  });
  let datos = null;
  try { datos = await r.json(); } catch { /* sin cuerpo */ }
  if (r.status === 401 && ruta !== "/auth/login") {
    sesion.cerrar();
    location.hash = "#/login";
    throw new ErrorApi("Su sesión expiró. Inicie sesión nuevamente.", 401);
  }
  if (!r.ok) throw new ErrorApi((datos && datos.error) || "Error de comunicación con el servidor", r.status);
  return datos;
}

export async function descargar(ruta, nombre) {
  const r = await fetch("/api" + ruta, { headers: { Authorization: "Bearer " + sesion.token } });
  if (!r.ok) throw new ErrorApi("No se pudo descargar el archivo", r.status);
  const blob = await r.blob();
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = nombre; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

/** Conexión SSE con reconexión automática */
export function conectarEventos(manejadores) {
  let fuente = null, cerrado = false;
  const abrir = () => {
    if (cerrado || !sesion.token) return;
    fuente = new EventSource("/api/stream?token=" + encodeURIComponent(sesion.token));
    for (const [ev, fn] of Object.entries(manejadores)) fuente.addEventListener(ev, e => fn(JSON.parse(e.data || "{}")));
    fuente.onerror = () => { fuente.close(); setTimeout(abrir, 4000); };
  };
  abrir();
  return () => { cerrado = true; if (fuente) fuente.close(); };
}

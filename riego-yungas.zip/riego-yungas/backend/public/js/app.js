// Aplicación principal: sesión, enrutador, menú por rol y notificaciones en vivo
import { api, sesion, conectarEventos } from "./api.js";
import { esc, icono, aviso, hace, error } from "./ui.js";

import login from "./pages/login.js";
import inicio from "./pages/inicio.js";
import sectores from "./pages/sectores.js";
import riego from "./pages/riego.js";
import sector from "./pages/sector.js";
import agua from "./pages/agua.js";
import clima from "./pages/clima.js";
import historial from "./pages/historial.js";
import alertas from "./pages/alertas.js";
import dispositivos from "./pages/dispositivos.js";
import mantenimiento from "./pages/mantenimiento.js";
import automatizacion from "./pages/automatizacion.js";
import ia from "./pages/ia.js";
import usuarios from "./pages/usuarios.js";
import ajustes from "./pages/ajustes.js";
import auditoria from "./pages/auditoria.js";
import perfil from "./pages/perfil.js";

// Menú: cada entrada se muestra solo si el rol tiene el permiso
const MENU = [
  { sep: "Operación" },
  { ruta: "inicio", texto: "Panel", icono: "inicio", permiso: "dashboard.ver", pagina: inicio, movil: true },
  { ruta: "sectores", texto: "Sectores", icono: "sectores", permiso: "sectores.ver", pagina: sectores, movil: true },
  { ruta: "riego", texto: "Riego manual", icono: "gota", permisos: ["riego.manual", "riego.programar"], pagina: riego, movil: true },
  { ruta: "agua", texto: "Agua y tanque", icono: "tanque", permiso: "tanque.ver", pagina: agua },
  { ruta: "clima", texto: "Clima e IA", icono: "clima", permiso: "clima.ver", pagina: clima },
  { ruta: "historial", texto: "Historial", icono: "historial", permiso: "historial.ver", pagina: historial },
  { ruta: "alertas", texto: "Alertas", icono: "alerta", permiso: "alertas.ver", pagina: alertas, movil: true, burbuja: true },
  { sep: "Campo" },
  { ruta: "dispositivos", texto: "Sensores y nodos", icono: "sensor", permiso: "sensores.ver", pagina: dispositivos, movil: true },
  { ruta: "mantenimiento", texto: "Mantenimiento", icono: "llave", permiso: "mantenimiento.gestionar", pagina: mantenimiento },
  { sep: "Administración" },
  { ruta: "automatizacion", texto: "Automatización", icono: "rayo", permiso: "automatizacion.gestionar", pagina: automatizacion },
  { ruta: "ia", texto: "Modelos de IA", icono: "cerebro", permiso: "ia.ver", pagina: ia },
  { ruta: "usuarios", texto: "Usuarios y roles", icono: "usuarios", permiso: "usuarios.gestionar", pagina: usuarios },
  { ruta: "ajustes", texto: "Configuración", icono: "ajustes", permisos: ["riego.configurar", "sectores.configurar"], pagina: ajustes },
  { ruta: "auditoria", texto: "Auditoría", icono: "escudo", permiso: "auditoria.ver", pagina: auditoria },
];
const EXTRA = { sector: { pagina: sector, permiso: "sectores.ver", padre: "sectores" }, perfil: { pagina: perfil, padre: null } };

const raiz = document.getElementById("raiz");
let desconectar = null, paginaActual = null, alertasActivas = 0, ultimoRefresco = 0, refrescoPendiente = null;

const visible = m => !m.sep && (m.permiso ? sesion.puede(m.permiso) : m.permisos ? sesion.puede(...m.permisos) : true);

function layout() {
  const u = sesion.usuario;
  const items = MENU.filter(m => m.sep || visible(m));
  const limpio = items.filter((m, i) => !m.sep || (items[i + 1] && !items[i + 1].sep));
  const movil = MENU.filter(m => m.movil && visible(m)).slice(0, 4);
  raiz.innerHTML = `
  <div class="app">
    <aside class="lateral" id="lateral">
      <div class="marca"><div class="logo">${icono("gota", 'style="width:20px;height:20px;color:#03140a"')}</div>
        <div><b>Riego Yungas IA</b><small>Coroico · 4 ha</small></div></div>
      ${limpio.map(m => m.sep ? `<div class="nav-sep">${esc(m.sep)}</div>` :
        `<a class="nav-item" data-ruta="${m.ruta}" href="#/${m.ruta}">${icono(m.icono)}<span>${esc(m.texto)}</span>${m.burbuja ? '<span class="burbuja" id="burbuja-alertas" hidden></span>' : ""}</a>`).join("")}
      <div style="margin-top:auto" class="col">
        <div class="card" style="padding:12px">
          <div class="eti">Sesión</div>
          <div style="margin:6px 0 2px;font-weight:600">${esc(u.nombre)} ${esc(u.apellido)}</div>
          <span class="pill ${u.rol === "admin" ? "violeta" : u.rol === "tecnico" ? "azul" : "verde"}">${esc(u.rol_nombre)}</span>
        </div>
        <a class="nav-item" href="#/perfil">${icono("ajustes")}<span>Mi perfil</span></a>
        <a class="nav-item" id="btn-salir">${icono("salir")}<span>Cerrar sesión</span></a>
      </div>
    </aside>
    <div class="principal">
      <header class="cabecera">
        <button class="btn fant chico" id="btn-menu" style="display:none">${icono("menu")}</button>
        <div><h1 id="titulo">Panel</h1><div class="sub" id="subtitulo"></div></div>
        <div class="der">
          <span class="pill verde pulso" id="estado-sistema"><span class="pt"></span>Sistema activo</span>
          <div class="campana"><button class="btn fant chico" id="btn-notif" title="Notificaciones">${icono("campana")}</button><span class="num" id="num-notif" hidden></span>
            <div class="panel-notif" id="panel-notif" hidden></div></div>
          <a class="chip-usuario" href="#/perfil"><span class="avatar">${esc(u.nombre[0])}${esc(u.apellido[0])}</span><span class="peq">${esc(u.usuario)}</span></a>
        </div>
      </header>
      <main class="contenido" id="contenido"></main>
    </div>
  </div>
  <nav class="barra-movil">${movil.map(m => `<a data-ruta="${m.ruta}" href="#/${m.ruta}">${icono(m.icono)}<span>${esc(m.texto.split(" ")[0])}</span></a>`).join("")}
    <a href="#" id="btn-mas">${icono("menu")}<span>Más</span></a></nav>`;

  document.getElementById("btn-salir").onclick = async () => { try { await api("/auth/logout", { metodo: "POST" }); } catch { /* */ } salir(); };
  const lat = document.getElementById("lateral");
  const alternar = e => { e.preventDefault(); lat.classList.toggle("abierto"); };
  document.getElementById("btn-mas").onclick = alternar;
  lat.addEventListener("click", e => { if (e.target.closest("a")) lat.classList.remove("abierto"); });
  const panel = document.getElementById("panel-notif");
  document.getElementById("btn-notif").onclick = async () => {
    panel.hidden = !panel.hidden;
    if (!panel.hidden) { await cargarNotificaciones(true); api("/notificaciones/leer", { metodo: "POST" }).then(() => contarNotificaciones()).catch(() => {}); }
  };
  document.addEventListener("click", e => { if (!e.target.closest(".campana")) panel.hidden = true; });
}

async function cargarNotificaciones(mostrar) {
  const r = await api("/notificaciones");
  const n = document.getElementById("num-notif");
  if (n) { n.hidden = !r.no_leidas; n.textContent = r.no_leidas > 9 ? "9+" : r.no_leidas; }
  if (mostrar) document.getElementById("panel-notif").innerHTML =
    `<div class="fila entre" style="padding:12px 14px;border-bottom:1px solid var(--line)"><b>Notificaciones</b><span class="eti">${r.no_leidas} sin leer</span></div>` +
    (r.notificaciones.length ? r.notificaciones.map(x => `<div class="notif ${x.leida ? "" : "no-leida"}"><div class="fila entre"><b>${esc(x.titulo)}</b><span class="eti">${hace(x.fecha)}</span></div><div class="mut" style="margin-top:3px;line-height:1.45">${esc(x.mensaje)}</div></div>`).join("") : `<div class="vacio">Sin notificaciones</div>`);
}
const contarNotificaciones = () => cargarNotificaciones(false).catch(() => {});

async function contarAlertas() {
  if (!sesion.puede("alertas.ver")) return;
  try {
    const a = await api("/alertas");
    alertasActivas = a.length;
    const b = document.getElementById("burbuja-alertas");
    if (b) { b.hidden = !alertasActivas; b.textContent = alertasActivas; }
    const est = document.getElementById("estado-sistema");
    const crit = a.some(x => x.severidad === "critica");
    if (est) { est.className = "pill pulso " + (crit ? "rojo" : a.length ? "ambar" : "verde"); est.innerHTML = `<span class="pt"></span>${crit ? "Falla crítica" : a.length ? a.length + " alerta(s)" : "Sistema activo"}`; }
  } catch { /* */ }
}

function salir() {
  if (desconectar) desconectar();
  desconectar = null;
  sesion.cerrar();
  location.hash = "#/login";
}

function refrescarPagina() {
  if (!paginaActual || !paginaActual.refrescar) return;
  // No refrescar mientras el usuario escribe o tiene un diálogo abierto
  const act = document.activeElement;
  if (document.querySelector(".modal-fondo") || (act && ["INPUT", "SELECT", "TEXTAREA"].includes(act.tagName))) return;
  const ahora = Date.now();
  if (ahora - ultimoRefresco < 2500) { if (!refrescoPendiente) refrescoPendiente = setTimeout(() => { refrescoPendiente = null; refrescarPagina(); }, 2600); return; }
  ultimoRefresco = ahora;
  paginaActual.refrescar().catch(() => {});
}

async function navegar() {
  const [ruta, ...params] = (location.hash.replace(/^#\/?/, "") || "inicio").split("/");
  if (!sesion.token || ruta === "login") {
    if (desconectar) { desconectar(); desconectar = null; }
    paginaActual = null;
    return login(raiz, () => { if (location.hash === "#/inicio") navegar(); else location.hash = "#/inicio"; });
  }
  if (!document.getElementById("contenido")) {
    layout();
    contarNotificaciones(); contarAlertas();
    desconectar = conectarEventos({
      notificacion: n => {
        aviso(n.titulo, n.mensaje, n.nivel); contarNotificaciones();
        if ("Notification" in window && Notification.permission === "granted" && document.hidden) new Notification(n.titulo, { body: n.mensaje, icon: "img/logo.svg" });
      },
      alertas: () => { contarAlertas(); refrescarPagina(); },
      sector: () => refrescarPagina(),
      lectura: () => refrescarPagina(),
      prediccion: () => refrescarPagina(),
      programados: () => refrescarPagina(),
      mantenimientos: () => refrescarPagina(),
    });
  }
  const def = MENU.find(m => m.ruta === ruta) || EXTRA[ruta];
  const cont = document.getElementById("contenido");
  if (!def || (def.permiso && !sesion.puede(def.permiso)) || (def.permisos && !sesion.puede(...def.permisos))) {
    location.hash = "#/inicio";
    return;
  }
  const activa = def.padre !== undefined ? def.padre : ruta;
  document.querySelectorAll("[data-ruta]").forEach(a => a.classList.toggle("activo", a.dataset.ruta === activa));
  const setTitulo = (t, s = "") => { document.getElementById("titulo").textContent = t; document.getElementById("subtitulo").textContent = s; document.title = t + " · Riego Yungas IA"; };
  paginaActual = { refrescar: null };
  try {
    await def.pagina(cont, { params, setTitulo, pagina: paginaActual });
  } catch (e) { error(e); }
  window.scrollTo(0, 0);
}

window.addEventListener("hashchange", navegar);
navegar();
setInterval(contarAlertas, 30000);

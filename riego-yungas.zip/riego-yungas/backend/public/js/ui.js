// Utilidades de interfaz: escape HTML, formato, íconos, avisos y modales

export const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const nf = (d) => new Intl.NumberFormat("es-BO", { minimumFractionDigits: d, maximumFractionDigits: d });
export const num = (v, d = 0) => (v === null || v === undefined || Number.isNaN(Number(v)) ? "—" : nf(d).format(Number(v)));
export const litros = v => num(v, 0) + " L";
export const pct = (v, d = 1) => num(v, d) + " %";
export const fechaHora = s => {
  if (!s) return "—";
  const d = new Date(String(s).replace(" ", "T"));
  return d.toLocaleString("es-BO", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
};
export const hora = s => (s ? new Date(String(s).replace(" ", "T")).toLocaleTimeString("es-BO", { hour: "2-digit", minute: "2-digit" }) : "—");
export const fechaCorta = s => (s ? new Date(String(s).slice(0, 10) + "T12:00:00").toLocaleDateString("es-BO", { day: "2-digit", month: "short" }) : "—");
export const hace = s => {
  if (!s) return "—";
  const seg = (Date.now() - new Date(String(s).replace(" ", "T")).getTime()) / 1000;
  if (seg < 60) return "hace " + Math.max(1, Math.round(seg)) + " s";
  if (seg < 3600) return "hace " + Math.round(seg / 60) + " min";
  if (seg < 86400) return "hace " + Math.round(seg / 3600) + " h";
  return "hace " + Math.round(seg / 86400) + " d";
};
export const hoyISO = () => new Date().toLocaleDateString("en-CA");
export const diasAtrasISO = n => new Date(Date.now() - n * 86400000).toLocaleDateString("en-CA");

// ------------------------------ Íconos -------------------------------
const P = {
  inicio: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
  sectores: '<rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="8" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/><rect x="13" y="13" width="8" height="8" rx="2"/>',
  gota: '<path d="M12 3c4 5.5 7 9.4 7 13a7 7 0 0 1-14 0c0-3.6 3-7.5 7-13z"/>',
  tanque: '<rect x="5" y="3" width="14" height="18" rx="3"/><path d="M5 13h14"/><path d="M9 17h6"/>',
  clima: '<path d="M7 18a4 4 0 0 1-.6-8A6 6 0 0 1 18 9a4.5 4.5 0 0 1-.5 9z"/>',
  sol: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  historial: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 3v6h6"/><path d="M12 7v5l3 3"/>',
  alerta: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>',
  campana: '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',
  sensor: '<circle cx="12" cy="12" r="2"/><path d="M8.5 8.5a5 5 0 0 0 0 7M15.5 8.5a5 5 0 0 1 0 7M5.6 5.6a9 9 0 0 0 0 12.8M18.4 5.6a9 9 0 0 1 0 12.8"/>',
  llave: '<path d="M14.7 6.3a4 4 0 0 0 5 5L22 14l-8 8-2.3-2.3a4 4 0 0 0-5-5L3 11l8-8z"/>',
  rayo: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  cerebro: '<path d="M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 3 3h1V4z"/><path d="M15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-3 3h-1V4z"/>',
  usuarios: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20a7 7 0 0 1 14 0"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14a5 5 0 0 1 6 5"/>',
  ajustes: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  escudo: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  salir: '<path d="M15 4h4v16h-4"/><path d="M10 8l-4 4 4 4M6 12h11"/>',
  play: '<path d="M7 4l13 8-13 8z"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  bateria: '<rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 11v2"/><path d="M5 10h8v4H5z"/>',
  viento: '<path d="M3 8h11a3 3 0 1 0-3-3"/><path d="M3 12h16a3 3 0 1 1-3 3"/><path d="M3 16h7"/>',
  termo: '<path d="M14 14.8V4a2 2 0 0 0-4 0v10.8a4 4 0 1 0 4 0z"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  descarga: '<path d="M12 4v11M7 10l5 5 5-5"/><path d="M4 20h16"/>',
  imprimir: '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
  mas: '<path d="M12 5v14M5 12h14"/>',
  actualizar: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
  señal: '<path d="M4 20v-3M9 20v-7M14 20v-11M19 20V4"/>',
  chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
  lluvia: '<path d="M7 14a4 4 0 0 1-.6-8A6 6 0 0 1 18 5a4.5 4.5 0 0 1-.5 9z"/><path d="M8 18l-1 3M12 18l-1 3M16 18l-1 3"/>',
  luna: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  nubesol: '<path d="M12 3v1.5M5.6 5.6l1 1M3 12h1.5M17.4 6.6l1-1"/><path d="M8.5 11a4 4 0 0 1 7.6-1.3"/><path d="M8 20a3.5 3.5 0 0 1-.5-7 5 5 0 0 1 9.6-.8A3.8 3.8 0 0 1 17 20z"/>',
  tormenta: '<path d="M7 14a4 4 0 0 1-.6-8A6 6 0 0 1 18 5a4.5 4.5 0 0 1-.5 9z"/><path d="M12 14l-2 4h3l-2 4"/>',
  niebla: '<path d="M4 9h16M3 13h18M5 17h14"/>',
  calendario: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
  basura: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  editar: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  reloj: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
};

/** Ícono del clima a partir del código WMO de Open-Meteo o de la probabilidad de lluvia */
export function iconoClima({ codigo = null, prob = 0, lluvia = 0, hora = 12, esDia = null } = {}) {
  const dia = esDia === null ? hora >= 6 && hora < 19 : esDia;
  let n;
  if (codigo !== null && codigo !== undefined) {
    n = codigo >= 95 ? "tormenta" : codigo >= 51 ? "lluvia" : codigo >= 45 ? "niebla" : codigo >= 2 ? "nubesol" : dia ? "sol" : "luna";
  } else n = prob >= 60 || lluvia >= 1 ? "lluvia" : prob >= 30 ? "nubesol" : dia ? "sol" : "luna";
  const color = { tormenta: "#b794f6", lluvia: "#4cc9f0", niebla: "#7d978a", nubesol: "#f5b041", sol: "#f5b041", luna: "#d77be8" }[n];
  return icono(n, `style="color:${color}"`);
}
export const textoClima = c => (c >= 95 ? "Tormenta" : c >= 80 ? "Chubascos" : c >= 61 ? "Lluvia" : c >= 51 ? "Llovizna" : c >= 45 ? "Niebla" : c >= 3 ? "Nublado" : c >= 1 ? "Parcialmente nublado" : "Despejado");
export const icono = (n, extra = "") => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" ${extra}>${P[n] || ""}</svg>`;

// ----------------------------- Estados -------------------------------
export const ESTADOS = {
  reposo: ["En reposo", "gris"], evaluando: ["Evaluando", "azul"], regando: ["Regando", "verde"], pospuesto: ["Pospuesto · lluvia", "ambar"],
  esperando_agua: ["Esperando agua", "ambar"], falla: ["En falla", "rojo"], mantenimiento: ["Mantenimiento", "violeta"],
};
export const pillEstado = e => { const [t, c] = ESTADOS[e] || [e, "gris"]; return `<span class="pill ${c} ${e === "regando" ? "pulso" : ""}"><span class="pt"></span>${esc(t)}</span>`; };
export const SEV = { critica: ["Crítica", "rojo"], alta: ["Alta", "ambar"], media: ["Media", "ambar"], info: ["Info", "azul"] };
export const pillSev = s => `<span class="pill ${SEV[s] ? SEV[s][1] : "gris"}">${esc(SEV[s] ? SEV[s][0] : s)}</span>`;
export const DECISION = { regar: ["Regar", "verde"], no_regar: ["No regar", "gris"], posponer: ["Posponer", "ambar"], esperar: ["Esperar agua", "ambar"], suspender: ["Suspender", "rojo"] };
export const pillDecision = d => `<span class="pill ${DECISION[d] ? DECISION[d][1] : "gris"}">${esc(DECISION[d] ? DECISION[d][0] : d)}</span>`;

// ------------------------------ Avisos -------------------------------
export function aviso(titulo, mensaje = "", tipo = "info", ms = 5000) {
  const cont = document.getElementById("avisos");
  const el = document.createElement("div");
  el.className = "aviso " + tipo;
  el.innerHTML = `<b>${esc(titulo)}</b>${esc(mensaje)}`;
  cont.prepend(el);
  setTimeout(() => el.remove(), ms);
}
export const error = e => aviso("No se pudo completar", e.message || String(e), "error", 6000);

// ------------------------------ Modales ------------------------------
export function modal({ titulo, cuerpo, botones = [] }) {
  return new Promise(resolve => {
    const fondo = document.createElement("div");
    fondo.className = "modal-fondo";
    fondo.innerHTML = `<div class="modal" role="dialog" aria-modal="true">
      <div class="modal-cab"><h3>${esc(titulo)}</h3><button class="btn fant chico" data-cerrar>${icono("x")}</button></div>
      <div class="modal-cuerpo">${cuerpo}</div>
      <div class="modal-pie">${botones.map((b, i) => `<button class="btn ${b.clase || ""}" data-i="${i}">${esc(b.texto)}</button>`).join("")}</div></div>`;
    const tecla = e => { if (e.key === "Escape") cerrar(null); };
    const cerrar = v => { fondo.remove(); document.removeEventListener("keydown", tecla); resolve(v); };
    document.addEventListener("keydown", tecla);
    fondo.addEventListener("click", async e => {
      if (e.target === fondo || e.target.closest("[data-cerrar]")) return cerrar(null);
      const b = e.target.closest("[data-i]");
      if (!b) return;
      const def = botones[Number(b.dataset.i)];
      if (def.accion) {
        b.disabled = true;
        try { const r = await def.accion(fondo); if (r !== false) cerrar(r ?? true); }
        catch (err) { error(err); }
        finally { b.disabled = false; }
      } else cerrar(def.valor ?? null);
    });
    document.body.appendChild(fondo);
    const primero = fondo.querySelector("input, select, textarea");
    if (primero) primero.focus();
  });
}

export const confirmar = (titulo, texto, clase = "prim", textoBoton = "Confirmar") =>
  modal({ titulo, cuerpo: `<p style="margin:0;color:var(--txt2);line-height:1.5">${esc(texto)}</p>`, botones: [{ texto: "Cancelar", valor: false }, { texto: textoBoton, clase, valor: true }] });

export const vacio = (t = "Sin datos") => `<div class="vacio">${esc(t)}</div>`;
export const cargando = () => `<div class="cargando"><div class="spinner"></div></div>`;
export const interruptor = (nombre, activo, extra = "") => `<label class="interruptor"><input type="checkbox" name="${esc(nombre)}" ${activo ? "checked" : ""} ${extra}><span></span></label>`;

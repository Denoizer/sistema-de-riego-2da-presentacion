// Componentes reutilizables de la interfaz
import { esc, num, litros, pillEstado, icono, hace, fechaHora, interruptor } from "./ui.js";
import { sesion } from "./api.js";
import { tanque } from "./charts.js";
import { api } from "./api.js";
import { modal, aviso, error } from "./ui.js";

/** Tarjeta de sector con humedad, umbral, estado y progreso de riego */
export function tarjetaSector(s) {
  const min = 0.10, max = 0.40;
  const pos = v => Math.max(0, Math.min(100, ((v - min) / (max - min)) * 100));
  const h = s.humedad;
  const color = h === null ? "" : h < s.umbral ? "rojo" : h < s.umbral + 0.01 ? "ambar" : "";
  const r = s.riego;
  const n = s.codigo.replace(/\D/g, "");
  return `<div class="card sector ${esc(s.estado)}" data-sector="${s.id}">
    <div class="fila" style="margin-bottom:10px">
      <div class="num-sector">${esc(n)}</div>
      <div style="min-width:0"><div style="font-weight:650;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(s.nombre)}</div>
        <div class="eti">${esc(s.cultivo)} · ${num(s.area_ha, 1)} ha · ${esc(s.modo)}</div></div>
      <div style="margin-left:auto">${pillEstado(s.estado)}</div>
    </div>
    ${sesion.puede("riego.configurar") && s.modo !== "mantenimiento" ? `<div class="fila entre" style="margin:-2px 0 10px" data-no-abrir>
      <span class="eti">Riego automático</span>${interruptor("modo" + s.id, s.modo === "automatico", `data-modo-sector="${s.id}"`)}</div>` : ""}
    <div class="fila entre"><span class="eti">Humedad del suelo</span><span class="mono peq">${h === null ? "—" : num(h, 3)} <span class="mut">/ umbral ${num(s.umbral, 3)} m³/m³</span></span></div>
    <div class="barra ${color}" style="margin:6px 0 10px"><i style="width:${h === null ? 0 : pos(h)}%"></i><span class="marca-umbral" style="left:${pos(s.umbral)}%"></span></div>
    <div class="grid g3" style="gap:8px">
      <div><div class="eti">ETc loc.</div><div class="mono">${num(s.etc_loc_mm, 2)} <span class="mut">mm/d</span></div></div>
      <div><div class="eti">Déficit</div><div class="mono">${num(s.deficit_mm, 2)} <span class="mut">mm</span></div></div>
      <div><div class="eti">T. suelo</div><div class="mono">${num(s.temp_suelo, 1)} <span class="mut">°C</span></div></div>
    </div>
    ${r ? `<div class="sep"></div>
      <div class="fila entre"><span class="eti" style="color:var(--verde)">Riego ${esc(r.tipo)} en curso</span><span class="mono peq">${num(r.caudal_lmin, 0)} L/min</span></div>
      <div class="barra azul" style="margin:6px 0"><i style="width:${r.pct}%"></i></div>
      <div class="fila entre peq"><span class="mono">${litros(r.litros)} / ${litros(r.litros_plan)}</span><span class="mut">${r.min_restantes === null ? "sin caudal" : "≈ " + num(r.min_restantes, 0) + " min restantes"}</span></div>
      ${r.motivo ? `<div class="muy-peq mut" style="margin-top:6px">Motivo <b class="mono" style="color:var(--txt2)">${esc(r.motivo)}</b> · ${esc(r.motivo_desc || "")}</div>` : ""}`
      : s.ultima_decision ? `<div class="sep"></div><div class="muy-peq mut">Última decisión <b class="mono" style="color:var(--txt2)">${esc(s.ultima_decision.codigo)}</b> · ${esc(s.ultima_decision.detalle || s.ultima_decision.descripcion)} · ${hace(s.ultima_decision.fecha)}</div>` : ""}
  </div>`;
}

/** Tarjeta del tanque con litros, porcentaje y situación */
export function tarjetaTanque(t, { botones = false } = {}) {
  const color = t.porcentaje < t.umbral_min_pct ? "rojo" : t.porcentaje < 45 ? "ambar" : "azul";
  return `<div class="card ${t.porcentaje < t.umbral_min_pct ? "borde-rojo" : ""}">
    <div class="card-t">${icono("tanque")}<h3>${esc(t.nombre)}</h3><div class="der"><span class="pill ${t.situacion === "NORMAL" ? "azul" : t.situacion === "LLENANDO" ? "verde pulso" : "rojo pulso"}"><span class="pt"></span>${esc(t.situacion)}</span></div></div>
    <div class="fila" style="gap:16px;align-items:center">
      <div style="width:110px">${tanque(t.porcentaje, t.llenando)}</div>
      <div class="col" style="flex:1">
        <div><div class="eti">Volumen disponible</div><div class="valor ${color}">${num(t.nivel_l, 0)}<small>L</small></div></div>
        <div class="mut peq">de ${num(t.capacidad_l, 0)} L · ${esc(t.tendencia)}</div>
        <div class="grid g2" style="gap:8px">
          <div><div class="eti">Salida</div><div class="mono">${num(t.caudal_salida_lmin, 0)} L/min</div></div>
          <div><div class="eti">Llenado</div><div class="mono">${t.llenando ? "abierto" : "cerrado"}</div></div>
          <div><div class="eti">Mín / Máx</div><div class="mono">${num(t.umbral_min_pct, 0)}% / ${num(t.umbral_max_pct, 0)}%</div></div>
          <div><div class="eti">Vertiente</div><div class="mono">${num(t.caudal_entrada_ls, 1)} L/s</div></div>
        </div>
        ${botones ? `<button class="btn chico ${t.llenando ? "" : "prim"}" data-llenado="${t.llenando ? 0 : 1}">${t.llenando ? "Detener llenado" : "Iniciar llenado"}</button>` : ""}
      </div>
    </div></div>`;
}

export function enlazarLlenado(cont, recargar) {
  cont.querySelectorAll("[data-llenado]").forEach(b => b.onclick = async () => {
    try {
      await api("/tanque/llenado", { metodo: "POST", cuerpo: { iniciar: b.dataset.llenado === "1" } });
      aviso(b.dataset.llenado === "1" ? "Llenado iniciado" : "Llenado detenido", "", "info");
      recargar();
    } catch (e) { error(e); }
  });
}

/** Modal de riego manual (HU-13): por litros o por minutos, con estimación del tiempo */
export function dialogoRiegoManual(s, alTerminar) {
  const q = s.caudal_nominal_lh; // L/h
  const area = (s.area_ha || 1) * 10000;
  let modo = "litros";
  const pintar = el => {
    const v = Number(el.querySelector("#cantidad").value || 0);
    const litrosV = modo === "litros" ? v : (q * v) / 60;
    const min = modo === "litros" ? (v / q) * 60 : v;
    el.querySelector("#e-litros").innerHTML = num(litrosV, 0) + "<small>L</small>";
    el.querySelector("#e-tiempo").innerHTML = (min >= 60 ? Math.floor(min / 60) + " h " + Math.round(min % 60) : num(min, 0)) + "<small>min</small>";
    el.querySelector("#e-lamina").innerHTML = num(litrosV / area, 2) + "<small>mm</small>";
    el.querySelector("#e-fin").textContent = new Date(Date.now() + min * 60000).toLocaleTimeString("es-BO", { hour: "2-digit", minute: "2-digit" });
  };
  setTimeout(() => {
    const el = document.querySelector(".modal");
    if (!el) return;
    const inp = el.querySelector("#cantidad"), rango = el.querySelector("#rango");
    inp.oninput = () => { rango.value = inp.value; pintar(el); };
    rango.oninput = () => { inp.value = rango.value; pintar(el); };
    el.querySelectorAll("[data-modo]").forEach(b => b.onclick = () => {
      modo = b.dataset.modo;
      el.querySelectorAll("[data-modo]").forEach(x => x.classList.toggle("activo", x === b));
      el.querySelector("#lbl").textContent = modo === "litros" ? "Cantidad de agua (litros)" : "Duración (minutos)";
      Object.assign(rango, modo === "litros" ? { min: 100, max: Math.floor(q * 3), step: 100 } : { min: 5, max: 180, step: 5 });
      inp.value = rango.value = modo === "litros" ? Math.round(q / 2 / 100) * 100 : 30;
      pintar(el);
    });
    pintar(el);
  }, 0);
  return modal({
    titulo: `Riego manual · ${s.nombre}`,
    cuerpo: `<div class="fila entre"><span class="eti">Indicar por</span><div class="seg"><button class="activo" data-modo="litros">Litros</button><button data-modo="minutos">Minutos</button></div></div>
      <div class="campo"><label id="lbl">Cantidad de agua (litros)</label>
        <input class="input" type="number" id="cantidad" min="100" step="100" value="${Math.round(q / 2 / 100) * 100}">
        <input type="range" id="rango" min="100" max="${Math.floor(q * 3)}" step="100" value="${Math.round(q / 2 / 100) * 100}"></div>
      <div class="estimacion">
        <div><div class="eti">Volumen</div><div class="valor verde" id="e-litros"></div></div>
        <div><div class="eti">Tardará</div><div class="valor rosa" id="e-tiempo"></div></div>
        <div><div class="eti">Lámina</div><div class="valor" id="e-lamina"></div></div>
        <div><div class="eti">Termina ≈</div><div class="valor" style="font-size:18px" id="e-fin"></div></div>
      </div>
      <div class="mut muy-peq">Caudal del sector ${num(q, 0)} L/h (${num(q / 60, 0)} L/min). El tiempo real depende del caudal medido por el caudalímetro. En modo simulación el proceso se acelera.</div>
      <div class="ayuda-error" id="err"></div>`,
    botones: [{ texto: "Cancelar", valor: false }, {
      texto: "Iniciar riego", clase: "prim", accion: async el => {
        const v = Number(el.querySelector("#cantidad").value);
        const cuerpo = modo === "litros" ? { litros: v } : { minutos: v };
        try {
          const r = await api(`/sectores/${s.id}/riego-manual`, { metodo: "POST", cuerpo });
          aviso("Riego manual iniciado", `${s.codigo}: ${num(r.litros, 0)} L en ≈ ${num(r.minutos, 0)} min`, "info");
        } catch (e) { el.querySelector("#err").textContent = e.message; return false; }
        if (alTerminar) alTerminar();
      },
    }],
  });
}

/** Enlaza los interruptores de "riego automático" de las tarjetas de sector */
export function enlazarModoSector(cont, recargar) {
  cont.querySelectorAll("[data-no-abrir]").forEach(el => el.addEventListener("click", e => e.stopPropagation()));
  cont.querySelectorAll("[data-modo-sector]").forEach(i => i.onchange = async () => {
    try {
      await api(`/sectores/${i.dataset.modoSector}/riego`, { metodo: "PUT", cuerpo: { modo: i.checked ? "automatico" : "manual" } });
      aviso(i.checked ? "Riego automático activado" : "Sector en modo solo manual", "");
      recargar();
    } catch (e) { error(e); i.checked = !i.checked; }
  });
}

export const filaNodo = n => `<tr>
  <td><b class="mono">${esc(n.codigo)}</b><div class="muy-peq mut">${esc(n.tipo)}${n.sector ? " · " + esc(n.sector) : ""}</div></td>
  <td>${n.en_linea ? '<span class="pill verde"><span class="pt"></span>En línea</span>' : '<span class="pill rojo"><span class="pt"></span>Sin conexión</span>'}</td>
  <td class="mono">${n.bateria_v ? num(n.bateria_v, 2) + " V" : "—"}</td>
  <td class="mono">${n.rssi_dbm ? n.rssi_dbm + " dBm" : "—"}</td>
  <td class="mut peq">${fechaHora(n.ultima_conexion)}</td></tr>`;

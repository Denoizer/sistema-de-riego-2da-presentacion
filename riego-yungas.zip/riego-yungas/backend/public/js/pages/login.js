// HU-01 · Inicio de sesión
import { api, sesion } from "../api.js";
import { esc, icono } from "../ui.js";

export default function login(raiz, alEntrar) {
  raiz.innerHTML = `
  <div class="login">
    <section class="login-arte">
      <div class="marca" style="border:0"><div class="logo">${icono("gota", 'style="width:20px;height:20px;color:#03140a"')}</div>
        <div><b>Riego Yungas IA</b><small>Coroico · Nor Yungas · La Paz</small></div></div>
      <div>
        <span class="pill verde pulso"><span class="pt"></span>4 sectores · 4 hectáreas</span>
        <h2 style="margin-top:16px">Riego automatizado basado en evapotranspiración y predicción climática</h2>
        <p>Cada sector recibe el agua que su cultivo necesita, en el momento oportuno: el sistema calcula la ETo FAO Penman-Monteith,
           mide la humedad del suelo, anticipa la lluvia con IA y le avisa en el celular cuánta agua hay en el tanque y por qué se riega.</p>
        <div class="grid g3" style="max-width:520px;margin-top:22px">
          <div class="card"><div class="eti">ETo</div><div class="valor verde" style="font-size:20px">FAO-56</div></div>
          <div class="card"><div class="eti">Predicción</div><div class="valor azul" style="font-size:20px">72 h</div></div>
          <div class="card"><div class="eti">Alertas</div><div class="valor rosa" style="font-size:20px">11 tipos</div></div>
        </div>
      </div>
      <div class="eti">Proyecto de grado · Sistema embebido + IA + MySQL</div>
    </section>
    <section class="login-form">
      <form class="login-caja" id="form-login" novalidate>
        <div><h2 style="margin:0 0 4px">Iniciar sesión</h2><div class="mut">Ingrese con su usuario y contraseña.</div></div>
        <div class="campo"><label for="usuario">Usuario o correo</label><input class="input" id="usuario" autocomplete="username" required></div>
        <div class="campo"><label for="clave">Contraseña</label><input class="input" id="clave" type="password" autocomplete="current-password" required></div>
        <div class="ayuda-error" id="error"></div>
        <button class="btn prim bloque" id="btn-entrar" type="submit">Ingresar</button>
        <div class="sep"></div>
        <div class="eti">Cuentas de demostración (clic para completar)</div>
        <div class="cuentas">
          ${[["admin", "Admin2026!", "Administrador", "violeta", "Usuarios, sectores, reglas, IA y auditoría"],
             ["agricultor", "Agro2026!", "Agricultor", "verde", "Panel, riego manual, tanque, clima e historial"],
             ["tecnico", "Tecnico2026!", "Técnico", "azul", "Nodos, sensores, alertas y mantenimiento"]]
            .map(([u, c, r, col, d]) => `<div class="cuenta" data-u="${u}" data-c="${c}"><span class="pill ${col}">${r}</span><div><b class="mono">${u}</b> / <span class="mono">${esc(c)}</span><div class="mut muy-peq">${d}</div></div></div>`).join("")}
        </div>
      </form>
    </section>
  </div>`;

  const f = raiz.querySelector("#form-login");
  raiz.querySelectorAll(".cuenta").forEach(c => c.onclick = () => { f.usuario.value = c.dataset.u; f.clave.value = c.dataset.c; f.clave.focus(); });
  f.onsubmit = async e => {
    e.preventDefault();
    const err = raiz.querySelector("#error");
    err.textContent = "";
    f.usuario.classList.toggle("error", !f.usuario.value.trim());
    f.clave.classList.toggle("error", !f.clave.value);
    if (!f.usuario.value.trim() || !f.clave.value) { err.textContent = "Complete el usuario y la contraseña."; return; }
    const b = raiz.querySelector("#btn-entrar");
    b.disabled = true; b.textContent = "Verificando…";
    try {
      const r = await api("/auth/login", { metodo: "POST", cuerpo: { usuario: f.usuario.value, clave: f.clave.value } });
      sesion.guardar(r.token, r.usuario);
      raiz.innerHTML = "";
      alEntrar();
    } catch (ex) {
      err.textContent = ex.message;
    } finally { b.disabled = false; b.textContent = "Ingresar"; }
  };
}

// Panel de control: una vista distinta por rol (agricultor, técnico, administrador)
import { api, sesion } from "../api.js";
import { esc, num, icono, hace, pillSev, pillDecision, pillEstado, cargando, vacio, error, aviso, interruptor, iconoClima, textoClima } from "../ui.js";
import { tarjetaSector, tarjetaTanque, enlazarLlenado, filaNodo, enlazarModoSector } from "../componentes.js";
import { lineas } from "../charts.js";

const kpi = (ic, eti, valor, sub = "", clase = "") =>
  `<div class="card kpi"><div class="fila entre"><span class="eti">${esc(eti)}</span><span class="ic">${icono(ic)}</span></div>
   <div class="valor ${clase}">${valor}</div><div class="mut muy-peq">${sub}</div></div>`;

function cabeceraFinca(p) {
  const u = sesion.usuario;
  return `<div class="card hero" style="margin-bottom:14px">
    <div class="fila entre envolver">
      <div><div class="eti">Finca de estudio · Coroico, Nor Yungas · 1 700 m s. n. m.</div>
        <div style="font-size:20px;font-weight:700;margin-top:4px">Hola, ${esc(u.nombre)} 👋</div>
        <div class="mut peq">Actualizado ${hace(p.fecha)} · ${p.nodos_en_linea}/${p.nodos_total} nodos en línea</div></div>
      <div class="fila envolver">
        ${sesion.puede("riego.configurar") ? `<label class="fila" style="gap:8px;cursor:pointer"><span class="eti">Riego automático</span>${interruptor("auto", p.riego_automatico, 'id="sw-auto"')}</label>` : ""}
        <span class="pill ${p.riego_automatico ? "verde" : "ambar"}"><span class="pt"></span>${p.riego_automatico ? "Automático activo" : "Automático pausado"}</span>
        ${sesion.puede("riego.manual") ? `<a class="btn rosa chico" href="#/riego">${icono("gota")} Riego manual</a>` : ""}
        ${p.simulador ? `<span class="pill violeta" title="Sin hardware conectado: el simulador reemplaza a los nodos">Simulación ×${p.aceleracion}</span>` : '<span class="pill azul">Hardware real</span>'}
      </div>
    </div></div>`;
}

function climaHoy(p) {
  const c = p.clima, pr = p.pronostico_24h, x = p.clima_externo;
  return `<div class="card">
    ${x ? `<div class="fila" style="gap:12px;margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid var(--line)">
      <div style="width:38px">${iconoClima({ codigo: x.codigo, esDia: x.es_dia })}</div>
      <div><div class="eti">Ahora en Coroico · Open-Meteo</div><div style="font-weight:650">${num(x.temp_c, 1)} °C · ${esc(textoClima(x.codigo))}</div>
      <div class="mut muy-peq">Sensación ${num(x.sensacion_c, 0)} °C · HR ${num(x.hr_pct, 0)} % · nubes ${num(x.nubosidad_pct, 0)} %</div></div></div>` : ""}
    <div class="card-t">${icono("sol")}<h3>Clima en la finca</h3><div class="der"><span class="eti">estación meteorológica</span></div></div>
    <div class="grid g3" style="gap:10px">
      <div><div class="eti">Temperatura</div><div class="valor" style="font-size:22px">${num(c.temp_c, 1)}<small>°C</small></div></div>
      <div><div class="eti">Humedad rel.</div><div class="valor" style="font-size:22px">${num(c.hr_pct, 0)}<small>%</small></div></div>
      <div><div class="eti">Radiación</div><div class="valor" style="font-size:22px">${num(c.radiacion_wm2, 0)}<small>W/m²</small></div></div>
      <div><div class="eti">Viento 2 m</div><div class="mono">${num(c.viento_ms, 1)} m/s</div></div>
      <div><div class="eti">Lluvia 1 h</div><div class="mono">${num(c.lluvia_1h, 1)} mm</div></div>
      <div><div class="eti">ETo ref.</div><div class="mono" style="color:var(--verde)">${num(c.eto_ref, 2)} mm/d</div></div>
    </div>
    <div class="sep"></div>
    <div class="fila entre"><div><div class="eti">Predicción IA · próximas 24 h</div>
      <div class="peq" style="margin-top:4px">Lluvia <b class="mono">${pr ? num(pr.lluvia_mm, 1) : "—"} mm</b> · prob. máx. <b class="mono">${pr ? num(pr.prob_max, 0) : "—"} %</b> · ${pr ? num(pr.tmin, 0) + "–" + num(pr.tmax, 0) + " °C" : ""}</div></div>
      <a class="btn chico" href="#/clima">Ver 72 h</a></div>
  </div>`;
}

function tarjetaFallas(fallas) {
  return `<div class="card ${fallas.length ? "borde-rojo" : ""}">
    <div class="card-t">${icono("alerta", 'style="width:18px;height:18px;color:' + (fallas.length ? "var(--rojo)" : "var(--verde)") + '"')}<h3>Fallas del sistema de riego</h3>
      <div class="der"><span class="pill ${fallas.length ? "rojo pulso" : "verde"}"><span class="pt"></span>${fallas.length ? fallas.length + " activa(s)" : "Sin fallas"}</span></div></div>
    ${fallas.length ? `<div class="col">${fallas.map(f => `<div class="falla-item"><div style="min-width:0;flex:1">
      <div class="fila entre envolver"><div class="fila" style="gap:6px">${pillSev(f.severidad)}<b class="peq">${esc(f.codigo)} · ${esc(f.nombre)}</b>${f.sector ? `<span class="pill gris">${esc(f.sector)}</span>` : ""}</div><span class="eti">${hace(f.fecha)}</span></div>
      <div class="mut peq" style="margin-top:4px">${esc(f.mensaje)}</div>
      ${f.agricultores ? `<div class="muy-peq" style="margin-top:4px;color:var(--rosa)">Agricultor a cargo: ${esc(f.agricultores)} · notificado</div>` : ""}</div></div>`).join("")}
      ${sesion.puede("alertas.atender") ? `<a class="btn prim chico" href="#/alertas">Atender fallas</a>` : `<div class="mut muy-peq">El técnico fue notificado y atenderá la falla.</div>`}</div>`
      : vacio("Todos los nodos, válvulas y sensores funcionan correctamente ✔")}
  </div>`;
}

function alertasResumen(lista, puedeAtender) {
  return `<div class="card">
    <div class="card-t">${icono("alerta")}<h3>Alertas activas</h3><div class="der"><a class="btn chico" href="#/alertas">${puedeAtender ? "Atender" : "Ver todas"}</a></div></div>
    ${lista.length ? `<div class="col">${lista.slice(0, 4).map(a => `<div class="alerta-item"><div class="franja sev-${a.severidad}"></div>
      <div style="min-width:0"><div class="fila" style="gap:6px">${pillSev(a.severidad)}<b class="peq">${esc(a.codigo)} · ${esc(a.nombre)}</b></div>
      <div class="mut peq" style="margin-top:4px">${esc(a.mensaje)}</div><div class="eti" style="margin-top:4px">${hace(a.fecha)}</div></div></div>`).join("")}</div>` : vacio("Sin alertas pendientes ✔")}
  </div>`;
}

async function panelAgricultorAdmin(cont, p, esAdmin) {
  const alertas = await api("/alertas");
  const hoyL = p.consumo_hoy.litros;
  let extra = "";
  if (esAdmin) {
    const [dec, ia] = await Promise.all([api("/decisiones?limite=8"), api("/ia/modelos")]);
    const sec = ia.modelos.filter(m => m.tipo === "sector");
    extra = `<div class="grid g2" style="margin-top:14px">
      <div class="card"><div class="card-t">${icono("rayo")}<h3>Decisiones recientes del motor</h3><div class="der"><a class="btn chico" href="#/automatizacion">Reglas</a></div></div>
        <div class="timeline">${dec.map(d => `<div class="tl-item"><div class="tl-ic">${icono(d.decision === "regar" ? "gota" : d.decision === "posponer" ? "lluvia" : "check")}</div>
          <div style="min-width:0;flex:1"><div class="fila entre"><span class="fila" style="gap:6px"><b class="mono">${esc(d.sector)}</b>${pillDecision(d.decision)}<span class="mono muy-peq mut">${esc(d.motivo)}</span></span><span class="eti">${hace(d.fecha)}</span></div>
          <div class="mut muy-peq" style="margin-top:3px">${esc(d.detalle || d.motivo_desc)}</div></div></div>`).join("") || vacio()}</div></div>
      <div class="card"><div class="card-t">${icono("cerebro")}<h3>Aprendizaje de la IA por sector</h3><div class="der"><a class="btn chico" href="#/ia">Modelos</a></div></div>
        <table class="tabla"><thead><tr><th>Sector</th><th>Fase</th><th>Muestras</th><th>MAE θ 24 h</th></tr></thead><tbody>
        ${sec.map(m => `<tr><td class="mono">${esc(m.sector)}</td><td><span class="pill ${m.fase === "adaptacion" ? "verde" : m.fase === "recomendacion" ? "azul" : "gris"}">${esc(m.fase)}</span></td><td class="mono">${m.n_muestras}</td><td class="mono">${num(m.mae, 4)}</td></tr>`).join("")}
        </tbody></table></div></div>`;
  }
  cont.innerHTML = cabeceraFinca(p) + `
    <div class="grid g4" style="margin-bottom:14px">
      ${kpi("tanque", "Agua en tanque", num(p.tanque.nivel_l, 0) + "<small>L</small>", num(p.tanque.porcentaje, 1) + " % · " + esc(p.tanque.tendencia), p.tanque.porcentaje < p.tanque.umbral_min_pct ? "rojo" : "azul")}
      ${kpi("gota", "Distribuido hoy", num(hoyL, 0) + "<small>L</small>", p.consumo_hoy.n + " riego(s) hoy", "verde")}
      ${kpi("sol", "ETo de referencia", num(p.clima.eto_ref, 2) + "<small>mm/d</small>", "FAO Penman-Monteith (día anterior)")}
      ${kpi("alerta", "Alertas activas", Object.values(p.alertas).reduce((a, b) => a + b, 0), (p.alertas.critica || 0) + " críticas · " + (p.alertas.alta || 0) + " altas", p.alertas.critica ? "rojo" : "")}
    </div>
    <div class="grid" style="grid-template-columns:minmax(0,2fr) minmax(0,1fr);gap:14px" id="cuerpo">
      <div class="col" style="gap:14px">
        <div class="card-t" style="margin:0"><h3>Sectores de riego</h3><div class="der"><a class="btn chico" href="#/sectores">Gestionar</a></div></div>
        <div class="grid g2">${p.sectores.map(tarjetaSector).join("")}</div>
      </div>
      <div class="col" style="gap:14px">
        ${tarjetaFallas(p.fallas)}
        ${tarjetaTanque(p.tanque, { botones: sesion.puede("tanque.operar") })}
        ${climaHoy(p)}
        ${alertasResumen(alertas.filter(a => !p.fallas.some(f => f.id === a.id)), sesion.puede("alertas.atender"))}
      </div>
    </div>${extra}`;
  if (window.innerWidth < 1100) cont.querySelector("#cuerpo").style.gridTemplateColumns = "1fr";
}

async function panelTecnico(cont, p) {
  const [alertas, nodos] = await Promise.all([api("/alertas"), api("/nodos")]);
  const fallas = nodos.nodos.flatMap(n => n.sensores.filter(s => s.estado === "falla").map(s => ({ ...s, nodo: n.codigo })));
  const batMin = Math.min(...nodos.nodos.filter(n => n.bateria_v).map(n => n.bateria_v));
  const series = [1, 2, 3, 4].map((id, i) => ({
    nombre: "Nodo S" + id, color: ["#22c55e", "#38bdf8", "#f59e0b", "#a78bfa"][i],
    puntos: nodos.bateria.filter(b => b.sector_id === id).map(b => ({ x: b.fecha, y: b.bateria_v })),
  }));
  cont.innerHTML = cabeceraFinca(p) + `
    <div class="grid g4" style="margin-bottom:14px">
      ${kpi("chip", "Nodos en línea", `${p.nodos_en_linea}<small>/ ${p.nodos_total}</small>`, "LoRa 915 MHz", p.nodos_en_linea < p.nodos_total ? "rojo" : "verde")}
      ${kpi("alerta", "Alertas por atender", alertas.length, alertas.filter(a => a.severidad === "critica").length + " críticas", alertas.length ? "ambar" : "verde")}
      ${kpi("sensor", "Sensores con falla", fallas.length, fallas.map(f => f.nodo + " " + (f.posicion || "")).join(", ") || "todos operativos", fallas.length ? "rojo" : "verde")}
      ${kpi("bateria", "Batería mínima", num(batMin, 2) + "<small>V</small>", "umbral 11,8 V", batMin < 11.8 ? "rojo" : "")}
    </div>
    <div class="grid g2">
      <div class="card"><div class="card-t">${icono("chip")}<h3>Estado de nodos</h3><div class="der"><a class="btn chico" href="#/dispositivos">Detalle</a></div></div>
        <div class="tabla-scroll"><table class="tabla"><thead><tr><th>Nodo</th><th>Estado</th><th>Batería</th><th>Señal</th><th>Último reporte</th></tr></thead>
        <tbody>${nodos.nodos.map(filaNodo).join("")}</tbody></table></div></div>
      ${tarjetaFallas(p.fallas)}
      <div class="card"><div class="card-t">${icono("bateria")}<h3>Tensión de baterías (24 h)</h3></div>
        ${lineas(series, { alto: 200, umbrales: [{ y: 11.8, color: "#ef4444", texto: "mín. 11,8 V" }], fy: v => num(v, 1) })}</div>
      <div class="card"><div class="card-t">${icono("sectores")}<h3>Sectores</h3></div>
        <table class="tabla"><thead><tr><th>Sector</th><th>Modo</th><th>Estado</th><th>θ</th><th>Caudal</th></tr></thead><tbody>
        ${p.sectores.map(s => `<tr data-sector="${s.id}" style="cursor:pointer"><td><b class="mono">${esc(s.codigo)}</b> <span class="mut peq">${esc(s.cultivo)}</span></td><td class="peq">${esc(s.modo)}</td>
          <td>${pillEstado(s.estado)}</td><td class="mono">${num(s.humedad, 3)}</td><td class="mono">${num(s.caudal_lmin, 0)} L/min</td></tr>`).join("")}</tbody></table></div>
      ${tarjetaTanque(p.tanque)}
      <div class="card"><div class="card-t">${icono("llave")}<h3>Acciones rápidas</h3></div>
        <div class="col"><a class="btn" href="#/mantenimiento">${icono("llave")} Registrar mantenimiento</a>
        <a class="btn" href="#/dispositivos">${icono("sensor")} Calibrar sensores</a>
        <a class="btn" href="#/mantenimiento">${icono("rayo")} Pruebas de falla (simulación)</a></div></div>
    </div>`;
}

export default async function inicio(cont, { setTitulo, pagina }) {
  const u = sesion.usuario;
  setTitulo("Panel de control", u.rol === "tecnico" ? "Vista del técnico de mantenimiento" : u.rol === "admin" ? "Vista del administrador" : "Vista del agricultor");
  cont.innerHTML = cargando();
  const dibujar = async () => {
    const p = await api("/panel");
    if (u.rol === "tecnico") await panelTecnico(cont, p);
    else await panelAgricultorAdmin(cont, p, u.rol === "admin");
    cont.querySelectorAll("[data-sector]").forEach(el => el.onclick = () => { location.hash = "#/sector/" + el.dataset.sector; });
    enlazarLlenado(cont, dibujar);
    enlazarModoSector(cont, dibujar);
    const sw = cont.querySelector("#sw-auto");
    if (sw) sw.onchange = async () => {
      try { await api("/config", { metodo: "PUT", cuerpo: { parametros: { riego_automatico: sw.checked ? 1 : 0 } } }); aviso(sw.checked ? "Riego automático activado" : "Riego automático pausado", sw.checked ? "El motor vuelve a decidir los riegos" : "Solo se regará de forma manual o programada"); dibujar(); }
      catch (e) { error(e); sw.checked = !sw.checked; }
    };
  };
  try { await dibujar(); } catch (e) { error(e); }
  pagina.refrescar = dibujar;
}

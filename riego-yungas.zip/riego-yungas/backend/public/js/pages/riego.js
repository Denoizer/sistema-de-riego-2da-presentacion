// Riego manual y programado: el usuario indica los litros, el sistema calcula cuánto tardará
import { api, sesion } from "../api.js";
import { esc, num, icono, cargando, error, aviso, confirmar, interruptor, pillEstado, fechaHora, vacio, hoyISO } from "../ui.js";

const durTexto = min => (min >= 60 ? `${Math.floor(min / 60)} h ${Math.round(min % 60)} min` : `${num(min, 0)} min`);

export default async function riego(cont, { setTitulo, pagina }) {
  setTitulo("Riego manual y programado", "Indique los litros y el sistema calcula el tiempo de riego");
  cont.innerHTML = cargando();
  let sel = null, litrosSel = 5000;

  const dibujar = async () => {
    const [sectores, programados, tanque, cfg] = await Promise.all([api("/sectores"), api("/programados"), api("/tanque?horas=1"), api("/config").catch(() => null)]);
    const maxMin = cfg ? Number((cfg.parametros.find(p => p.clave === "max_min_riego") || {}).valor || 180) : 180;
    if (!sel || !sectores.find(s => s.id === sel)) sel = sectores[0] ? sectores[0].id : null;
    const s = sectores.find(x => x.id === sel);
    const enCurso = sectores.find(x => x.riego);
    const maxL = s ? Math.floor((s.caudal_nominal_lh * maxMin) / 60) : 1000;
    litrosSel = Math.min(Math.max(100, litrosSel), maxL);
    cont.innerHTML = `
    <div class="grid" style="grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:14px" id="g1">
      <div class="card hero">
        <div class="card-t">${icono("gota")}<h3>Nuevo riego</h3><div class="der">${enCurso ? `<span class="pill verde pulso"><span class="pt"></span>${esc(enCurso.codigo)} regando</span>` : '<span class="pill gris">Ningún sector regando</span>'}</div></div>
        <div class="eti" style="margin-bottom:6px">1 · Elija el sector</div>
        <div class="grid g2" style="gap:8px;margin-bottom:14px">${sectores.map(x => `<button class="card" data-sel="${x.id}" style="padding:10px;text-align:left;cursor:pointer;${x.id === sel ? "border-color:var(--rosa);box-shadow:0 0 0 1px var(--rosa)" : ""}">
          <div class="fila entre"><b>${esc(x.codigo)} · ${esc(x.cultivo)}</b>${pillEstado(x.estado)}</div>
          <div class="mut muy-peq" style="margin-top:4px">θ ${num(x.humedad, 3)} / umbral ${num(x.umbral, 3)} · ${num(x.caudal_nominal_lh, 0)} L/h</div></button>`).join("") || vacio("No tiene sectores asignados")}</div>
        ${s ? `
        <div class="eti" style="margin-bottom:6px">2 · Cantidad de agua</div>
        <div class="fila" style="gap:12px;align-items:center">
          <input class="input" type="number" id="litros" min="100" max="${maxL}" step="100" value="${litrosSel}" style="width:150px;font-size:18px;font-weight:700"><span class="mono">litros</span>
          <div class="fila envolver" style="gap:6px">${[1000, 5000, 10000, 20000].filter(v => v <= maxL).map(v => `<button class="btn chico" data-rapido="${v}">${num(v, 0)} L</button>`).join("")}
            <button class="btn chico" data-rapido="${Math.round(s.etc_loc_mm / (s.eficiencia || 0.9) * s.area_ha * 10000 / 100) * 100}" title="Reposición de un día de ETc">ETc de 1 día</button></div>
        </div>
        <input type="range" id="rango" min="100" max="${maxL}" step="100" value="${litrosSel}" style="margin:10px 0 14px">
        <div class="estimacion" id="estimacion"></div>
        <div class="mut muy-peq" style="margin-top:8px">Tanque disponible: <b class="mono">${num(tanque.nivel_l, 0)} L</b> (${num(tanque.porcentaje, 1)} %) · caudal ${num(s.caudal_nominal_lh / 60, 0)} L/min · máximo ${maxMin} min por riego (${num(maxL, 0)} L).</div>
        <div class="sep"></div>
        <div class="eti" style="margin-bottom:8px">3 · ¿Cuándo?</div>
        <div class="fila envolver" style="align-items:flex-end;gap:10px">
          ${sesion.puede("riego.manual") ? `<button class="btn prim" id="ahora" ${["falla", "mantenimiento"].includes(s.estado) || enCurso ? "disabled" : ""}>${icono("play")} Regar ahora</button>` : ""}
          ${sesion.puede("riego.programar") ? `
          <div class="campo"><label>Fecha</label><input class="input" type="date" id="fecha" value="${hoyISO()}" min="${hoyISO()}"></div>
          <div class="campo"><label>Hora</label><input class="input" type="time" id="hora" value="17:30"></div>
          <div class="campo"><label>Repetir</label><select class="input" id="repetir"><option value="una_vez">Una vez</option><option value="diario">Todos los días</option></select></div>
          <button class="btn rosa" id="programar">${icono("calendario")} Programar</button>` : ""}
        </div>
        ${enCurso ? `<div class="mut muy-peq" style="margin-top:8px">El riego es secuencial: ${esc(enCurso.nombre)} se está regando (${num(enCurso.riego.pct, 0)} %). Puede programar el riego o esperar.</div>` : ""}
        <div class="ayuda-error" id="err"></div>` : ""}
      </div>
      <div class="col" style="gap:14px">
        ${enCurso ? `<div class="card borde-verde"><div class="card-t">${icono("gota")}<h3>Riego en curso · ${esc(enCurso.codigo)}</h3></div>
          <div class="barra azul" style="height:10px"><i style="width:${enCurso.riego.pct}%"></i></div>
          <div class="fila entre mono peq" style="margin-top:6px"><span>${num(enCurso.riego.litros, 0)} / ${num(enCurso.riego.litros_plan, 0)} L</span><span>${num(enCurso.riego.caudal_lmin, 0)} L/min</span><span>${enCurso.riego.min_restantes === null ? "—" : "≈ " + num(enCurso.riego.min_restantes, 0) + " min"}</span></div>
          <div class="mut muy-peq" style="margin-top:6px">${esc(enCurso.riego.tipo)} · ${esc(enCurso.riego.motivo || "")} ${esc(enCurso.riego.motivo_desc || "")}</div>
          ${sesion.puede("riego.manual") ? `<button class="btn peligro chico" style="margin-top:10px" id="detener" data-id="${enCurso.id}">${icono("stop")} Detener riego</button>` : ""}</div>` : ""}
        <div class="card"><div class="card-t">${icono("calendario")}<h3>Riegos programados</h3><div class="der"><span class="eti">${programados.filter(p => p.activo).length} activos</span></div></div>
          ${programados.length ? `<div class="col">${programados.map(p => `<div class="card" style="padding:12px;${p.activo ? "" : "opacity:.55"}">
            <div class="fila entre"><div><b class="mono">${esc(p.sector)}</b> <span class="pill ${p.repetir === "diario" ? "rosa" : "gris"}">${p.repetir === "diario" ? "Diario" : "Una vez"}</span></div>
              ${sesion.puede("riego.programar") ? interruptor("p" + p.id, p.activo, `data-activo="${p.id}"`) : ""}</div>
            <div class="grid g3" style="gap:8px;margin-top:8px">
              <div><div class="eti">Litros</div>${sesion.puede("riego.programar") ? `<input class="input" style="padding:5px 8px" type="number" step="100" value="${p.litros}" data-litros="${p.id}">` : `<div class="mono">${num(p.litros, 0)}</div>`}</div>
              <div><div class="eti">Tardará</div><div class="mono" style="color:var(--rosa)">${durTexto(p.minutos_estimados)}</div></div>
              <div><div class="eti">Hora</div>${sesion.puede("riego.programar") ? `<input class="input" style="padding:5px 8px" type="time" value="${String(p.hora).slice(0, 5)}" data-hora="${p.id}">` : `<div class="mono">${String(p.hora).slice(0, 5)}</div>`}</div>
            </div>
            <div class="fila entre" style="margin-top:8px"><span class="mut muy-peq">${p.activo ? "Próximo: " + fechaHora(p.proxima_ejecucion) : "Inactivo"}${p.ultima_ejecucion ? " · último " + fechaHora(p.ultima_ejecucion) : ""} · ${esc(p.creado_por || "")}</span>
              ${sesion.puede("riego.programar") ? `<div class="fila" style="gap:6px"><button class="btn chico" data-guardar="${p.id}">${icono("check")} Guardar</button><button class="btn chico fant" data-borrar="${p.id}" title="Eliminar">${icono("basura")}</button></div>` : ""}</div>
          </div>`).join("")}</div>` : vacio("Sin riegos programados")}
        </div>
      </div>
    </div>`;
    if (window.innerWidth < 1100) cont.querySelector("#g1").style.gridTemplateColumns = "1fr";
    const $ = q => cont.querySelector(q);
    cont.querySelectorAll("[data-sel]").forEach(b => b.onclick = () => { sel = Number(b.dataset.sel); dibujar(); });
    if (!s) return;

    const estimar = () => {
      const l = Number($("#litros").value || 0);
      litrosSel = l;
      const min = (l / s.caudal_nominal_lh) * 60;
      const fin = new Date(Date.now() + min * 60000).toLocaleTimeString("es-BO", { hour: "2-digit", minute: "2-digit" });
      const alcanza = l <= tanque.nivel_l;
      $("#estimacion").innerHTML = `
        <div><div class="eti">Tardará</div><div class="valor rosa">${durTexto(min).replace(" min", "<small>min</small>")}</div></div>
        <div><div class="eti">Lámina aplicada</div><div class="valor">${num(l / (s.area_ha * 10000), 2)}<small>mm</small></div></div>
        <div><div class="eti">Termina ≈</div><div class="valor">${fin}</div></div>
        <div><div class="eti">Tanque</div><div class="valor ${alcanza ? "verde" : "rojo"}" style="font-size:16px">${alcanza ? "Alcanza ✔" : "Insuficiente"}</div><div class="muy-peq mut">${num(Math.max(0, tanque.nivel_l - l), 0)} L restantes</div></div>`;
    };
    $("#litros").oninput = () => { $("#rango").value = $("#litros").value; estimar(); };
    $("#rango").oninput = () => { $("#litros").value = $("#rango").value; estimar(); };
    cont.querySelectorAll("[data-rapido]").forEach(b => b.onclick = () => { $("#litros").value = $("#rango").value = b.dataset.rapido; estimar(); });
    estimar();

    if ($("#ahora")) $("#ahora").onclick = async () => {
      const l = Number($("#litros").value);
      if (!(await confirmar("Regar ahora", `Se aplicarán ${num(l, 0)} L en ${s.nombre} durante ≈ ${durTexto((l / s.caudal_nominal_lh) * 60)}.`, "prim", "Regar"))) return;
      try { const r = await api(`/sectores/${s.id}/riego-manual`, { metodo: "POST", cuerpo: { litros: l } }); aviso("Riego iniciado", `${s.codigo}: ${num(r.litros, 0)} L · ≈ ${num(r.minutos, 0)} min`); dibujar(); }
      catch (e) { $("#err").textContent = e.message; }
    };
    if ($("#programar")) $("#programar").onclick = async () => {
      try {
        const r = await api("/programados", { metodo: "POST", cuerpo: { sector_id: s.id, litros: Number($("#litros").value), hora: $("#hora").value, fecha: $("#fecha").value, repetir: $("#repetir").value } });
        aviso("Riego programado", `${s.codigo}: ${num($("#litros").value, 0)} L · ${fechaHora(r.proxima_ejecucion)} · ≈ ${durTexto(r.minutos_estimados)}`);
        dibujar();
      } catch (e) { $("#err").textContent = e.message; }
    };
    if ($("#detener")) $("#detener").onclick = async () => {
      if (!(await confirmar("Detener riego", "Se cerrará la válvula del sector.", "peligro", "Detener"))) return;
      try { await api(`/sectores/${$("#detener").dataset.id}/detener`, { metodo: "POST" }); aviso("Riego detenido"); dibujar(); } catch (e) { error(e); }
    };
    cont.querySelectorAll("[data-activo]").forEach(i => i.onchange = async () => {
      try { await api("/programados/" + i.dataset.activo, { metodo: "PUT", cuerpo: { activo: i.checked } }); aviso(i.checked ? "Programación activada" : "Programación pausada"); dibujar(); } catch (e) { error(e); i.checked = !i.checked; }
    });
    cont.querySelectorAll("[data-guardar]").forEach(b => b.onclick = async () => {
      const id = b.dataset.guardar;
      try { await api("/programados/" + id, { metodo: "PUT", cuerpo: { litros: Number(cont.querySelector(`[data-litros="${id}"]`).value), hora: cont.querySelector(`[data-hora="${id}"]`).value } }); aviso("Programación actualizada"); dibujar(); } catch (e) { error(e); }
    });
    cont.querySelectorAll("[data-borrar]").forEach(b => b.onclick = async () => {
      if (!(await confirmar("Eliminar programación", "¿Eliminar este riego programado?", "peligro", "Eliminar"))) return;
      try { await api("/programados/" + b.dataset.borrar, { metodo: "DELETE" }); aviso("Programación eliminada"); dibujar(); } catch (e) { error(e); }
    });
  };
  try { await dibujar(); } catch (e) { error(e); }
  pagina.refrescar = dibujar;
}

// Mantenimiento: registro de trabajos, sectores en mantenimiento y pruebas de falla
import { api } from "../api.js";
import { esc, icono, cargando, error, aviso, confirmar, fechaHora, pillEstado, vacio } from "../ui.js";

const FALLAS = [
  ["valvula", "Válvula trabada (sin caudal)", "A-03"], ["fuga", "Fuga con válvula cerrada", "A-04"], ["nodo", "Nodo sin comunicación", "A-05"],
  ["sensor", "Sensor de humedad dañado", "A-06"], ["bateria", "Batería baja", "A-07"], ["llenado", "Falla en el llenado del tanque", "A-02"],
];

export default async function mantenimiento(cont, { setTitulo, pagina }) {
  setTitulo("Mantenimiento", "Trabajos realizados, sectores en mantenimiento y pruebas del sistema");
  cont.innerHTML = cargando();
  const dibujar = async () => {
    const [lista, sectores, nodos] = await Promise.all([api("/mantenimientos"), api("/sectores"), api("/nodos")]);
    cont.innerHTML = `
    <div class="grid g2">
      <div class="card"><div class="card-t">${icono("llave")}<h3>Registrar mantenimiento</h3></div>
        <div class="grid g2">
          <div class="campo"><label>Tipo</label><select class="input" id="tipo"><option value="preventivo">Preventivo</option><option value="correctivo">Correctivo</option><option value="calibracion">Calibración</option></select></div>
          <div class="campo"><label>Sector</label><select class="input" id="sector"><option value="">General</option>${sectores.map(s => `<option value="${s.id}">${esc(s.codigo)} · ${esc(s.cultivo)}</option>`).join("")}</select></div>
        </div>
        <div class="campo" style="margin-top:10px"><label>Descripción del trabajo</label><textarea class="input" id="desc" rows="3" placeholder="Ej.: limpieza de filtros y revisión de goteros del sector 2"></textarea></div>
        <div class="ayuda-error" id="err"></div>
        <button class="btn prim" id="registrar">Registrar</button>
      </div>
      <div class="card"><div class="card-t">${icono("sectores")}<h3>Sectores</h3></div>
        <table class="tabla"><thead><tr><th>Sector</th><th>Estado</th><th></th></tr></thead><tbody>
        ${sectores.map(s => `<tr><td><b class="mono">${esc(s.codigo)}</b> <span class="mut peq">${esc(s.cultivo)}</span></td><td>${pillEstado(s.estado)}</td>
          <td style="text-align:right"><button class="btn chico ${s.modo === "mantenimiento" ? "prim" : ""}" data-mant="${s.id}" data-act="${s.modo === "mantenimiento" ? 0 : 1}">${s.modo === "mantenimiento" ? "Rehabilitar" : "Mantenimiento"}</button></td></tr>`).join("")}
        </tbody></table>
        <div class="mut muy-peq" style="margin-top:8px">Un sector en «falla» se rehabilita al atender su alerta en la sección Alertas.</div></div>
      ${nodos.simulador ? `<div class="card span2 borde-ambar"><div class="card-t">${icono("rayo")}<h3>Pruebas de falla · modo simulación</h3><div class="der"><span class="pill violeta">Solo sin hardware</span></div></div>
        <div class="mut peq" style="margin-bottom:12px">Inyecte una falla en el simulador de campo para verificar que el sistema la detecta, genera la alerta y notifica a la app (pruebas PF-07 y PI-04 del marco práctico).</div>
        <div class="fila envolver" style="align-items:flex-end">
          <div class="campo"><label>Falla</label><select class="input" id="falla">${FALLAS.map(([k, t, c]) => `<option value="${k}">${c} · ${t}</option>`).join("")}</select></div>
          <div class="campo"><label>Sector</label><select class="input" id="fsector">${sectores.map(s => `<option value="${s.id}">${esc(s.codigo)}</option>`).join("")}</select></div>
          <button class="btn ambar" id="inyectar">Inyectar falla</button>
          <button class="btn" id="limpiar">Reparar todo</button>
          <div class="campo"><label>Lluvia simulada (mm/h)</label><input class="input" id="lluvia" type="number" value="0" style="width:120px"></div>
          <button class="btn" id="btn-lluvia">${icono("lluvia")} Aplicar</button>
        </div>
        <div class="peq mut" style="margin-top:10px">Fallas activas: <span class="mono">${Object.entries(nodos.fallas).filter(([, v]) => (Array.isArray(v) ? v.length : v)).map(([k, v]) => k + (Array.isArray(v) ? " (" + v.map(x => "S" + x).join(", ") + ")" : "")).join(" · ") || "ninguna"}</span></div>
      </div>` : ""}
      <div class="card span2"><div class="card-t">${icono("historial")}<h3>Historial de mantenimientos</h3></div>
        <div class="tabla-scroll"><table class="tabla"><thead><tr><th>Fecha</th><th>Tipo</th><th>Sector / nodo</th><th>Descripción</th><th>Técnico</th></tr></thead><tbody>
        ${lista.map(m => `<tr><td class="peq">${fechaHora(m.fecha)}</td><td><span class="pill ${m.tipo === "correctivo" ? "ambar" : m.tipo === "calibracion" ? "azul" : "verde"}">${esc(m.tipo)}</span></td>
          <td class="mono peq">${esc(m.sector || "—")} ${m.nodo ? "· " + esc(m.nodo) : ""}</td><td class="peq">${esc(m.descripcion)}</td><td class="peq mut">${esc(m.tecnico || "")}</td></tr>`).join("") || `<tr><td colspan="5">${vacio()}</td></tr>`}
        </tbody></table></div></div>
    </div>`;
    const $ = q => cont.querySelector(q);
    $("#registrar").onclick = async () => {
      const desc = $("#desc").value.trim();
      if (desc.length < 10) { $("#err").textContent = "Describa el trabajo realizado (mínimo 10 caracteres)"; return; }
      try { await api("/mantenimientos", { metodo: "POST", cuerpo: { tipo: $("#tipo").value, descripcion: desc, sector_id: $("#sector").value ? Number($("#sector").value) : null } }); aviso("Mantenimiento registrado"); dibujar(); } catch (e) { error(e); }
    };
    cont.querySelectorAll("[data-mant]").forEach(b => b.onclick = async () => {
      const activar = b.dataset.act === "1";
      if (!(await confirmar(activar ? "Poner en mantenimiento" : "Rehabilitar sector", activar ? "El sector no se regará automáticamente mientras esté en mantenimiento." : "El sector volverá al modo automático."))) return;
      try { await api(`/sectores/${b.dataset.mant}/mantenimiento`, { metodo: "PUT", cuerpo: { activar } }); dibujar(); } catch (e) { error(e); }
    });
    if ($("#inyectar")) {
      $("#inyectar").onclick = async () => {
        try { await api("/simulacion/falla", { metodo: "POST", cuerpo: { tipo: $("#falla").value, sector_id: Number($("#fsector").value) } }); aviso("Falla inyectada", "Observe la alerta y la notificación en los próximos segundos", "alta"); dibujar(); } catch (e) { error(e); }
      };
      $("#limpiar").onclick = async () => { try { await api("/simulacion/limpiar", { metodo: "POST" }); aviso("Fallas reparadas en el simulador"); dibujar(); } catch (e) { error(e); } };
      $("#btn-lluvia").onclick = async () => { try { await api("/simulacion/lluvia", { metodo: "POST", cuerpo: { mm_hora: Number($("#lluvia").value) } }); aviso("Lluvia simulada", $("#lluvia").value + " mm/h"); } catch (e) { error(e); } };
    }
  };
  try { await dibujar(); } catch (e) { error(e); }
  pagina.refrescar = null;
}

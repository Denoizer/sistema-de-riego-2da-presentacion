// HU-12 · Alertas del sistema (el técnico y el administrador pueden atenderlas)
import { api, sesion } from "../api.js";
import { esc, icono, cargando, error, aviso, pillSev, fechaHora, hace, modal, vacio } from "../ui.js";

export default async function alertas(cont, { setTitulo, pagina }) {
  setTitulo("Alertas", "Fallas, tanque, batería, conectividad y clima");
  let estado = "activas";
  cont.innerHTML = cargando();
  const dibujar = async () => {
    const lista = await api("/alertas?estado=" + estado);
    const cuenta = s => lista.filter(a => a.severidad === s && !a.atendida).length;
    cont.innerHTML = `
      <div class="fila entre envolver" style="margin-bottom:14px">
        <div class="tabs" style="margin:0">${[["activas", "Activas"], ["atendidas", "Atendidas"], ["todas", "Todas"]].map(([k, t]) => `<button class="tab ${k === estado ? "activo" : ""}" data-e="${k}">${t}</button>`).join("")}</div>
        <div class="fila">${["critica", "alta", "media", "info"].map(s => `${pillSev(s)}<span class="mono peq">${cuenta(s)}</span>`).join(" ")}</div>
      </div>
      <div class="col" style="gap:10px">
      ${lista.map(a => `<div class="alerta-item" style="${a.atendida ? "opacity:.7" : ""}">
        <div class="franja sev-${a.severidad}"></div>
        <div style="flex:1;min-width:0">
          <div class="fila entre envolver"><div class="fila envolver" style="gap:8px">${pillSev(a.severidad)}<b>${esc(a.codigo)} · ${esc(a.nombre)}</b>
            ${a.sector ? `<span class="pill gris">${esc(a.sector)}</span>` : ""}${a.nodo ? `<span class="pill gris">${esc(a.nodo)}</span>` : ""}</div>
            <span class="eti">${fechaHora(a.fecha)} · ${hace(a.fecha)}</span></div>
          <div style="margin-top:6px;color:var(--txt2)">${esc(a.mensaje)}</div>
          ${a.atendida ? `<div class="muy-peq mut" style="margin-top:6px">${icono("check", 'style="width:12px;height:12px;vertical-align:-2px"')} Atendida por ${esc(a.atendida_por || "el sistema")} · ${fechaHora(a.atendida_en)} · ${esc(a.nota_atencion || "")}</div>` : ""}
        </div>
        ${!a.atendida && sesion.puede("alertas.atender") ? `<div><button class="btn chico prim" data-atender="${a.id}">Atender</button></div>` : ""}
      </div>`).join("") || vacio(estado === "activas" ? "No hay alertas activas ✔" : "Sin registros")}
      </div>
      ${!sesion.puede("alertas.atender") ? `<div class="mut muy-peq" style="margin-top:12px">Las alertas las atiende el técnico de mantenimiento o el administrador.</div>` : ""}`;
    cont.querySelectorAll("[data-e]").forEach(b => b.onclick = () => { estado = b.dataset.e; dibujar(); });
    cont.querySelectorAll("[data-atender]").forEach(b => b.onclick = async () => {
      const a = lista.find(x => x.id == b.dataset.atender);
      await modal({
        titulo: `Atender ${a.codigo} · ${a.nombre}`,
        cuerpo: `<div class="mut">${esc(a.mensaje)}</div><div class="campo"><label>Acción realizada</label><textarea class="input" id="nota" rows="3" placeholder="Ej.: se limpió el filtro y se verificó la apertura de la válvula"></textarea></div><div class="ayuda-error" id="err"></div>`,
        botones: [{ texto: "Cancelar", valor: false }, {
          texto: "Marcar como atendida", clase: "prim", accion: async el => {
            const nota = el.querySelector("#nota").value.trim();
            if (nota.length < 5) { el.querySelector("#err").textContent = "Describa la acción realizada (mínimo 5 caracteres)"; return false; }
            await api(`/alertas/${a.id}/atender`, { metodo: "POST", cuerpo: { nota } });
            aviso("Alerta atendida", a.codigo);
            dibujar();
          },
        }],
      });
    });
  };
  try { await dibujar(); } catch (e) { error(e); }
  pagina.refrescar = dibujar;
}

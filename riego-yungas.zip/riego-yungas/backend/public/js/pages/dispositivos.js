// Sensores y nodos: estado, batería, señal y calibración (HU-18)
import { api, sesion } from "../api.js";
import { esc, num, icono, cargando, error, aviso, modal, fechaHora } from "../ui.js";

export default async function dispositivos(cont, { setTitulo, pagina }) {
  setTitulo("Sensores y nodos", "Red LoRa 915 MHz · ESP32 · estación meteorológica");
  cont.innerHTML = cargando();
  const dibujar = async () => {
    const d = await api("/nodos");
    cont.innerHTML = `
    <div class="grid g-auto">
    ${d.nodos.map(n => `<div class="card ${n.en_linea ? "" : "borde-rojo"}">
      <div class="card-t">${icono(n.tipo === "central" ? "chip" : n.tipo === "tanque" ? "tanque" : "sensor")}<h3 class="mono">${esc(n.codigo)}</h3>
        <div class="der"><span class="pill ${n.en_linea ? "verde" : "rojo pulso"}"><span class="pt"></span>${n.en_linea ? "En línea" : "Sin conexión"}</span></div></div>
      <div class="mut peq" style="margin:-6px 0 10px">${esc(n.descripcion || "")}${n.sector ? " · modo " + esc(n.modo) : ""}</div>
      <div class="grid g3" style="gap:8px;margin-bottom:10px">
        <div><div class="eti">Batería</div><div class="mono" style="color:${n.bateria_v && n.bateria_v < 11.8 ? "var(--rojo)" : "inherit"}">${num(n.bateria_v, 2)} V</div></div>
        <div><div class="eti">Señal</div><div class="mono">${n.rssi_dbm ? n.rssi_dbm + " dBm" : "—"}</div></div>
        <div><div class="eti">Firmware</div><div class="mono">${esc(n.firmware || "—")}</div></div>
      </div>
      <div class="eti" style="margin-bottom:4px">Último reporte: ${n.segundos_desde_reporte !== null ? "hace " + n.segundos_desde_reporte + " s" : fechaHora(n.ultima_conexion)}</div>
      <table class="tabla"><thead><tr><th>Sensor</th><th>Valor</th><th>Estado</th><th></th></tr></thead><tbody>
      ${n.sensores.map(s => `<tr><td class="peq">${esc(s.tipo)} <span class="mono mut">${esc(s.posicion || "")}</span><div class="muy-peq mut">${esc(s.modelo || "")}</div></td>
        <td class="mono peq">${num(s.ultimo_valor, s.tipo === "humedad" ? 3 : 1)} ${esc(s.unidad)}</td>
        <td><span class="pill ${s.estado === "ok" ? "verde" : "rojo"}">${esc(s.estado)}</span></td>
        <td>${sesion.puede("sensores.calibrar") && s.tipo === "humedad" ? `<button class="btn chico" data-cal="${s.id}">Calibrar</button>` : ""}</td></tr>`).join("")}
      </tbody></table></div>`).join("")}
    </div>`;
    cont.querySelectorAll("[data-cal]").forEach(b => b.onclick = async () => {
      const s = d.nodos.flatMap(n => n.sensores.map(x => ({ ...x, nodo: n.codigo }))).find(x => x.id == b.dataset.cal);
      const hist = await api(`/sensores/${s.id}/calibraciones`);
      await modal({
        titulo: `Calibrar ${s.nodo} · ${s.posicion}`,
        cuerpo: `<div class="mut peq">Registre la lectura ADC del sensor con suelo seco (al aire) y saturado (en agua). El firmware convierte el ADC a m³/m³ con estos valores.</div>
          <div class="grid g2"><div class="campo"><label>ADC en seco</label><input class="input" id="seco" type="number" value="${s.adc_seco || 3200}"></div>
          <div class="campo"><label>ADC saturado</label><input class="input" id="sat" type="number" value="${s.adc_saturado || 1380}"></div></div>
          <div class="campo"><label>Observación</label><input class="input" id="obs" placeholder="Método gravimétrico, muestra 3"></div>
          <div class="eti">Historial</div><div class="peq mut">${hist.slice(0, 4).map(h => `${fechaHora(h.fecha)} · ${h.adc_seco}/${h.adc_saturado} · ${esc(h.tecnico || "")}`).join("<br>") || "Sin calibraciones"}</div>`,
        botones: [{ texto: "Cancelar", valor: false }, {
          texto: "Guardar calibración", clase: "prim", accion: async el => {
            await api(`/sensores/${s.id}/calibrar`, { metodo: "POST", cuerpo: { adc_seco: Number(el.querySelector("#seco").value), adc_saturado: Number(el.querySelector("#sat").value), observacion: el.querySelector("#obs").value } });
            aviso("Calibración registrada", `${s.nodo} ${s.posicion}`);
            dibujar();
          },
        }],
      });
    });
  };
  try { await dibujar(); } catch (e) { error(e); }
  pagina.refrescar = dibujar;
}

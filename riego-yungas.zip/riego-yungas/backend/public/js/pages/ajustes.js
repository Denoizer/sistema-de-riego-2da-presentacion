// HU-16 / RF-27 · Configuración: parámetros de riego, horarios, tanque y cultivos
import { api, sesion } from "../api.js";
import { esc, num, icono, cargando, error, aviso, interruptor } from "../ui.js";

export default async function ajustes(cont, { setTitulo }) {
  const esAdmin = sesion.puede("sectores.configurar");
  setTitulo("Configuración", esAdmin ? "Parámetros generales, tanque y cultivos" : "Parámetros de riego que puede ajustar el agricultor");
  cont.innerHTML = cargando();
  const dibujar = async () => {
    const c = await api("/config");
    cont.innerHTML = `
    <div class="grid g2">
      <div class="card"><div class="card-t">${icono("ajustes")}<h3>Parámetros de riego</h3></div>
        <div class="col" style="gap:12px">${c.parametros.map(p => `<div class="fila entre" style="gap:16px">
          <div><div style="font-weight:600" class="peq">${esc(p.descripcion)}</div><div class="eti">${esc(p.clave)}${p.editable ? "" : " · solo administrador"}</div></div>
          ${p.tipo === "booleano" ? interruptor(p.clave, p.valor === "1", `data-p="${p.clave}" ${p.editable ? "" : "disabled"}`)
            : `<input class="input" style="width:110px" type="number" step="0.1" data-p="${p.clave}" value="${esc(p.valor)}" ${p.editable ? "" : "disabled"}>`}</div>`).join("")}</div>
        <div class="sep"></div>
        <div class="eti" style="margin-bottom:6px">Horarios de evaluación (máx. 4)</div>
        <div class="fila envolver" id="horarios">${c.horarios.map(h => `<input class="input" type="time" style="width:120px" value="${String(h.hora).slice(0, 5)}" data-hora>`).join("")}
          <button class="btn chico" id="mas-hora">${icono("mas")}</button></div>
        <div class="ayuda-error" id="err"></div>
        <button class="btn prim" id="guardar" style="margin-top:8px">Guardar parámetros</button>
      </div>
      <div class="col" style="gap:14px">
        ${esAdmin ? `<div class="card"><div class="card-t">${icono("tanque")}<h3>Tanque</h3></div>
          <div class="grid g2"><div class="campo"><label>Umbral mínimo (%) – inicia llenado</label><input class="input" id="t-min" type="number" value="${c.tanque.umbral_min_pct}"></div>
          <div class="campo"><label>Umbral máximo (%) – detiene llenado</label><input class="input" id="t-max" type="number" value="${c.tanque.umbral_max_pct}"></div></div>
          <div class="mut muy-peq" style="margin-top:6px">Capacidad ${num(c.tanque.capacidad_l, 0)} L · vertiente ${num(c.tanque.caudal_entrada_ls, 1)} L/s</div>
          <button class="btn prim" id="guardar-tq" style="margin-top:10px">Guardar tanque</button></div>
        <div class="card"><div class="card-t">${icono("gota")}<h3>Cultivos (coeficientes FAO-56)</h3></div>
          <div class="tabla-scroll"><table class="tabla"><thead><tr><th>Cultivo</th><th>Kc ini</th><th>Kc med</th><th>Kc fin</th><th>Kr</th><th>Zr (m)</th><th>p</th><th></th></tr></thead><tbody>
          ${c.cultivos.map(k => `<tr data-cultivo="${k.id}"><td><b>${esc(k.nombre)}</b><div class="muy-peq mut"><i>${esc(k.nombre_cientifico || "")}</i></div></td>
            ${["kc_inicial", "kc_medio", "kc_final", "kr", "prof_raiz_m", "p_agotamiento"].map(f => `<td><input class="input" style="width:64px;padding:6px" type="number" step="0.01" data-c="${f}" value="${k[f]}"></td>`).join("")}
            <td><button class="btn chico" data-gc="${k.id}">Guardar</button></td></tr>`).join("")}</tbody></table></div>
          <div class="mut muy-peq" style="margin-top:6px">Al guardar se recalcula el umbral de los sectores: θumbral = θcc − p·(θcc − θpmp).</div></div>` : `<div class="card"><div class="card-t">${icono("escudo")}<h3>Permisos</h3></div><div class="mut peq">Como agricultor puede activar el riego automático, cambiar la duración máxima y los horarios. El umbral de cada sector se ajusta desde el detalle del sector.</div></div>`}
        ${c.simulador ? `<div class="card borde-ambar"><div class="card-t">${icono("rayo")}<h3>Modo simulación</h3></div><div class="mut peq">El backend corre con SIMULADOR=1: los nodos, la estación y el tanque se simulan con aceleración ×${c.aceleracion} (1 min real ≈ ${c.aceleracion} min de campo). Para hardware real, ponga SIMULADOR=0 en backend/.env.</div></div>` : ""}
      </div>
    </div>`;
    const $ = q => cont.querySelector(q);
    $("#mas-hora").onclick = () => {
      if (cont.querySelectorAll("[data-hora]").length >= 4) { $("#err").textContent = "Se permiten hasta 4 horarios"; return; }
      $("#mas-hora").insertAdjacentHTML("beforebegin", '<input class="input" type="time" style="width:120px" value="12:00" data-hora>');
    };
    $("#guardar").onclick = async () => {
      const parametros = {};
      cont.querySelectorAll("[data-p]").forEach(i => { if (!i.disabled) parametros[i.dataset.p] = i.type === "checkbox" ? (i.checked ? 1 : 0) : i.value; });
      const horarios = [...cont.querySelectorAll("[data-hora]")].map(i => i.value).filter(Boolean);
      try { await api("/config", { metodo: "PUT", cuerpo: { parametros, horarios } }); aviso("Configuración guardada"); dibujar(); } catch (e) { $("#err").textContent = e.message; }
    };
    if ($("#guardar-tq")) $("#guardar-tq").onclick = async () => {
      try { await api("/config", { metodo: "PUT", cuerpo: { tanque: { umbral_min_pct: Number($("#t-min").value), umbral_max_pct: Number($("#t-max").value) } } }); aviso("Tanque actualizado"); } catch (e) { error(e); }
    };
    cont.querySelectorAll("[data-gc]").forEach(b => b.onclick = async () => {
      const fila = cont.querySelector(`[data-cultivo="${b.dataset.gc}"]`);
      const cuerpo = {};
      fila.querySelectorAll("[data-c]").forEach(i => { cuerpo[i.dataset.c] = Number(i.value); });
      try { await api("/cultivos/" + b.dataset.gc, { metodo: "PUT", cuerpo }); aviso("Cultivo actualizado", "Umbrales recalculados"); } catch (e) { error(e); }
    });
  };
  try { await dibujar(); } catch (e) { error(e); }
}

// Automatización: reglas de disparo/corte del motor de decisión (administrador)
import { api } from "../api.js";
import { esc, num, icono, cargando, error, aviso, interruptor, pillDecision, fechaHora } from "../ui.js";

export default async function automatizacion(cont, { setTitulo, pagina }) {
  setTitulo("Automatización", "Reglas del motor de decisión de riego (punto 3.15.3)");
  cont.innerHTML = cargando();
  const dibujar = async () => {
    const [reglas, dec] = await Promise.all([api("/reglas"), api("/decisiones?limite=30")]);
    cont.innerHTML = `
    <div class="card borde-verde" style="margin-bottom:14px"><div class="fila entre envolver">
      <div><div class="eti">Algoritmo de decisión</div><div style="font-size:17px;font-weight:700;margin-top:4px">ETc (FAO-56) + humedad del suelo + predicción IA + volumen del tanque</div>
      <div class="mut peq" style="margin-top:4px">Cada sector se evalúa en los horarios configurados, de forma continua y ante humedad crítica. El riego es secuencial.</div></div>
      <span class="pill verde pulso"><span class="pt"></span>Motor activo</span></div></div>
    <div class="grid g2">
      <div class="col" style="gap:12px">${reglas.map(r => `<div class="card">
        <div class="fila entre"><div class="fila" style="gap:8px"><span class="pill ${r.activa ? "verde" : "gris"}">${esc(r.codigo)}</span><b>${esc(r.nombre)}</b></div>${interruptor("r" + r.id, r.activa, `data-regla="${r.id}"`)}</div>
        <div class="mut peq" style="margin:8px 0">${esc(r.descripcion)}</div>
        ${r.valor !== null ? `<div class="fila"><span class="eti">${esc(r.parametro)}</span><input class="input" style="width:120px" type="number" step="0.001" value="${r.valor}" data-valor="${r.id}"><span class="mono peq mut">${esc(r.unidad || "")}</span>
          <button class="btn chico" data-guardar="${r.id}">Guardar</button></div>` : `<div class="eti">Parámetro: umbral propio de cada sector</div>`}
        <div class="muy-peq mut" style="margin-top:6px">${r.actualizado_en ? "Modificada " + fechaHora(r.actualizado_en) : ""}</div></div>`).join("")}</div>
      <div class="card"><div class="card-t">${icono("historial")}<h3>Historial de ejecución</h3><div class="der"><span class="eti">últimas 30 decisiones</span></div></div>
        <div class="timeline">${dec.map(d => `<div class="tl-item"><div class="tl-ic">${icono(d.decision === "regar" ? "gota" : d.decision === "posponer" ? "lluvia" : d.decision === "suspender" ? "x" : d.decision === "esperar" ? "tanque" : "check")}</div>
          <div style="flex:1;min-width:0"><div class="fila entre"><span class="fila" style="gap:6px"><b class="mono">${esc(d.sector)}</b>${pillDecision(d.decision)}<span class="mono muy-peq mut">${esc(d.motivo)}</span></span><span class="eti">${fechaHora(d.fecha)}</span></div>
          <div class="mut muy-peq" style="margin-top:3px">${esc(d.detalle || d.motivo_desc)}${d.humedad !== null ? ` · θ ${num(d.humedad, 3)} / ${num(d.umbral, 3)}` : ""}${d.prob_lluvia !== null ? ` · lluvia ${num(d.lluvia_prevista_mm, 1)} mm (${num(d.prob_lluvia, 0)} %)` : ""}</div></div></div>`).join("")}</div></div>
    </div>`;
    cont.querySelectorAll("[data-regla]").forEach(i => i.onchange = async () => {
      try { await api(`/reglas/${i.dataset.regla}`, { metodo: "PUT", cuerpo: { activa: i.checked } }); aviso("Regla " + (i.checked ? "activada" : "desactivada")); dibujar(); } catch (e) { error(e); }
    });
    cont.querySelectorAll("[data-guardar]").forEach(b => b.onclick = async () => {
      const v = cont.querySelector(`[data-valor="${b.dataset.guardar}"]`).value;
      try { await api(`/reglas/${b.dataset.guardar}`, { metodo: "PUT", cuerpo: { valor: Number(v) } }); aviso("Parámetro guardado"); dibujar(); } catch (e) { error(e); }
    });
  };
  try { await dibujar(); } catch (e) { error(e); }
  pagina.refrescar = null;
}

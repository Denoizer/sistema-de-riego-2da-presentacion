// Bitácora de auditoría (administrador)
import { api } from "../api.js";
import { esc, icono, cargando, error, fechaHora } from "../ui.js";

export default async function auditoria(cont, { setTitulo }) {
  setTitulo("Auditoría", "Registro de acciones de los usuarios");
  cont.innerHTML = cargando();
  try {
    const filas = await api("/auditoria");
    cont.innerHTML = `<div class="card"><div class="card-t">${icono("escudo")}<h3>Últimas 300 acciones</h3><div class="der"><input class="input" id="buscar" placeholder="Buscar…" style="width:200px"></div></div>
      <div class="tabla-scroll"><table class="tabla"><thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Entidad</th><th>Detalle</th><th>IP</th></tr></thead><tbody id="cuerpo">
      ${filas.map(a => `<tr><td class="peq">${fechaHora(a.fecha)}</td><td class="mono">${esc(a.usuario || "sistema")}</td><td><span class="pill ${a.accion.includes("FALLIDO") ? "rojo" : a.accion.startsWith("LOGIN") ? "azul" : "gris"}">${esc(a.accion)}</span></td>
        <td class="mono peq">${esc(a.entidad || "")} ${esc(a.entidad_id || "")}</td><td class="peq mut" style="max-width:380px">${esc(a.detalle || "")}</td><td class="mono muy-peq mut">${esc(a.ip || "")}</td></tr>`).join("")}
      </tbody></table></div></div>`;
    cont.querySelector("#buscar").oninput = e => {
      const t = e.target.value.toLowerCase();
      cont.querySelectorAll("#cuerpo tr").forEach(tr => { tr.style.display = tr.textContent.toLowerCase().includes(t) ? "" : "none"; });
    };
  } catch (e) { error(e); }
}

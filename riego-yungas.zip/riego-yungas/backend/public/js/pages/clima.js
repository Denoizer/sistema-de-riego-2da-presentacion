// Clima e IA: condiciones del momento (en vivo), pronóstico por horas y por días (HU-09)
import { api, sesion } from "../api.js";
import { esc, num, icono, cargando, error, fechaCorta, fechaHora, aviso, iconoClima, textoClima, hora } from "../ui.js";
import { lineas, barras } from "../charts.js";

const DIAS = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
const nombreDia = (f, i) => (i === 0 ? "Hoy" : i === 1 ? "Mañana" : DIAS[new Date(f + "T12:00:00").getDay()] + " " + f.slice(8, 10));

function heroAhora(c) {
  const a = c.actual, x = c.externo, h = new Date().getHours();
  return `<div class="card hero">
    <div class="card-t">${icono("reloj")}<h3>Clima en este momento</h3><div class="der"><span class="pill verde pulso"><span class="pt"></span>En vivo · ${new Date().toLocaleTimeString("es-BO", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</span></div></div>
    <div class="grid g2">
      <div class="ahora-hero">
        <div class="ic-grande">${iconoClima({ prob: a.lluvia_1h > 0.2 ? 90 : a.hr_pct > 92 ? 40 : 0, lluvia: a.lluvia_1h, hora: h })}</div>
        <div><div class="eti">Estación meteorológica de la finca</div>
          <div class="valor grad" style="font-size:44px">${num(a.temp_c, 1)}<small>°C</small></div>
          <div class="mut peq">${a.lluvia_1h > 0.2 ? "Lloviendo · " + num(a.lluvia_1h, 1) + " mm en la última hora" : a.radiacion_wm2 > 350 ? "Soleado" : a.radiacion_wm2 > 50 ? "Nublado / parcial" : "Sin radiación solar"}</div></div>
      </div>
      <div class="grid g3" style="gap:10px">
        <div><div class="eti">Humedad rel.</div><div class="valor" style="font-size:20px">${num(a.hr_pct, 0)}<small>%</small></div></div>
        <div><div class="eti">Viento 2 m</div><div class="valor" style="font-size:20px">${num(a.viento_ms, 1)}<small>m/s</small></div></div>
        <div><div class="eti">Radiación</div><div class="valor" style="font-size:20px">${num(a.radiacion_wm2, 0)}<small>W/m²</small></div></div>
        <div><div class="eti">Presión</div><div class="mono">${num(a.presion_kpa, 2)} kPa</div></div>
        <div><div class="eti">Lluvia 1 h</div><div class="mono">${num(a.lluvia_1h, 1)} mm</div></div>
        <div><div class="eti">ETo de ref.</div><div class="mono" style="color:var(--verde)">${num(c.eto_ref, 2)} mm/d</div></div>
      </div>
    </div>
    ${x ? `<div class="sep"></div><div class="fila envolver" style="gap:14px">
      <div style="width:34px">${iconoClima({ codigo: x.codigo, esDia: x.es_dia })}</div>
      <div><div class="eti">Coroico ahora · Open-Meteo (${hora(x.fecha)})</div><b>${num(x.temp_c, 1)} °C · ${esc(textoClima(x.codigo))}</b>
      <span class="mut peq"> · sensación ${num(x.sensacion_c, 0)} °C · HR ${num(x.hr_pct, 0)} % · nubes ${num(x.nubosidad_pct, 0)} % · lluvia ${num(x.lluvia_mm, 1)} mm · viento ${num(x.viento_ms, 1)} m/s</span></div></div>`
      : `<div class="sep"></div><div class="mut muy-peq">Open-Meteo no disponible (sin internet o desactivado en Configuración). Se muestran los datos de la estación y el modelo local.</div>`}
  </div>`;
}

export default async function clima(cont, { setTitulo, pagina }) {
  setTitulo("Clima e IA", "Condiciones actuales y pronóstico de las próximas 72 horas");
  cont.innerHTML = cargando();
  const dibujar = async () => {
    const [c, p] = await Promise.all([api("/clima?horas=48"), api("/clima/prediccion")]);
    const res = p.resumenes;
    let modeloParam = {};
    try { modeloParam = typeof p.modelo.parametros === "string" ? JSON.parse(p.modelo.parametros) : p.modelo.parametros || {}; } catch { /* */ }
    const prox24 = p.horas.slice(0, 24);
    const dias = (c.externo && c.externo.dias ? c.externo.dias.slice(0, 4).map((d, i) => ({ ...d, ia: p.dias.find(x => x.fecha === d.fecha) })) : p.dias.slice(0, 4).map(d => ({ ...d, codigo: null })));
    cont.innerHTML = `
    <div id="hero">${heroAhora(c)}</div>

    <div class="card" style="margin-top:14px"><div class="card-t">${icono("reloj")}<h3>Próximas 24 horas</h3>
      <div class="der"><span class="pill ${p.fuente === "fusion" ? "verde" : "azul"}">${p.fuente === "fusion" ? "IA + Open-Meteo" : "Modelo IA local"}</span></div></div>
      <div class="hora-tira">
        <div class="hora-card ahora"><span class="eti">Ahora</span>${iconoClima({ lluvia: c.actual.lluvia_1h, hora: new Date().getHours() })}<b>${num(c.actual.temp_c, 0)}°</b><span class="muy-peq mut">${num(c.actual.hr_pct, 0)} %</span></div>
        ${prox24.map(h => { const d = new Date(h.fecha_objetivo.replace(" ", "T")); return `<div class="hora-card"><span class="eti">${String(d.getHours()).padStart(2, "0")}:00</span>
          ${iconoClima({ prob: h.prob_lluvia, lluvia: h.lluvia_mm, hora: d.getHours() })}<b>${num(h.temp_c, 0)}°</b>
          <span class="muy-peq" style="color:${h.prob_lluvia >= 50 ? "var(--azul)" : "var(--mut)"}">${num(h.prob_lluvia, 0)} %</span></div>`; }).join("")}
      </div></div>

    <div class="grid g4" style="margin-top:14px">
      ${dias.map((d, i) => `<div class="dia-card">
        <div class="fila entre"><b>${nombreDia(d.fecha, i)}</b><span class="eti">${fechaCorta(d.fecha)}</span></div>
        <div class="fila" style="gap:10px"><div style="width:36px">${iconoClima({ codigo: d.codigo, prob: d.prob_lluvia, lluvia: d.lluvia_mm })}</div>
          <div><span class="valor" style="font-size:20px">${num(d.tmax, 0)}°</span> <span class="mut">/ ${num(d.tmin, 0)}°</span>${d.codigo !== null && d.codigo !== undefined ? `<div class="muy-peq mut">${esc(textoClima(d.codigo))}</div>` : ""}</div></div>
        <div class="fila entre peq"><span class="mut">Lluvia</span><span class="mono" style="color:var(--azul)">${num(d.lluvia_mm, 1)} mm · ${num(d.prob_lluvia, 0)} %</span></div>
        <div class="fila entre peq"><span class="mut">ETo</span><span class="mono" style="color:var(--verde)">${num(d.eto_mm, 1)} mm</span></div>
        ${d.ia ? `<div class="muy-peq" style="color:var(--rosa)">IA local: ${num(d.ia.tmax, 0)}°/${num(d.ia.tmin, 0)}° · ${num(d.ia.prob_lluvia, 0)} %</div>` : ""}
      </div>`).join("")}
    </div>

    <div class="grid g4" style="margin:14px 0">
      ${[6, 24, 48, 72].map(h => { const r = res[h]; return `<div class="card kpi"><div class="fila entre"><span class="eti">Lluvia próximas ${h} h</span><span style="width:20px;display:inline-block">${iconoClima({ prob: r ? r.prob_max : 0 })}</span></div>
        <div class="valor ${r && r.prob_max >= 60 ? "azul" : ""}">${r ? num(r.lluvia_mm, 1) : "—"}<small>mm</small></div>
        <div class="mut muy-peq">prob. máx. ${r ? num(r.prob_max, 0) : "—"} % · ETo ${r ? num(r.eto_mm, 1) : "—"} mm</div></div>`; }).join("")}
    </div>
    <div class="grid g2">
      <div class="card span2"><div class="card-t">${icono("cerebro")}<h3>Predicción horaria 72 h</h3>
        <div class="der"><span class="eti">generada ${fechaHora(p.generado_en)}</span>
        ${sesion.puede("ia.reentrenar") ? `<button class="btn chico" id="regenerar">${icono("actualizar")} Regenerar</button>` : ""}</div></div>
        ${lineas([
          { nombre: "Temperatura (°C)", color: "#f5b041", puntos: p.horas.map(h => ({ x: h.fecha_objetivo, y: h.temp_c })) },
          { nombre: "Prob. de lluvia (%) ÷ 4", color: "#f0609e", dash: "4 3", puntos: p.horas.map(h => ({ x: h.fecha_objetivo, y: h.prob_lluvia / 4 })) },
        ], { alto: 230, fy: v => num(v, 0) })}
        ${barras(p.horas.filter((_, i) => i % 3 === 0).map(h => new Date(h.fecha_objetivo.replace(" ", "T")).getHours() + "h"),
          [{ nombre: "Lluvia prevista (mm / 3 h)", color: "#4cc9f0", valores: p.horas.filter((_, i) => i % 3 === 0).map((_, k) => p.horas.slice(k * 3, k * 3 + 3).reduce((s, x) => s + (x.lluvia_mm || 0), 0)) },
           { nombre: "ETo prevista (mm / 3 h)", color: "#2bd576", valores: p.horas.filter((_, i) => i % 3 === 0).map((_, k) => p.horas.slice(k * 3, k * 3 + 3).reduce((s, x) => s + (x.eto_mm || 0), 0)) }],
          { alto: 150, fy: v => num(v, 1) })}
        <div class="mut muy-peq" style="margin-top:6px">Modelo: ${esc(p.modelo.algoritmo)} · MAE temperatura ${p.modelo.mae === null ? "en evaluación" : num(p.modelo.mae, 2) + " °C"} · peso local ${num((modeloParam.peso_local ?? 1) * 100, 0)} %</div>
      </div>
      <div class="card"><div class="card-t">${icono("termo")}<h3>Estación · últimas 48 h</h3></div>
        ${lineas([
          { nombre: "Temperatura (°C)", color: "#f5b041", puntos: c.serie.map(x => ({ x: x.fecha, y: x.temp_c })) },
          { nombre: "Humedad relativa ÷ 4", color: "#4cc9f0", puntos: c.serie.map(x => ({ x: x.fecha, y: x.hr_pct / 4 })) },
        ], { alto: 200 })}</div>
      <div class="card"><div class="card-t">${icono("sol")}<h3>ETo diaria (FAO Penman-Monteith)</h3></div>
        ${barras(c.diario.map(d => fechaCorta(d.fecha)), [{ nombre: "ETo (mm)", color: "#2bd576", valores: c.diario.map(d => d.eto_mm) }, { nombre: "Lluvia (mm)", color: "#f0609e", valores: c.diario.map(d => d.lluvia_mm) }], { alto: 200, fy: v => num(v, 1) })}
      </div>
      <div class="card span2"><div class="card-t">${icono("rayo")}<h3>Calculadora ETo – validación del método (punto 3.20.6)</h3></div>
        <div class="grid g4" id="calc">
          ${[["tmax", "Tmax (°C)", 24], ["tmin", "Tmin (°C)", 14], ["hrmax", "HR máx (%)", 95], ["hrmin", "HR mín (%)", 60], ["u2", "Viento u2 (m/s)", 1.5], ["rs", "Rs (MJ/m²·día)", 15], ["fecha", "Fecha", "2026-07-15"], ["z", "Altitud (m)", 1700]]
            .map(([k, l, v]) => `<div class="campo"><label>${l}</label><input class="input" id="c-${k}" ${k === "fecha" ? 'type="date"' : 'type="number" step="0.1"'} value="${v}"></div>`).join("")}
        </div>
        <div class="fila envolver" style="margin-top:12px"><button class="btn prim" id="calcular">Calcular ETo</button><span id="res-eto" class="mono"></span></div>
        <div class="mut muy-peq" style="margin-top:6px">Con los valores del ejemplo del marco práctico (15 de julio, Coroico) el resultado es ≈ 2,78 mm/día.</div>
      </div>
    </div>`;
    const reg = cont.querySelector("#regenerar");
    if (reg) reg.onclick = async () => { try { await api("/clima/prediccion/generar", { metodo: "POST" }); aviso("Predicción regenerada"); dibujar(); } catch (e) { error(e); } };
    cont.querySelector("#calcular").onclick = async () => {
      const v = k => cont.querySelector("#c-" + k).value;
      try {
        const r = await api("/clima/eto-calculo", { metodo: "POST", cuerpo: { tmax: v("tmax"), tmin: v("tmin"), hrmax: v("hrmax"), hrmin: v("hrmin"), u2: v("u2"), rs: v("rs"), fecha: v("fecha"), z: v("z") } });
        cont.querySelector("#res-eto").innerHTML = `ETo = <b style="color:var(--verde);font-size:16px">${num(r.eto, 2)} mm/día</b> · P ${num(r.P, 2)} kPa · γ ${num(r.gamma, 4)} · es ${num(r.es, 3)} · ea ${num(r.ea, 3)} · Δ ${num(r.delta, 4)} · Rn ${num(r.rn, 2)}`;
      } catch (e) { error(e); }
    };
  };
  try { await dibujar(); } catch (e) { error(e); }
  // Solo se refrescan las condiciones del momento (cada lectura de la estación)
  pagina.refrescar = async () => {
    const hero = cont.querySelector("#hero");
    if (!hero) return;
    const c = await api("/clima?horas=1");
    hero.innerHTML = heroAhora(c);
  };
}

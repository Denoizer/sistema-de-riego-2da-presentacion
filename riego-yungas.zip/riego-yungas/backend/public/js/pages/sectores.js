// Sectores de riego: listado con estado, riego manual y alta de sectores (admin)
import { api, sesion } from "../api.js";
import { esc, num, icono, cargando, error, aviso, confirmar, modal } from "../ui.js";
import { tarjetaSector, dialogoRiegoManual, enlazarModoSector } from "../componentes.js";

const FILTROS = [["todos", "Todos"], ["regando", "Regando"], ["reposo", "En reposo"], ["pospuesto", "Pospuestos"], ["falla", "Falla / mant."]];

export default async function sectores(cont, { setTitulo, pagina }) {
  setTitulo("Sectores de riego", "4 sectores de 1 ha · riego por goteo secuencial");
  let filtro = "todos", lista = [];
  cont.innerHTML = cargando();

  const dibujar = async () => {
    lista = await api("/sectores");
    const vis = lista.filter(s => filtro === "todos" || s.estado === filtro || (filtro === "falla" && ["falla", "mantenimiento"].includes(s.estado)) || (filtro === "pospuesto" && ["pospuesto", "esperando_agua"].includes(s.estado)));
    const total = lista.reduce((a, s) => a + s.caudal_nominal_lh, 0);
    cont.innerHTML = `
      <div class="fila entre envolver" style="margin-bottom:12px">
        <div class="tabs" style="margin:0">${FILTROS.map(([k, t]) => `<button class="tab ${k === filtro ? "activo" : ""}" data-f="${k}">${t} <span class="mono mut">${k === "todos" ? lista.length : lista.filter(s => s.estado === k || (k === "falla" && ["falla", "mantenimiento"].includes(s.estado)) || (k === "pospuesto" && ["pospuesto", "esperando_agua"].includes(s.estado))).length}</span></button>`).join("")}</div>
        <div class="fila">
          <span class="eti">Caudal instalado ${num(total, 0)} L/h</span>
          ${sesion.puede("sectores.configurar") ? `<button class="btn prim chico" id="nuevo">${icono("mas")} Nuevo sector</button>` : ""}
        </div>
      </div>
      <div class="grid g-auto">${vis.map(s => `<div class="col" style="gap:6px">${tarjetaSector(s)}
        ${sesion.puede("riego.manual") ? `<div class="fila">${s.riego
          ? `<button class="btn peligro bloque" data-detener="${s.id}">${icono("stop")} Detener riego</button>`
          : `<button class="btn rosa bloque" data-manual="${s.id}" ${["mantenimiento", "falla"].includes(s.estado) ? "disabled" : ""}>${icono("gota")} Regar por litros</button>`}
          <button class="btn" data-evaluar="${s.id}" title="Evaluar ahora con el motor de decisión">${icono("actualizar")}</button></div>` : ""}
      </div>`).join("") || `<div class="vacio">No hay sectores en este filtro</div>`}</div>`;

    cont.querySelectorAll("[data-f]").forEach(b => b.onclick = () => { filtro = b.dataset.f; dibujar(); });
    cont.querySelectorAll("[data-sector]").forEach(el => el.onclick = () => { location.hash = "#/sector/" + el.dataset.sector; });
    enlazarModoSector(cont, dibujar);
    cont.querySelectorAll("[data-manual]").forEach(b => b.onclick = () => dialogoRiegoManual(lista.find(s => s.id == b.dataset.manual), dibujar));
    cont.querySelectorAll("[data-detener]").forEach(b => b.onclick = async () => {
      const s = lista.find(x => x.id == b.dataset.detener);
      if (!(await confirmar("Detener riego", `¿Detener el riego del ${s.nombre}? Se cerrará la válvula.`, "peligro", "Detener"))) return;
      try { await api(`/sectores/${s.id}/detener`, { metodo: "POST" }); aviso("Riego detenido", s.nombre); dibujar(); } catch (e) { error(e); }
    });
    cont.querySelectorAll("[data-evaluar]").forEach(b => b.onclick = async () => {
      try { const r = await api(`/sectores/${b.dataset.evaluar}/evaluar`, { metodo: "POST" }); aviso("Evaluación del motor", `Decisión: ${r.decision.replace("_", " ")}`); dibujar(); } catch (e) { error(e); }
    });
    const nuevo = cont.querySelector("#nuevo");
    if (nuevo) nuevo.onclick = nuevoSector;
  };

  async function nuevoSector() {
    const cfg = await api("/config");
    await modal({
      titulo: "Nuevo sector de riego",
      cuerpo: `<div class="campo"><label>Nombre</label><input class="input" id="nombre" placeholder="Sector 5 – Café"></div>
        <div class="campo"><label>Cultivo</label><select class="input" id="cultivo">${cfg.cultivos.map(c => `<option value="${c.id}">${esc(c.nombre)} (Kc ${num(c.kc_medio, 2)})</option>`).join("")}</select></div>
        <div class="grid g2"><div class="campo"><label>Área (ha)</label><input class="input" id="area" type="number" step="0.1" value="1"></div>
        <div class="campo"><label>N.º de plantas</label><input class="input" id="plantas" type="number" value="5000"></div>
        <div class="campo"><label>Goteros por planta</label><input class="input" id="goteros" type="number" value="1"></div>
        <div class="campo"><label>Caudal gotero (L/h)</label><input class="input" id="qg" type="number" step="0.1" value="2"></div></div>
        <div class="ayuda-error" id="err"></div>`,
      botones: [{ texto: "Cancelar", valor: false }, {
        texto: "Crear sector", clase: "prim", accion: async el => {
          const v = id => el.querySelector("#" + id).value;
          const r = await api("/sectores", { metodo: "POST", cuerpo: { nombre: v("nombre") || undefined, cultivo_id: Number(v("cultivo")), area_ha: Number(v("area")), n_plantas: Number(v("plantas")), goteros_por_planta: Number(v("goteros")), caudal_gotero_lh: Number(v("qg")) } });
          aviso("Sector creado", `${r.codigo} con su nodo, sensores y modelo de IA`);
          dibujar();
        },
      }],
    });
  }

  try { await dibujar(); } catch (e) { error(e); }
  pagina.refrescar = dibujar;
}

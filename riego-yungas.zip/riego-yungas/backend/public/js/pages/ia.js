// Modelos de IA: fases de aprendizaje, métricas y reentrenamiento (HU-15)
import { api, sesion } from "../api.js";
import { esc, num, icono, cargando, error, aviso, fechaHora } from "../ui.js";
import { lineas } from "../charts.js";

const FASES = { observacion: ["Observación", "gris", "Solo reglas FAO; la IA aprende en segundo plano"], recomendacion: ["Recomendación", "azul", "La IA predice y se compara con las reglas"], adaptacion: ["Adaptación", "verde", "Ajusta Kc y umbral ±10 % y puede anticipar riegos"] };

export default async function ia(cont, { setTitulo }) {
  setTitulo("Modelos de IA", "Predicción climática y aprendizaje progresivo por sector");
  cont.innerHTML = cargando();
  const dibujar = async () => {
    const d = await api("/ia/modelos");
    const clima = d.modelos.find(m => m.tipo === "clima");
    const sec = d.modelos.filter(m => m.tipo === "sector");
    const colores = ["#22c55e", "#38bdf8", "#f59e0b", "#a78bfa", "#f472b6"];
    cont.innerHTML = `
    <div class="grid g3" style="margin-bottom:14px">${Object.entries(FASES).map(([k, [t, c, d2]], i) => `<div class="card"><div class="fila" style="gap:8px"><span class="num-sector">${i + 1}</span><span class="pill ${c}">${t}</span></div><div class="mut peq" style="margin-top:8px">${d2}</div>
      <div class="eti" style="margin-top:6px">${k === "observacion" ? "< 30 muestras" : k === "recomendacion" ? "30 – 119 muestras" : "≥ 120 muestras"}</div></div>`).join("")}</div>
    <div class="grid g2">
      <div class="card span2"><div class="card-t">${icono("cerebro")}<h3>Modelos por sector</h3>
        ${sesion.puede("ia.reentrenar") ? `<div class="der"><button class="btn prim chico" id="reentrenar">${icono("actualizar")} Reentrenar todos</button></div>` : ""}</div>
        <div class="tabla-scroll"><table class="tabla"><thead><tr><th>Sector</th><th>Algoritmo</th><th>Versión</th><th>Fase</th><th>Muestras</th><th>Pendientes</th><th>MAE θ</th><th>RMSE θ</th><th>Factor Kc</th><th>Entrenado</th></tr></thead><tbody>
        ${sec.map(m => `<tr><td class="mono"><b>${esc(m.sector)}</b></td><td class="peq">${esc(m.algoritmo)}</td><td class="mono">v${m.version}</td>
          <td><span class="pill ${FASES[m.fase][1]}">${FASES[m.fase][0]}</span></td><td class="mono">${m.n_muestras}</td><td class="mono mut">${m.muestras_pendientes}</td>
          <td class="mono" style="color:${m.mae !== null && m.mae <= 0.02 ? "var(--verde)" : "var(--ambar)"}">${num(m.mae, 4)}</td><td class="mono">${num(m.rmse, 4)}</td>
          <td class="mono">${m.parametros && m.parametros.ratioKc ? num(Math.min(1.1, Math.max(0.9, m.parametros.ratioKc)), 3) : "1,000"}</td><td class="peq mut">${fechaHora(m.entrenado_en)}</td></tr>`).join("")}
        </tbody></table></div>
        <div class="mut muy-peq" style="margin-top:8px">Meta RNF-08: MAE de humedad a 24 h ≤ 0,02 m³/m³. El modelo se actualiza con cada muestra vencida y se reentrena por lotes semanalmente o a pedido.</div></div>
      <div class="card"><div class="card-t">${icono("gota")}<h3>Humedad observada a 24 h (muestras recientes)</h3></div>
        ${lineas(sec.map((m, i) => ({ nombre: m.sector, color: colores[i % colores.length], puntos: d.ultimas.filter(u => u.sector_id === m.sector_id).map(u => ({ x: u.fecha, y: u.humedad_objetivo })) })), { alto: 220 })}</div>
      <div class="card"><div class="card-t">${icono("clima")}<h3>Modelo climático</h3></div>
        <table class="tabla"><tbody>
          <tr><td class="mut">Algoritmo</td><td>${esc(clima.algoritmo)}</td></tr>
          <tr><td class="mut">Fase</td><td><span class="pill ${FASES[clima.fase][1]}">${FASES[clima.fase][0]}</span></td></tr>
          <tr><td class="mut">Datos de entrenamiento</td><td class="mono">${clima.n_muestras} lecturas (7 días)</td></tr>
          <tr><td class="mut">MAE temperatura (1–6 h)</td><td class="mono">${clima.mae === null ? "en evaluación" : num(clima.mae, 2) + " °C"}</td></tr>
          <tr><td class="mut">Peso del modelo local</td><td class="mono">${num((clima.parametros?.peso_local ?? 1) * 100, 0)} %</td></tr>
          <tr><td class="mut">Open-Meteo</td><td>${clima.parametros?.open_meteo?.ok ? '<span class="pill verde">conectado</span>' : clima.parametros?.open_meteo?.ok === false ? '<span class="pill ambar">sin conexión</span>' : '<span class="pill gris">no utilizado</span>'}</td></tr>
          <tr><td class="mut">Última generación</td><td class="peq">${fechaHora(clima.entrenado_en)}</td></tr>
        </tbody></table>
        <div class="mut muy-peq" style="margin-top:8px">Los scripts de entrenamiento LSTM / Random Forest en Python (carpeta ia_python) pueden reemplazar estos modelos ligeros cuando haya suficientes datos.</div></div>
    </div>`;
    const b = cont.querySelector("#reentrenar");
    if (b) b.onclick = async () => {
      b.disabled = true; b.textContent = "Reentrenando…";
      try { await api("/ia/reentrenar", { metodo: "POST" }); aviso("Modelos reentrenados"); dibujar(); } catch (e) { error(e); b.disabled = false; }
    };
  };
  try { await dibujar(); } catch (e) { error(e); }
}

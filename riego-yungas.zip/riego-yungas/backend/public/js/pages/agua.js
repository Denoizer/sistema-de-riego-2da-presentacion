// Agua y tanque: litros disponibles, llenado y distribución por sector (HU-05, HU-06, HU-11)
import { api, sesion } from "../api.js";
import { esc, num, icono, cargando, error } from "../ui.js";
import { tarjetaTanque, enlazarLlenado } from "../componentes.js";
import { lineas, barras } from "../charts.js";

const COLORES = ["#22c55e", "#38bdf8", "#f59e0b", "#a78bfa", "#f472b6", "#2dd4bf"];

export default async function agua(cont, { setTitulo, pagina }) {
  setTitulo("Agua y tanque", "Volumen en litros, llenado automático y distribución por sector");
  let horas = 24;
  cont.innerHTML = cargando();
  const dibujar = async () => {
    const [t, sectores] = await Promise.all([api("/tanque?horas=" + horas), api("/sectores")]);
    const totalHoy = t.distribucion_hoy.reduce((a, s) => a + s.litros, 0);
    const enCurso = sectores.filter(s => s.riego);
    cont.innerHTML = `
    <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,2fr);gap:14px" id="g1">
      ${tarjetaTanque(t, { botones: sesion.puede("tanque.operar") })}
      <div class="card"><div class="card-t">${icono("tanque")}<h3>Nivel del tanque</h3>
        <div class="der">${[6, 24, 72].map(h => `<button class="tab ${h === horas ? "activo" : ""}" data-h="${h}">${h} h</button>`).join("")}</div></div>
        ${lineas([{ nombre: "Volumen (L)", color: "#38bdf8", area: true, puntos: t.serie.map(x => ({ x: x.fecha, y: x.nivel_l })) }],
          { alto: 230, min: 0, max: t.capacidad_l, umbrales: [{ y: t.capacidad_l * t.umbral_min_pct / 100, color: "#ef4444", texto: "mínimo " + t.umbral_min_pct + " %", leyenda: "Umbral de llenado" }, { y: t.capacidad_l * t.umbral_max_pct / 100, color: "#22c55e", texto: "máximo " + t.umbral_max_pct + " %" }], fy: v => num(v / 1000, 0) + " k" })}
      </div>
    </div>
    <div class="card" style="margin-top:14px"><div class="card-t">${icono("gota")}<h3>Distribución en curso</h3><div class="der"><span class="eti">riego secuencial · un sector a la vez</span></div></div>
      ${enCurso.length ? enCurso.map(s => `<div class="fila envolver" style="gap:16px">
          <div style="min-width:160px"><b>${esc(s.nombre)}</b><div class="eti">${esc(s.riego.tipo)} · ${esc(s.riego.motivo || "")}</div></div>
          <div style="flex:1;min-width:200px"><div class="barra azul" style="height:10px"><i style="width:${s.riego.pct}%"></i></div>
            <div class="fila entre peq mono" style="margin-top:4px"><span>${num(s.riego.litros, 0)} / ${num(s.riego.litros_plan, 0)} L</span><span>${num(s.riego.caudal_lmin, 0)} L/min</span><span>${s.riego.min_restantes === null ? "—" : "≈ " + num(s.riego.min_restantes, 0) + " min"}</span></div></div></div>`).join("")
        : `<div class="vacio">Ningún sector se está regando en este momento</div>`}
    </div>
    <div class="grid g2" style="margin-top:14px">
      <div class="card"><div class="card-t">${icono("sectores")}<h3>Litros distribuidos hoy por sector</h3><div class="der"><span class="valor" style="font-size:18px">${num(totalHoy, 0)}<small>L</small></span></div></div>
        ${barras(t.distribucion_hoy.map(s => s.codigo), [{ nombre: "Litros", color: "#22c55e", valores: t.distribucion_hoy.map(s => s.litros) }], { alto: 200, fy: v => num(v / 1000, 1) + " k" })}</div>
      <div class="card"><div class="card-t">${icono("historial")}<h3>Detalle por sector (hoy)</h3></div>
        <table class="tabla"><thead><tr><th>Sector</th><th>Riegos</th><th>Litros</th><th>Tiempo plan.</th><th>% del día</th></tr></thead><tbody>
        ${t.distribucion_hoy.map((s, i) => `<tr><td><span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:${COLORES[i % COLORES.length]};margin-right:6px"></span><b class="mono">${esc(s.codigo)}</b> <span class="mut peq">${esc(s.nombre.split("–")[1] || "")}</span></td>
          <td class="mono">${s.riegos}</td><td class="mono">${num(s.litros, 0)} L</td><td class="mono">${num(s.minutos, 0)} min</td><td class="mono">${totalHoy ? num((s.litros / totalHoy) * 100, 1) : "0"} %</td></tr>`).join("")}
        </tbody></table>
        <div class="mut muy-peq" style="margin-top:10px">La vertiente aporta ≈ ${num(t.caudal_entrada_ls * 3600, 0)} L/h cuando la válvula de llenado está abierta. El sistema verifica el volumen antes de cada riego (regla de reserva mínima).</div></div>
    </div>`;
    if (window.innerWidth < 1100) cont.querySelector("#g1").style.gridTemplateColumns = "1fr";
    cont.querySelectorAll("[data-h]").forEach(b => b.onclick = () => { horas = Number(b.dataset.h); dibujar(); });
    enlazarLlenado(cont, dibujar);
  };
  try { await dibujar(); } catch (e) { error(e); }
  pagina.refrescar = dibujar;
}

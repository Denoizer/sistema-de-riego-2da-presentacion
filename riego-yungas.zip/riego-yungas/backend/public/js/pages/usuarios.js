// HU-02 · Gestión de usuarios: el administrador añade agricultores, técnicos y administradores
import { api, sesion } from "../api.js";
import { esc, icono, cargando, error, aviso, modal, fechaHora, confirmar, interruptor, vacio } from "../ui.js";

const COLOR = { admin: "violeta", tecnico: "azul", agricultor: "verde" };

export default async function usuarios(cont, { setTitulo }) {
  setTitulo("Usuarios y roles", "Añada agricultores y técnicos; cada rol accede a funciones distintas");
  cont.innerHTML = cargando();
  let filtro = "todos";
  const dibujar = async () => {
    const [lista, r, sectores] = await Promise.all([api("/usuarios"), api("/roles"), api("/sectores")]);
    const modulos = [...new Set(r.permisos.map(p => p.modulo))];
    const rolId = c => r.roles.find(x => x.codigo === c).id;
    const vis = lista.filter(u => filtro === "todos" || u.rol === filtro);
    cont.innerHTML = `
    <div class="grid g3" style="margin-bottom:14px">
      ${[["agricultor", "Añadir agricultor", "Opera los sectores a su cargo y recibe sus alertas", "gota"], ["tecnico", "Añadir técnico", "Atiende fallas, calibra sensores y registra mantenimiento", "llave"], ["admin", "Añadir administrador", "Acceso completo a la configuración", "escudo"]]
        .map(([k, t, d, ic]) => `<button class="card" data-nuevo="${k}" style="text-align:left;cursor:pointer"><div class="fila" style="gap:10px"><span class="kpi"><span class="ic">${icono(ic)}</span></span><div><b>${t}</b><div class="mut muy-peq">${d}</div></div><span style="margin-left:auto" class="pill ${COLOR[k]}">${lista.filter(u => u.rol === k).length}</span></div></button>`).join("")}
    </div>
    <div class="card" style="margin-bottom:14px"><div class="card-t">${icono("usuarios")}<h3>Usuarios registrados</h3>
      <div class="der"><div class="tabs" style="margin:0">${[["todos", "Todos"], ["agricultor", "Agricultores"], ["tecnico", "Técnicos"], ["admin", "Administradores"]].map(([k, t]) => `<button class="tab ${k === filtro ? "activo" : ""}" data-f="${k}">${t}</button>`).join("")}</div></div></div>
      <div class="tabla-scroll"><table class="tabla"><thead><tr><th>Usuario</th><th>Nombre</th><th>Correo / teléfono</th><th>Rol</th><th>Sectores a cargo</th><th>Activo</th><th>Último acceso</th><th></th></tr></thead><tbody>
      ${vis.map(u => `<tr><td class="mono"><b>${esc(u.usuario)}</b></td><td>${esc(u.nombre)} ${esc(u.apellido)}</td><td class="peq">${esc(u.correo)}<div class="mut muy-peq">${esc(u.telefono || "")}</div></td>
        <td><span class="pill ${COLOR[u.rol]}">${esc(u.rol_nombre)}</span></td>
        <td class="mono peq">${u.rol === "agricultor" ? (u.sectores_codigos.length ? u.sectores_codigos.join(", ") : "Todos") : "—"}</td>
        <td>${u.id === sesion.usuario.id ? '<span class="pill verde">Usted</span>' : interruptor("a" + u.id, u.activo, `data-activo="${u.id}"`)}</td>
        <td class="peq mut">${fechaHora(u.ultimo_acceso)}</td>
        <td style="text-align:right;white-space:nowrap"><button class="btn chico" data-editar="${u.id}">${icono("editar")} Editar</button>
          ${u.id !== sesion.usuario.id ? `<button class="btn chico fant" data-borrar="${u.id}" title="Eliminar">${icono("basura")}</button>` : ""}</td></tr>`).join("") || `<tr><td colspan="8">${vacio()}</td></tr>`}
      </tbody></table></div></div>
    <div class="card"><div class="card-t">${icono("escudo")}<h3>Matriz de permisos por rol</h3></div>
      <div class="tabla-scroll"><table class="tabla"><thead><tr><th>Módulo</th><th>Permiso</th>${r.roles.map(x => `<th style="text-align:center">${esc(x.nombre)}</th>`).join("")}</tr></thead><tbody>
      ${modulos.map(m => r.permisos.filter(p => p.modulo === m).map((p, i) => `<tr><td class="peq mut">${i === 0 ? esc(m) : ""}</td><td class="peq">${esc(p.descripcion)} <span class="mono muy-peq mut">${esc(p.codigo)}</span></td>
        ${r.roles.map(x => `<td style="text-align:center">${r.matriz.some(z => z.rol_id === x.id && z.permiso_id === p.id) ? '<span style="color:var(--verde)">●</span>' : '<span style="color:var(--mut2)">○</span>'}</td>`).join("")}</tr>`).join("")).join("")}
      </tbody></table></div></div>`;

    const formulario = (u = {}, rolCodigo) => `
      <div class="grid g2"><div class="campo"><label>Usuario (para iniciar sesión)</label><input class="input" id="f-usuario" value="${esc(u.usuario || "")}" ${u.id ? "disabled" : ""} placeholder="ej. jperez"></div>
      <div class="campo"><label>Rol</label><select class="input" id="f-rol">${r.roles.map(x => `<option value="${x.id}" data-codigo="${x.codigo}" ${x.codigo === (u.rol || rolCodigo) ? "selected" : ""}>${esc(x.nombre)}</option>`).join("")}</select></div>
      <div class="campo"><label>Nombre</label><input class="input" id="f-nombre" value="${esc(u.nombre || "")}"></div>
      <div class="campo"><label>Apellido</label><input class="input" id="f-apellido" value="${esc(u.apellido || "")}"></div>
      <div class="campo"><label>Correo</label><input class="input" id="f-correo" type="email" value="${esc(u.correo || "")}"></div>
      <div class="campo"><label>Teléfono</label><input class="input" id="f-telefono" value="${esc(u.telefono || "")}"></div></div>
      <div class="campo" id="bloque-sectores"><label>Sectores a cargo (recibe las alertas y fallas de estos sectores)</label>
        <div class="chips-sector">${sectores.map(s => `<label><input type="checkbox" value="${s.id}" ${(u.sectores || []).includes(s.id) ? "checked" : ""}><span>${esc(s.codigo)} · ${esc(s.cultivo)}</span></label>`).join("")}</div>
        <div class="mut muy-peq">Si no marca ninguno, el agricultor verá todos los sectores.</div></div>
      <div class="campo"><label>${u.id ? "Nueva contraseña (opcional)" : "Contraseña"}</label><input class="input" id="f-clave" type="password" placeholder="Mín. 8 caracteres, mayúscula, minúscula y número"></div>
      <div class="ayuda-error" id="f-err"></div>`;
    const leer = el => {
      const v = id => el.querySelector("#f-" + id);
      return { usuario: v("usuario").value, rol_id: Number(v("rol").value), nombre: v("nombre").value, apellido: v("apellido").value, correo: v("correo").value, telefono: v("telefono").value,
        clave: v("clave").value || undefined, sectores: [...el.querySelectorAll("#bloque-sectores input:checked")].map(i => Number(i.value)) };
    };
    const ajustar = () => setTimeout(() => {
      const el = document.querySelector(".modal"); if (!el) return;
      const rol = el.querySelector("#f-rol"), bloque = el.querySelector("#bloque-sectores");
      const upd = () => { bloque.style.display = rol.selectedOptions[0].dataset.codigo === "agricultor" ? "" : "none"; };
      rol.onchange = upd; upd();
    }, 0);
    const guardar = (u) => async el => {
      const d = leer(el);
      try {
        if (u) { delete d.usuario; await api("/usuarios/" + u.id, { metodo: "PUT", cuerpo: d }); aviso("Usuario actualizado", d.nombre); }
        else { await api("/usuarios", { metodo: "POST", cuerpo: d }); aviso("Usuario creado", `${d.usuario} ya puede iniciar sesión`); }
      } catch (e) { el.querySelector("#f-err").textContent = e.message; return false; }
      dibujar();
    };

    cont.querySelectorAll("[data-f]").forEach(b => b.onclick = () => { filtro = b.dataset.f; dibujar(); });
    cont.querySelectorAll("[data-nuevo]").forEach(b => b.onclick = () => {
      ajustar();
      modal({ titulo: { agricultor: "Nuevo agricultor", tecnico: "Nuevo técnico", admin: "Nuevo administrador" }[b.dataset.nuevo], cuerpo: formulario({ rol_id: rolId(b.dataset.nuevo) }, b.dataset.nuevo), botones: [{ texto: "Cancelar", valor: false }, { texto: "Crear usuario", clase: "prim", accion: guardar(null) }] });
    });
    cont.querySelectorAll("[data-editar]").forEach(b => b.onclick = () => {
      const u = lista.find(x => x.id == b.dataset.editar);
      ajustar();
      modal({ titulo: "Editar " + u.usuario, cuerpo: formulario(u), botones: [{ texto: "Cancelar", valor: false }, { texto: "Guardar cambios", clase: "prim", accion: guardar(u) }] });
    });
    cont.querySelectorAll("[data-activo]").forEach(i => i.onchange = async () => {
      try { await api("/usuarios/" + i.dataset.activo, { metodo: "PUT", cuerpo: { activo: i.checked } }); aviso(i.checked ? "Usuario activado" : "Usuario desactivado", "Ya no podrá iniciar sesión"); dibujar(); }
      catch (e) { error(e); i.checked = !i.checked; }
    });
    cont.querySelectorAll("[data-borrar]").forEach(b => b.onclick = async () => {
      const u = lista.find(x => x.id == b.dataset.borrar);
      if (!(await confirmar("Eliminar usuario", `¿Eliminar a ${u.nombre} ${u.apellido} (${u.usuario})? Sus riegos y registros se conservan sin autor.`, "peligro", "Eliminar"))) return;
      try { await api("/usuarios/" + u.id, { metodo: "DELETE" }); aviso("Usuario eliminado"); dibujar(); } catch (e) { error(e); }
    });
  };
  try { await dibujar(); } catch (e) { error(e); }
}

// HU-14 · Historial de riegos, consumo por sector y reportes (CSV / PDF por impresión)
import { api, sesion, descargar } from "../api.js";
import { esc, num, icono, cargando, error, fechaHora, fechaCorta, hoyISO, diasAtrasISO, vacio } from "../ui.js";
import { barras } from "../charts.js";

const COLORES = ["#22c55e", "#38bdf8", "#f59e0b", "#a78bfa", "#f472b6", "#2dd4bf"];

export default async function historial(cont, { setTitulo }) {
  setTitulo("Historial y consumo", "Riegos realizados, litros por sector y reportes");
  const f = { desde: diasAtrasISO(7), hasta: hoyISO(), sector: "", tipo: "" };
  const sectores = await api("/sectores");
  const dibujar = async () => {
    cont.querySelector("#res").innerHTML = cargando();
    const q = new URLSearchParams(Object.entries(f).filter(([, v]) => v)).toString();
    const d = await api("/riegos?" + q);
    const total = d.por_sector.reduce((a, s) => a + s.litros, 0);
    const dias = [...new Set(d.por_dia.map(x => x.dia))];
    const cods = [...new Set(d.por_sector.map(s => s.codigo))];
    cont.querySelector("#res").innerHTML = `
      <div class="grid g4" style="margin-bottom:14px">
        <div class="card kpi"><span class="eti">Litros aplicados</span><div class="valor verde">${num(total, 0)}<small>L</small></div><div class="mut muy-peq">${fechaCorta(d.desde)} – ${fechaCorta(d.hasta)}</div></div>
        <div class="card kpi"><span class="eti">Riegos</span><div class="valor">${d.riegos.length}</div><div class="mut muy-peq">${d.riegos.filter(r => r.tipo === "manual").length} manuales · ${d.riegos.filter(r => r.tipo === "programado").length} programados · ${d.riegos.filter(r => r.estado === "fallido").length} fallidos</div></div>
        <div class="card kpi"><span class="eti">Lámina media</span><div class="valor">${num(total / Math.max(1, d.por_sector.length) / 10000 / Math.max(1, dias.length), 2)}<small>mm/día</small></div><div class="mut muy-peq">por sector de 1 ha</div></div>
        <div class="card kpi"><span class="eti">Promedio por riego</span><div class="valor">${num(total / Math.max(1, d.riegos.length), 0)}<small>L</small></div><div class="mut muy-peq">volumen real medido</div></div>
      </div>
      <div class="grid g2">
        <div class="card"><div class="card-t">${icono("historial")}<h3>Litros por día y sector</h3></div>
          ${dias.length ? barras(dias.map(fechaCorta), cods.map((c, i) => ({ nombre: c, color: COLORES[i % COLORES.length], valores: dias.map(di => (d.por_dia.find(x => x.dia === di && x.codigo === c) || {}).litros || 0) })), { apilar: true, alto: 230, fy: v => num(v / 1000, 0) + " k" }) : vacio()}</div>
        <div class="card"><div class="card-t">${icono("sectores")}<h3>Consumo por sector</h3></div>
          <table class="tabla"><thead><tr><th>Sector</th><th>Cultivo</th><th>Riegos</th><th>Litros</th><th>Lámina</th><th>%</th></tr></thead><tbody>
          ${d.por_sector.map(s => `<tr><td class="mono"><b>${esc(s.codigo)}</b></td><td>${esc(s.cultivo)}</td><td class="mono">${s.n}</td><td class="mono">${num(s.litros, 0)}</td><td class="mono">${num(s.litros / 10000, 1)} mm</td><td class="mono">${total ? num(s.litros / total * 100, 1) : 0} %</td></tr>`).join("")}
          </tbody></table></div>
        <div class="card span2"><div class="card-t">${icono("gota")}<h3>Detalle de riegos</h3><div class="der"><span class="eti">${d.riegos.length} registros</span></div></div>
          <div class="tabla-scroll"><table class="tabla"><thead><tr><th>Inicio</th><th>Fin</th><th>Sector</th><th>Tipo</th><th>Motivo</th><th>Plan (L)</th><th>Real (L)</th><th>Plan (min)</th><th>Estado</th><th>Usuario</th></tr></thead><tbody>
          ${d.riegos.map(r => `<tr><td class="peq">${fechaHora(r.inicio)}</td><td class="peq mut">${fechaHora(r.fin)}</td><td class="mono"><b>${esc(r.sector)}</b></td><td class="peq">${esc(r.tipo)}</td>
            <td class="peq" title="${esc(r.motivo_desc)}"><span class="mono">${esc(r.motivo)}</span></td><td class="mono">${num(r.litros_plan, 0)}</td><td class="mono">${num(r.litros_reales, 0)}</td><td class="mono">${num(r.duracion_plan_min, 0)}</td>
            <td><span class="pill ${r.estado === "completado" ? "verde" : r.estado === "en_curso" ? "azul" : r.estado === "fallido" ? "rojo" : "gris"}">${esc(r.estado)}</span></td><td class="peq mut">${esc(r.usuario || "sistema")}</td></tr>`).join("") || `<tr><td colspan="10">${vacio("Sin riegos en el periodo")}</td></tr>`}
          </tbody></table></div></div>
      </div>`;
  };

  cont.innerHTML = `
    <div class="card no-imprimir" style="margin-bottom:14px"><div class="fila envolver" style="align-items:flex-end">
      <div class="campo"><label>Desde</label><input class="input" type="date" id="desde" value="${f.desde}"></div>
      <div class="campo"><label>Hasta</label><input class="input" type="date" id="hasta" value="${f.hasta}"></div>
      <div class="campo"><label>Sector</label><select class="input" id="sector"><option value="">Todos</option>${sectores.map(s => `<option value="${s.id}">${esc(s.codigo)} · ${esc(s.cultivo)}</option>`).join("")}</select></div>
      <div class="campo"><label>Tipo</label><select class="input" id="tipo"><option value="">Todos</option><option value="automatico">Automático</option><option value="manual">Manual</option><option value="programado">Programado</option></select></div>
      <button class="btn prim" id="filtrar">Filtrar</button>
      ${sesion.puede("reportes.exportar") ? `<div class="fila" style="margin-left:auto"><button class="btn" id="csv">${icono("descarga")} CSV</button><button class="btn" id="pdf">${icono("imprimir")} PDF</button></div>` : ""}
    </div></div>
    <div class="solo-imprimir" style="display:none"></div>
    <div id="res"></div>`;
  const $ = q => cont.querySelector(q);
  $("#filtrar").onclick = () => {
    Object.assign(f, { desde: $("#desde").value, hasta: $("#hasta").value, sector: $("#sector").value, tipo: $("#tipo").value });
    if (f.desde > f.hasta) return error(new Error("La fecha inicial no puede ser mayor que la final"));
    dibujar().catch(error);
  };
  if ($("#csv")) $("#csv").onclick = () => descargar("/riegos/exportar.csv?" + new URLSearchParams(Object.entries(f).filter(([, v]) => v)), `riegos_${f.desde}_${f.hasta}.csv`).catch(error);
  if ($("#pdf")) $("#pdf").onclick = () => window.print();
  try { await dibujar(); } catch (e) { error(e); }
}

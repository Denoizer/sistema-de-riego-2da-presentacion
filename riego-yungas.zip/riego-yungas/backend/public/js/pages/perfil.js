// Perfil del usuario: datos, permisos y cambio de contraseña
import { api, sesion } from "../api.js";
import { esc, icono, error, aviso } from "../ui.js";

export default async function perfil(cont, { setTitulo }) {
  const u = sesion.usuario;
  setTitulo("Mi perfil", u.rol_nombre);
  cont.innerHTML = `<div class="grid g2">
    <div class="card"><div class="card-t">${icono("usuarios")}<h3>${esc(u.nombre)} ${esc(u.apellido)}</h3><div class="der"><span class="pill verde">${esc(u.rol_nombre)}</span></div></div>
      <div class="eti" style="margin-bottom:8px">Permisos de su rol</div>
      <div class="fila envolver">${u.permisos.map(p => `<span class="pill gris">${esc(p)}</span>`).join("")}</div>
      <div class="sep"></div>
      <button class="btn" id="notif">${icono("campana")} Activar notificaciones del navegador</button></div>
    <div class="card"><div class="card-t">${icono("escudo")}<h3>Cambiar contraseña</h3></div>
      <div class="col"><div class="campo"><label>Contraseña actual</label><input class="input" type="password" id="actual"></div>
      <div class="campo"><label>Nueva contraseña</label><input class="input" type="password" id="nueva"></div>
      <div class="campo"><label>Repetir nueva contraseña</label><input class="input" type="password" id="repetir"></div>
      <div class="ayuda-error" id="err"></div><button class="btn prim" id="cambiar">Actualizar contraseña</button></div></div></div>`;
  const $ = q => cont.querySelector(q);
  $("#cambiar").onclick = async () => {
    $("#err").textContent = "";
    if ($("#nueva").value !== $("#repetir").value) { $("#err").textContent = "Las contraseñas no coinciden"; return; }
    try { await api("/auth/clave", { metodo: "PUT", cuerpo: { actual: $("#actual").value, nueva: $("#nueva").value } }); aviso("Contraseña actualizada"); ["#actual", "#nueva", "#repetir"].forEach(q => { $(q).value = ""; }); }
    catch (e) { $("#err").textContent = e.message; }
  };
  $("#notif").onclick = async () => {
    if (!("Notification" in window)) return error(new Error("El navegador no soporta notificaciones"));
    const p = await Notification.requestPermission();
    aviso(p === "granted" ? "Notificaciones activadas" : "Permiso denegado", "");
  };
}

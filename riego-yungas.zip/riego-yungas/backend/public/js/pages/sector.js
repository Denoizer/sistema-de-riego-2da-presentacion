// Detalle de un sector: humedad 48 h, cálculo ETo→ETc→lámina→litros→tiempo, IA, decisiones y configuración
import { api, sesion } from "../api.js";
import { esc, num, icono, cargando, error, aviso, confirmar, pillEstado, pillDecision, fechaHora, hace, litros, modal, vacio } from "../ui.js";
import { dialogoRiegoManual } from "../componentes.js";
import { lineas, medidor } from "../charts.js";

export default async function sector(cont, { params, setTitulo, pagina }) {
  const id = Number(params[0]);
  let horas = 48;
  cont.innerHTML = cargando();

  const dibujar = async () => {
    const s = await api(`/sectores/${id}?horas=${horas}`);
    setTitulo(s.nombre, `${s.cultivo} · ${num(s.area_ha, 1)} ha · suelo ${s.textura}`);
    const r = s.riego, p = s.plan;
    const colorH = s.humedad < s.umbral ? "#ef4444" : s.humedad < s.umbral + 0.01 ? "#f59e0b" : "#22c55e";
    const serie = [
      { nombre: "Humedad promedio", color: "#22c55e", area: true, grosor: 2.4, puntos: s.serie.map(x => ({ x: x.fecha, y: x.humedad_prom })) },
      { nombre: "H1", color: "#38bdf8", grosor: 1, puntos: s.serie.map(x => ({ x: x.fecha, y: x.humedad_1 })) },
      { nombre: "H2", color: "#a78bfa", grosor: 1, puntos: s.serie.map(x => ({ x: x.fecha, y: x.humedad_2 })) },
      { nombre: "H3", color: "#f59e0b", grosor: 1, puntos: s.serie.map(x => ({ x: x.fecha, y: x.humedad_3 })) },
    ];
    cont.innerHTML = `
    <div class="fila entre envolver" style="margin-bottom:12px">
      <a class="btn chico fant" href="#/sectores">← Sectores</a>
      <div class="fila envolver">
        ${pillEstado(s.estado)} <span class="pill gris">Modo ${esc(s.modo)}</span>
        ${sesion.puede("riego.manual") ? (r ? `<button class="btn peligro chico" id="detener">${icono("stop")} Detener riego</button>`
          : `<button class="btn rosa chico" id="manual" ${["mantenimiento", "falla"].includes(s.estado) ? "disabled" : ""}>${icono("gota")} Regar por litros</button>
             <a class="btn chico" href="#/riego">${icono("calendario")} Programar</a>
             <button class="btn chico" id="evaluar">${icono("actualizar")} Evaluar ahora</button>`) : ""}
        ${sesion.puede("mantenimiento.gestionar") ? `<button class="btn chico ${s.modo === "mantenimiento" ? "prim" : "ambar"}" id="mant">${icono("llave")} ${s.modo === "mantenimiento" ? "Rehabilitar sector" : "Poner en mantenimiento"}</button>` : ""}
      </div>
    </div>

    <div class="grid g4" style="margin-bottom:14px">
      <div class="card" style="text-align:center"><div class="eti">Humedad del suelo θ</div>
        ${medidor(s.humedad ?? 0, s.theta_pmp, s.theta_cc + 0.05, { umbral: s.umbral, color: colorH, texto: num(s.humedad, 3) })}
        <div class="mut muy-peq">PMP ${num(s.theta_pmp, 2)} · umbral <b style="color:#ef4444">${num(s.umbral, 3)}</b> · CC ${num(s.theta_cc, 2)} m³/m³</div></div>
      <div class="card kpi"><span class="eti">Evapotranspiración</span><div class="valor verde">${num(s.etc_loc_mm, 2)}<small>mm/día</small></div>
        <div class="mut muy-peq">ETo ${num(s.eto_ref, 2)} × Kc ${num(s.kc, 2)} × Kr ${num(s.kr, 2)}${s.factor_kc_ia !== 1 ? " × IA " + num(s.factor_kc_ia, 3) : ""}</div></div>
      <div class="card kpi"><span class="eti">Déficit acumulado</span><div class="valor ${s.deficit_mm > 3 ? "ambar" : ""}">${num(s.deficit_mm, 2)}<small>mm</small></div>
        <div class="mut muy-peq">Último riego ${s.ultimo_riego ? hace(s.ultimo_riego) : "—"}</div></div>
      <div class="card kpi"><span class="eti">IA · humedad prevista 24 h</span><div class="valor azul">${s.ia && s.ia.humedad_pred_24h ? num(s.ia.humedad_pred_24h, 3) : "—"}</div>
        <div class="mut muy-peq">${s.ia ? `Fase ${esc(s.ia.fase)} · ${s.ia.n_muestras} muestras · MAE ${num(s.ia.mae, 4)}` : ""}</div></div>
    </div>

    ${r ? `<div class="card borde-verde" style="margin-bottom:14px">
      <div class="card-t">${icono("gota")}<h3>Riego ${esc(r.tipo)} en curso</h3><div class="der"><span class="pill verde pulso"><span class="pt"></span>Válvula abierta</span></div></div>
      <div class="grid g4">
        <div><div class="eti">Entregado</div><div class="valor azul">${num(r.litros, 0)}<small>/ ${num(r.litros_plan, 0)} L</small></div></div>
        <div><div class="eti">Caudal</div><div class="valor">${num(r.caudal_lmin, 0)}<small>L/min</small></div></div>
        <div><div class="eti">Tiempo restante</div><div class="valor">${r.min_restantes === null ? "—" : num(r.min_restantes, 0)}<small>min</small></div></div>
        <div><div class="eti">Duración planificada</div><div class="valor">${num(r.duracion_plan_min, 0)}<small>min</small></div></div>
      </div>
      <div class="barra azul" style="margin:12px 0 8px;height:10px"><i style="width:${r.pct}%"></i></div>
      <div class="mut peq">Motivo <b class="mono" style="color:var(--txt)">${esc(r.motivo || "")}</b> · ${esc(r.motivo_desc || "")} · iniciado ${fechaHora(r.inicio)}</div></div>` : ""}

    <div class="grid" style="grid-template-columns:minmax(0,2fr) minmax(0,1fr);gap:14px" id="g1">
      <div class="card"><div class="card-t">${icono("gota")}<h3>Humedad del suelo</h3>
        <div class="der">${[24, 48, 168].map(h => `<button class="tab ${h === horas ? "activo" : ""}" data-h="${h}">${h === 168 ? "7 d" : h + " h"}</button>`).join("")}</div></div>
        ${lineas(serie, { alto: 260, umbrales: [{ y: s.umbral, color: "#ef4444", texto: "umbral " + num(s.umbral, 3), leyenda: "Umbral de riego" }, { y: s.theta_cc, color: "#38bdf8", texto: "capacidad de campo", leyenda: "Capacidad de campo" }] })}</div>
      <div class="card"><div class="card-t">${icono("rayo")}<h3>Cálculo del riego (FAO-56)</h3></div>
        ${p ? `<table class="tabla"><tbody>
          <tr><td class="mut">ETo de referencia</td><td class="mono" style="text-align:right">${num(s.eto_ref, 2)} mm/d</td></tr>
          <tr><td class="mut">ETc localizada</td><td class="mono" style="text-align:right">${num(s.etc_loc_mm, 2)} mm/d</td></tr>
          <tr><td class="mut">Lámina neta Ln</td><td class="mono" style="text-align:right">${num(p.ln, 2)} mm</td></tr>
          <tr><td class="mut">Lámina bruta Lb = Ln / ${num(s.eficiencia, 2)}</td><td class="mono" style="text-align:right">${num(p.lb, 2)} mm</td></tr>
          <tr><td class="mut">Volumen V = Lb × ${num(s.area_ha * 10000, 0)} m²</td><td class="mono" style="text-align:right"><b>${litros(p.litros)}</b></td></tr>
          <tr><td class="mut">Tiempo t = V / ${num(s.caudal_nominal_lh, 0)} L/h</td><td class="mono" style="text-align:right"><b>${num(p.minutos, 0)} min</b></td></tr>
        </tbody></table>
        <div class="mut muy-peq" style="margin-top:8px">${num(s.n_plantas, 0)} plantas × ${s.goteros_por_planta} gotero(s) × ${num(s.caudal_gotero_lh, 1)} L/h · Zr ${num(s.prof_raiz_m, 2)} m · p ${num(s.p_agotamiento, 2)} · Pw ${num(s.fraccion_humedecida, 2)}</div>` : vacio()}
      </div>
    </div>

    <div class="grid g2" style="margin-top:14px">
      <div class="card"><div class="card-t">${icono("historial")}<h3>Decisiones del motor</h3></div>
        <div class="tabla-scroll"><table class="tabla"><thead><tr><th>Fecha</th><th>Decisión</th><th>θ / umbral</th><th>Detalle</th></tr></thead><tbody>
        ${s.decisiones.map(d => `<tr><td class="mut peq">${fechaHora(d.fecha)}</td><td>${pillDecision(d.decision)} <span class="mono muy-peq mut">${esc(d.codigo)}</span></td>
          <td class="mono peq">${num(d.humedad, 3)} / ${num(d.umbral, 3)}</td><td class="peq">${esc(d.detalle || "")}</td></tr>`).join("") || `<tr><td colspan="4">${vacio()}</td></tr>`}</tbody></table></div></div>
      <div class="card"><div class="card-t">${icono("gota")}<h3>Últimos riegos</h3></div>
        <div class="tabla-scroll"><table class="tabla"><thead><tr><th>Inicio</th><th>Tipo</th><th>Litros</th><th>Motivo</th><th>Estado</th></tr></thead><tbody>
        ${s.riegos.map(x => `<tr><td class="mut peq">${fechaHora(x.inicio)}</td><td class="peq">${esc(x.tipo)}</td><td class="mono peq">${num(x.litros_reales, 0)} / ${num(x.litros_plan, 0)}</td>
          <td class="mono peq" title="${esc(x.motivo_desc)}">${esc(x.motivo)}</td><td><span class="pill ${x.estado === "completado" ? "verde" : x.estado === "en_curso" ? "azul" : x.estado === "fallido" ? "rojo" : "gris"}">${esc(x.estado)}</span></td></tr>`).join("") || `<tr><td colspan="5">${vacio()}</td></tr>`}</tbody></table></div></div>
      <div class="card"><div class="card-t">${icono("sensor")}<h3>Sensores del nodo ${esc(s.nodo ? s.nodo.codigo : "")}</h3>
        <div class="der">${s.nodo ? `<span class="pill ${s.nodo.en_linea ? "verde" : "rojo"}"><span class="pt"></span>${s.nodo.en_linea ? "En línea" : "Sin conexión"}</span><span class="mono peq">${num(s.nodo.bateria_v, 2)} V · ${s.nodo.rssi_dbm} dBm</span>` : ""}</div></div>
        <table class="tabla"><thead><tr><th>Sensor</th><th>Modelo</th><th>Valor</th><th>Estado</th></tr></thead><tbody>
        ${s.sensores.map(x => `<tr><td class="peq">${esc(x.tipo)} ${esc(x.posicion || "")}</td><td class="mut peq">${esc(x.modelo || "")}</td><td class="mono">${num(x.ultimo_valor, x.tipo === "humedad" ? 3 : 1)} ${esc(x.unidad)}</td>
          <td><span class="pill ${x.estado === "ok" ? "verde" : "rojo"}">${esc(x.estado)}</span></td></tr>`).join("")}</tbody></table></div>
      ${sesion.puede("riego.configurar") ? `<div class="card"><div class="card-t">${icono("ajustes")}<h3>Configuración de riego del sector</h3></div>
        <div class="grid g2">
          <div class="campo"><label>Umbral de humedad (m³/m³)</label><input class="input" id="umbral" type="number" step="0.001" value="${s.umbral_base}"><div class="mut muy-peq">Entre ${s.theta_pmp} y ${s.theta_cc}. La IA puede ajustarlo ±10 %.</div></div>
          <div class="campo"><label>Modo</label><select class="input" id="modo" ${s.modo === "mantenimiento" ? "disabled" : ""}>
            <option value="automatico" ${s.modo === "automatico" ? "selected" : ""}>Automático</option><option value="manual" ${s.modo === "manual" ? "selected" : ""}>Solo manual</option>
            ${s.modo === "mantenimiento" ? '<option selected>Mantenimiento</option>' : ""}</select></div>
        </div>
        <div class="fila" style="margin-top:12px"><button class="btn prim" id="guardar">Guardar</button>
        ${sesion.puede("sectores.configurar") ? `<button class="btn" id="agro">${icono("ajustes")} Parámetros agronómicos</button>` : ""}</div></div>` : ""}
    </div>`;
    if (window.innerWidth < 1100) cont.querySelector("#g1").style.gridTemplateColumns = "1fr";

    const $ = q => cont.querySelector(q);
    cont.querySelectorAll("[data-h]").forEach(b => b.onclick = () => { horas = Number(b.dataset.h); dibujar(); });
    if ($("#manual")) $("#manual").onclick = () => dialogoRiegoManual(s, dibujar);
    if ($("#detener")) $("#detener").onclick = async () => {
      if (!(await confirmar("Detener riego", `¿Detener el riego del ${s.nombre}?`, "peligro", "Detener"))) return;
      try { await api(`/sectores/${id}/detener`, { metodo: "POST" }); aviso("Riego detenido"); dibujar(); } catch (e) { error(e); }
    };
    if ($("#evaluar")) $("#evaluar").onclick = async () => {
      try { const x = await api(`/sectores/${id}/evaluar`, { metodo: "POST" }); aviso("Evaluación del motor", "Decisión: " + x.decision.replace("_", " ")); dibujar(); } catch (e) { error(e); }
    };
    if ($("#mant")) $("#mant").onclick = async () => {
      const activar = s.modo !== "mantenimiento";
      if (!(await confirmar(activar ? "Poner en mantenimiento" : "Rehabilitar sector", activar ? "El sector dejará de regarse automáticamente hasta que lo rehabilite." : "El sector volverá al riego automático.", activar ? "ambar" : "prim"))) return;
      try { await api(`/sectores/${id}/mantenimiento`, { metodo: "PUT", cuerpo: { activar } }); aviso(activar ? "Sector en mantenimiento" : "Sector rehabilitado"); dibujar(); } catch (e) { error(e); }
    };
    if ($("#guardar")) $("#guardar").onclick = async () => {
      const cuerpo = { umbral_humedad: Number($("#umbral").value) };
      if (s.modo !== "mantenimiento") cuerpo.modo = $("#modo").value;
      try { await api(`/sectores/${id}/riego`, { metodo: "PUT", cuerpo }); aviso("Configuración guardada", s.nombre); dibujar(); } catch (e) { error(e); }
    };
    if ($("#agro")) $("#agro").onclick = async () => {
      const cfg = await api("/config");
      await modal({
        titulo: "Parámetros agronómicos · " + s.codigo,
        cuerpo: `<div class="campo"><label>Nombre</label><input class="input" id="a-nombre" value="${esc(s.nombre)}"></div>
          <div class="campo"><label>Cultivo</label><select class="input" id="a-cultivo">${cfg.cultivos.map(c => `<option value="${c.id}" ${c.nombre === s.cultivo ? "selected" : ""}>${esc(c.nombre)}</option>`).join("")}</select></div>
          <div class="grid g2">
            <div class="campo"><label>Área (ha)</label><input class="input" id="a-area" type="number" step="0.01" value="${s.area_ha}"></div>
            <div class="campo"><label>Plantas</label><input class="input" id="a-pl" type="number" value="${s.n_plantas}"></div>
            <div class="campo"><label>Goteros / planta</label><input class="input" id="a-go" type="number" value="${s.goteros_por_planta}"></div>
            <div class="campo"><label>Caudal gotero (L/h)</label><input class="input" id="a-qg" type="number" step="0.1" value="${s.caudal_gotero_lh}"></div>
            <div class="campo"><label>Eficiencia (Ea)</label><input class="input" id="a-ef" type="number" step="0.01" value="${s.eficiencia}"></div>
            <div class="campo"><label>Fracción humedecida (Pw)</label><input class="input" id="a-pw" type="number" step="0.05" value="${s.fraccion_humedecida}"></div>
          </div><div class="mut muy-peq">El caudal nominal se recalcula: plantas × goteros × caudal del gotero.</div>`,
        botones: [{ texto: "Cancelar", valor: false }, {
          texto: "Guardar", clase: "prim", accion: async el => {
            const v = q => el.querySelector(q).value;
            const x = await api(`/sectores/${id}`, { metodo: "PUT", cuerpo: { nombre: v("#a-nombre"), cultivo_id: Number(v("#a-cultivo")), area_ha: Number(v("#a-area")), n_plantas: Number(v("#a-pl")), goteros_por_planta: Number(v("#a-go")), caudal_gotero_lh: Number(v("#a-qg")), eficiencia: Number(v("#a-ef")), fraccion_humedecida: Number(v("#a-pw")) } });
            aviso("Sector actualizado", `Caudal nominal: ${num(x.caudal_nominal_lh, 0)} L/h`);
            dibujar();
          },
        }],
      });
    };
  };
  try { await dibujar(); } catch (e) { error(e); }
  pagina.refrescar = dibujar;
}

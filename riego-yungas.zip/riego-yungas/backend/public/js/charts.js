// Gráficos SVG livianos (sin librerías externas)
import { esc, num } from "./ui.js";

const t = s => (s instanceof Date ? s.getTime() : typeof s === "number" ? s : new Date(String(s).replace(" ", "T")).getTime());

/**
 * Gráfico de líneas.
 * series: [{ nombre, color, puntos: [{x, y}], area, dash }]
 * opts: { alto, min, max, umbrales: [{y, color, texto}], fy (formato eje Y), fx (formato eje X) }
 */
export function lineas(series, opts = {}) {
  const W = 640, H = opts.alto || 220, m = { l: 42, r: 12, t: 12, b: 26 };
  const todos = series.flatMap(s => s.puntos.filter(p => p.y !== null && p.y !== undefined && !Number.isNaN(p.y)));
  if (!todos.length) return `<div class="vacio">Sin datos para graficar</div>`;
  const xs = todos.map(p => t(p.x));
  let x0 = Math.min(...xs), x1 = Math.max(...xs);
  if (x0 === x1) x1 = x0 + 1;
  const ys = todos.map(p => p.y).concat((opts.umbrales || []).map(u => u.y));
  let y0 = opts.min ?? Math.min(...ys), y1 = opts.max ?? Math.max(...ys);
  if (opts.min === undefined || opts.max === undefined) { const pad = (y1 - y0) * 0.12 || 1; if (opts.min === undefined) y0 -= pad; if (opts.max === undefined) y1 += pad; }
  const X = v => m.l + ((t(v) - x0) / (x1 - x0)) * (W - m.l - m.r);
  const Y = v => H - m.b - ((v - y0) / (y1 - y0)) * (H - m.t - m.b);
  const fy = opts.fy || (v => num(v, Math.abs(y1 - y0) < 1 ? 3 : Math.abs(y1 - y0) < 10 ? 1 : 0));
  const fx = opts.fx || (v => { const d = new Date(v); return (x1 - x0) > 2 * 86400000 ? d.toLocaleDateString("es-BO", { day: "2-digit", month: "2-digit" }) : d.toLocaleTimeString("es-BO", { hour: "2-digit", minute: "2-digit" }); });
  let g = "";
  for (let i = 0; i <= 4; i++) {
    const v = y0 + ((y1 - y0) * i) / 4, y = Y(v);
    g += `<line x1="${m.l}" x2="${W - m.r}" y1="${y}" y2="${y}" stroke="#1d2a23" stroke-dasharray="3 4"/><text x="${m.l - 6}" y="${y + 3}" text-anchor="end">${esc(fy(v))}</text>`;
  }
  for (let i = 0; i <= 5; i++) {
    const v = x0 + ((x1 - x0) * i) / 5;
    g += `<text x="${X(v)}" y="${H - 8}" text-anchor="${i === 0 ? "start" : i === 5 ? "end" : "middle"}">${esc(fx(v))}</text>`;
  }
  for (const u of opts.umbrales || [])
    g += `<line x1="${m.l}" x2="${W - m.r}" y1="${Y(u.y)}" y2="${Y(u.y)}" stroke="${u.color || "#ef4444"}" stroke-width="1.2" stroke-dasharray="6 4"/>` +
         (u.texto ? `<text x="${W - m.r - 4}" y="${Y(u.y) - 5}" text-anchor="end" style="fill:${u.color || "#ef4444"}">${esc(u.texto)}</text>` : "");
  for (const s of series) {
    const pts = s.puntos.filter(p => p.y !== null && p.y !== undefined && !Number.isNaN(p.y)).sort((a, b) => t(a.x) - t(b.x));
    if (!pts.length) continue;
    const d = pts.map((p, i) => `${i ? "L" : "M"}${X(p.x).toFixed(1)},${Y(p.y).toFixed(1)}`).join("");
    if (s.area) {
      const id = "gr" + Math.random().toString(36).slice(2, 8);
      g += `<defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.color}" stop-opacity=".35"/><stop offset="1" stop-color="${s.color}" stop-opacity="0"/></linearGradient></defs>`;
      g += `<path d="${d}L${X(pts[pts.length - 1].x)},${H - m.b}L${X(pts[0].x)},${H - m.b}Z" fill="url(#${id})"/>`;
    }
    g += `<path d="${d}" fill="none" stroke="${s.color}" stroke-width="${s.grosor || 2}" ${s.dash ? `stroke-dasharray="${s.dash}"` : ""} stroke-linejoin="round"/>`;
  }
  const ley = series.length > 1 || (opts.umbrales || []).length
    ? `<div class="leyenda">${series.map(s => `<span><i style="background:${s.color}"></i>${esc(s.nombre)}</span>`).join("")}${(opts.umbrales || []).filter(u => u.leyenda).map(u => `<span><i style="background:${u.color}"></i>${esc(u.leyenda)}</span>`).join("")}</div>` : "";
  return `<div class="grafico"><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${g}</svg>${ley}</div>`;
}

/** Barras (agrupadas o apiladas). categorias: [..], series: [{nombre, color, valores: [..]}] */
export function barras(categorias, series, opts = {}) {
  const W = 640, H = opts.alto || 220, m = { l: 48, r: 10, t: 14, b: 28 };
  const apilar = !!opts.apilar;
  const maxV = Math.max(1, ...categorias.map((_, i) => apilar ? series.reduce((a, s) => a + (s.valores[i] || 0), 0) : Math.max(...series.map(s => s.valores[i] || 0))));
  const Y = v => H - m.b - (v / (maxV * 1.1)) * (H - m.t - m.b);
  const bw = (W - m.l - m.r) / Math.max(1, categorias.length);
  const fy = opts.fy || (v => num(v, 0));
  let g = "";
  for (let i = 0; i <= 4; i++) { const v = (maxV * 1.1 * i) / 4; g += `<line x1="${m.l}" x2="${W - m.r}" y1="${Y(v)}" y2="${Y(v)}" stroke="#1d2a23" stroke-dasharray="3 4"/><text x="${m.l - 6}" y="${Y(v) + 3}" text-anchor="end">${esc(fy(v))}</text>`; }
  categorias.forEach((c, i) => {
    const x = m.l + i * bw;
    if (apilar) {
      let acum = 0;
      series.forEach(s => { const v = s.valores[i] || 0; if (v > 0) g += `<rect x="${x + bw * 0.18}" y="${Y(acum + v)}" width="${bw * 0.64}" height="${Y(acum) - Y(acum + v)}" rx="3" fill="${s.color}"><title>${esc(s.nombre)}: ${esc(fy(v))}</title></rect>`; acum += v; });
    } else {
      const w = (bw * 0.7) / series.length;
      series.forEach((s, k) => { const v = s.valores[i] || 0; g += `<rect x="${x + bw * 0.15 + k * w}" y="${Y(v)}" width="${w - 2}" height="${H - m.b - Y(v)}" rx="3" fill="${s.color}"><title>${esc(s.nombre)}: ${esc(fy(v))}</title></rect>`; });
    }
    g += `<text x="${x + bw / 2}" y="${H - 9}" text-anchor="middle">${esc(c)}</text>`;
  });
  const ley = series.length > 1 ? `<div class="leyenda">${series.map(s => `<span><i style="background:${s.color}"></i>${esc(s.nombre)}</span>`).join("")}</div>` : "";
  return `<div class="grafico"><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${g}</svg>${ley}</div>`;
}

/** Ilustración del tanque con el nivel en porcentaje */
export function tanque(pct, llenando) {
  const p = Math.max(0, Math.min(100, pct || 0));
  const alto = 120, y = 18 + alto * (1 - p / 100);
  const color = p < 25 ? "#ef4444" : p < 45 ? "#f59e0b" : "#38bdf8";
  return `<svg class="tanque-svg" viewBox="0 0 110 160" width="100%" style="max-width:120px">
    <defs><linearGradient id="agua" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${color}" stop-opacity=".95"/><stop offset="1" stop-color="${color}" stop-opacity=".45"/></linearGradient>
    <clipPath id="tq"><rect x="15" y="18" width="80" height="120" rx="12"/></clipPath></defs>
    <rect x="15" y="18" width="80" height="120" rx="12" fill="#08100c" stroke="#263830" stroke-width="2"/>
    <g clip-path="url(#tq)"><rect class="agua" x="15" y="${y}" width="80" height="${138 - y}" fill="url(#agua)"/>
    <path d="M15 ${y} q10 -4 20 0 t20 0 t20 0 t20 0" fill="none" stroke="#ffffff55" stroke-width="1.5">
      <animateTransform attributeName="transform" type="translate" from="-20 0" to="0 0" dur="2s" repeatCount="indefinite"/></path></g>
    ${[25, 50, 75].map(k => `<line x1="88" x2="95" y1="${18 + alto * (1 - k / 100)}" y2="${18 + alto * (1 - k / 100)}" stroke="#56685d"/>`).join("")}
    <rect x="40" y="6" width="30" height="12" rx="3" fill="#121b17" stroke="#263830"/>
    ${llenando ? `<path d="M55 0v10" stroke="#38bdf8" stroke-width="3" stroke-dasharray="3 3"><animate attributeName="stroke-dashoffset" from="6" to="0" dur=".6s" repeatCount="indefinite"/></path>` : ""}
    <text x="55" y="154" text-anchor="middle" style="fill:#7d8f84;font-family:monospace;font-size:10px">${num(p, 1)} %</text></svg>`;
}

/** Medidor semicircular */
export function medidor(valor, min, max, { umbral, color = "#22c55e", texto = "" } = {}) {
  const f = Math.max(0, Math.min(1, (valor - min) / (max - min)));
  const ang = Math.PI * (1 - f);
  const x = 60 + 46 * Math.cos(ang), y = 60 - 46 * Math.sin(ang);
  let mu = "";
  if (umbral !== undefined) {
    const fu = (umbral - min) / (max - min), a = Math.PI * (1 - fu);
    mu = `<line x1="${60 + 38 * Math.cos(a)}" y1="${60 - 38 * Math.sin(a)}" x2="${60 + 54 * Math.cos(a)}" y2="${60 - 54 * Math.sin(a)}" stroke="#ef4444" stroke-width="2.5"/>`;
  }
  return `<svg viewBox="0 0 120 72" width="100%" style="max-width:170px">
    <path d="M14 60 A46 46 0 0 1 106 60" fill="none" stroke="#17221d" stroke-width="10" stroke-linecap="round"/>
    <path d="M14 60 A46 46 0 0 1 ${x.toFixed(1)} ${y.toFixed(1)}" fill="none" stroke="${color}" stroke-width="10" stroke-linecap="round"/>
    ${mu}<text x="60" y="56" text-anchor="middle" style="fill:#e7f0ea;font-weight:700;font-size:15px">${esc(texto)}</text></svg>`;
}

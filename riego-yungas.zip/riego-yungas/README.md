# 🌱 Riego Yungas IA

**Sistema de riego automatizado basado en evapotranspiración y predicción climática**
Finca de 4 ha · Coroico (Nor Yungas, La Paz) · 4 sectores de riego por goteo

Este proyecto implementa el Marco Práctico completo:

- **Base de datos MySQL**: 31 tablas, vistas, procedimientos, triggers y un evento programado.
- **Backend Node.js**:
  - API REST con autenticación JWT y permisos por rol.
  - Motor de decisión de riego con ETo FAO Penman-Monteith y balance hídrico.
  - Módulos de IA para predecir el clima y aprender cómo responde cada sector.
  - Alertas y notificaciones en tiempo real.
  - Simulador de campo.
- **Panel web responsivo** (modo oscuro), con un panel distinto para cada rol.
- **Firmware ESP32** para los nodos de sector y del tanque.

---

## Novedades de la versión 2

- **Nueva paleta de colores.** Verde (crecimiento, agua, calma) combinado con su color complementario, el magenta-rosa. El rosa se usa en acentos y en las acciones secundarias, y el verde en la acción principal.
- **Riego manual por litros.** Usted escribe los litros (o los minutos) y el sistema muestra cuánto tardará, la lámina aplicada, la hora en que termina y si el tanque alcanza. Está en la página **Riego manual** y en cada sector.
- **Riegos programados.** Puede programarlos por litros, para una sola vez o todos los días. Se pueden editar, pausar y eliminar, y se ejecutan solos.
- **Interruptores.** Puede activar o pausar el riego automático general y el de cada sector, las reglas, el llenado del tanque y los usuarios.
- **Gestión de usuarios.** El administrador añade **agricultores**, **técnicos** y administradores, asigna a cada agricultor sus **sectores a cargo**, y puede editar, desactivar o eliminar usuarios. Todo se guarda en MySQL.
- **Fallas del sistema de riego.**
  - Aparecen en el panel del administrador, del técnico y del agricultor.
  - Cada falla se notifica al **técnico** y al **agricultor a cargo de ese sector**.
- **Clima e IA:**
  - el clima **del momento**, en vivo (estación de la finca y Open-Meteo de Coroico);
  - el pronóstico **hora por hora** de las próximas 24 h;
  - el pronóstico de **4 días**;
  - la predicción de 72 h.
- **Base de datos v2.** Dos tablas nuevas: `usuario_sector` y `riegos_programados`. Además:
  - el motivo **M-10**;
  - el permiso `riego.programar`;
  - las vistas `v_fallas_activas` y `v_riegos_programados`.

**Para instalar la v2 tiene dos opciones:**

- **Desde cero.** Ejecute `database/riego_yungas.sql`. Borra y vuelve a crear la base.
- **Conservando sus datos de la v1.** Ejecute solo `database/04_actualizacion_v2.sql`.

---

## 1. Requisitos

| Programa | Versión | Uso |
|---|---|---|
| [Node.js](https://nodejs.org) | 18.17 o superior (recomendado 20 LTS o 22) | Ejecutar el backend |
| [MySQL Server + MySQL Workbench](https://dev.mysql.com/downloads/) | 8.0 o superior | Base de datos |
| [Visual Studio Code](https://code.visualstudio.com) | — | Editor |
| Arduino IDE / PlatformIO | — | Solo si va a programar los ESP32 reales |

## 2. Crear la base de datos en MySQL Workbench

1. Abra **MySQL Workbench** y conéctese como `root`.
2. Use **File → Open SQL Script** y ejecute ⚡ (*Execute*) el archivo único **`database/riego_yungas.sql`**. Si prefiere hacerlo por partes, ejecute **en este orden**:
   1. `database/01_esquema.sql`: crea la base `riego_yungas` y las 33 tablas.
   2. `database/02_datos_iniciales.sql`: carga roles, permisos, usuarios, finca, sectores, nodos, sensores y catálogos.
   3. `database/03_vistas_procedimientos.sql`: crea vistas, procedimientos, triggers, el evento y el usuario `riego_app`.
3. Para ver el diagrama de la base de datos, use **Database → Reverse Engineer…**, elija `riego_yungas` y siga los pasos hasta el final. También tiene el diagrama ya generado en `database/diagrama_er.png` y `database/diagrama_er.svg`.

> **Si el script 03 falla en `SET GLOBAL event_scheduler`**, su usuario no tiene privilegios de administrador. Puede omitir esa línea, porque el sistema funciona igual.
>
> Si prefiere conectarse con `root`, cambie `DB_USUARIO` y `DB_CLAVE` en `backend/.env`.

## 3. Ejecutar en Visual Studio Code

1. Abra la carpeta **`riego-yungas`** en VS Code (*File → Open Folder*).
2. Abra la terminal (**Ctrl + ñ** o *Terminal → New Terminal*) y ejecute:

```bash
cd backend
npm install          # instala la única dependencia: mysql2
npm run probar-db    # verifica la conexión a MySQL
npm run dev          # inicia el servidor (se reinicia al guardar cambios)
```

3. Abra **http://localhost:3000** en el navegador.

Otras formas de iniciarlo desde VS Code:

- **F5**, que usa la configuración *Iniciar backend*.
- **Ctrl + Shift + B**, que ejecuta la tarea *Iniciar en modo desarrollo*.

La **primera vez**, el backend genera **14 días de histórico** (lecturas, riegos, clima diario, ETo y muestras de IA) para que los paneles y reportes tengan datos desde el inicio.

## 4. Usuarios y roles

| Rol | Usuario | Contraseña | Puede |
|---|---|---|---|
| **Administrador** | `admin` | `Admin2026!` | Todo:<br>• usuarios y roles<br>• sectores y cultivos (Kc, caudales)<br>• reglas de automatización<br>• modelos de IA<br>• configuración global<br>• auditoría |
| **Agricultor / Productor** | `agricultor` | `Agro2026!` | • Panel<br>• sus sectores<br>• **riego manual por litros y programado**<br>• recibe las fallas de sus sectores<br>• tanque en litros y llenado<br>• clima y predicción<br>• historial y reportes CSV/PDF<br>• umbrales y horarios<br>• ver alertas |
| **Técnico de mantenimiento** | `tecnico` | `Tecnico2026!` | • Panel técnico (nodos, baterías, señal)<br>• sensores y **calibración**<br>• **atender alertas**<br>• mantenimiento<br>• pruebas de falla |

- Los permisos se guardan en las tablas `roles`, `permisos` y `rol_permiso`. El backend los **valida en cada solicitud**; ocultar el menú no es la única protección.
- La matriz completa está en *Usuarios y roles* (vista del administrador).
- Tras 5 intentos fallidos la cuenta se bloquea 5 minutos (HU-01).
- Las contraseñas se guardan cifradas con **scrypt**. Para crear un hash manualmente use `npm run hash -- "MiClave2026!"`.

## 5. Pantallas por rol

| Pantalla | Agricultor | Técnico | Admin | Historias de usuario |
|---|:-:|:-:|:-:|---|
| Panel de control (vista según el rol) | ✔ | ✔ | ✔ | HU-04, HU-05 |
| Sectores y detalle (humedad 48 h, cálculo FAO, decisiones) | ✔ | ✔ | ✔ | HU-04, HU-06, HU-07 |
| Riego manual por litros / programado / detener | ✔ | — | ✔ | HU-13 |
| Agua y tanque (litros, llenado, distribución por sector) | ✔ | ✔ | ✔ | HU-05, HU-06, HU-11 |
| Clima e IA (72 h, ETo diaria, calculadora Penman-Monteith) | ✔ | ✔ | ✔ | HU-09, HU-10 |
| Historial y reportes CSV/PDF | ✔ | — | ✔ | HU-14 |
| Alertas (ver / atender) | ver | atender | atender | HU-12 |
| Sensores y nodos, calibración | — | ✔ | ✔ | HU-18 |
| Mantenimiento y pruebas de falla | — | ✔ | ✔ | HU-18 |
| Automatización (reglas del motor) | — | — | ✔ | HU-07, HU-10 |
| Modelos de IA | — | — | ✔ | HU-15 |
| Usuarios y roles | — | — | ✔ | HU-02 |
| Configuración | parcial | — | ✔ | HU-03, HU-16 |
| Auditoría | — | — | ✔ | RNF-04 |

## 6. Modo simulación (sin hardware)

Con `SIMULADOR=1` en `backend/.env` el backend simula lo que haría el equipo de campo:

- los **4 nodos ESP32**: humedad, temperatura del suelo, caudal y batería;
- la **estación meteorológica**;
- el **tanque** y su llenado desde la vertiente.

`SIM_USAR_OPEN_METEO=1` hace que, si la PC tiene internet, el clima del momento y el pronóstico usen los datos reales de Coroico (Open-Meteo).

`SIM_ACELERACION=60` acelera los procesos físicos: 1 minuto real equivale a 1 hora de campo. Así se ve en pocos minutos cómo se seca el suelo, cómo el motor decide regar, cuántos litros salen del tanque y cómo se llena.

**Escenarios de demostración:**

1. **Riego automático.** Entre como `agricultor`, entre a un sector y pulse **Evaluar ahora**. Cuando la humedad baja del umbral, el sistema:
   - calcula ETo → ETc → lámina → litros → tiempo;
   - abre la válvula;
   - notifica el motivo (M-01);
   - descuenta el agua del tanque.
2. **Tanque bajo.** Si no hay agua suficiente, el sector queda en *Esperando agua* (M-07): se abre el llenado y llega la alerta A-01. Al llenarse, el sector se riega.
3. **Fallas.** Entre como `tecnico`, vaya a **Mantenimiento → Pruebas de falla** y elija *válvula trabada* en S2. Luego, como agricultor, inicie un riego manual en S2. Ocurre lo siguiente:
   - en menos de 60 s de campo llega la alerta **A-03**;
   - la válvula se cierra;
   - el sector pasa a *En falla*.

   El técnico la atiende y el sector se rehabilita. También puede probar fuga (A-04), nodo caído (A-05), sensor dañado (A-06), batería baja (A-07) y falla de llenado (A-02).
4. **Lluvia.** En la misma sección aplique lluvia simulada. El corte por pluviometría (M-09) suspende el riego.

Para usar **hardware real** ponga `SIMULADOR=0`. Los ESP32 envían datos a:

- `POST /api/iot/lecturas` (cabecera `X-Api-Key` con la clave del nodo, que está en la tabla `nodos`);
- `GET /api/iot/comandos`.

Vea `firmware/` y `docs/pruebas_api.http`.

## 7. Estructura del proyecto

```
riego-yungas/
├── database/
│   ├── 01_esquema.sql               33 tablas (7 módulos)
│   ├── 02_datos_iniciales.sql       roles, permisos, usuarios, finca, sectores, catálogos
│   ├── 03_vistas_procedimientos.sql vistas, SP, triggers, evento, usuario de la app
│   └── diagrama_er.png / .svg       modelo entidad-relación
├── backend/
│   ├── .env                          configuración (MySQL, simulador)
│   ├── package.json
│   ├── src/
│   │   ├── server.js                 punto de entrada
│   │   ├── db.js                     pool MySQL
│   │   ├── auth/                     scrypt, JWT, permisos por rol
│   │   ├── http/app.js               enrutador HTTP
│   │   ├── routes/                   auth, sectores, clima, historial, alertas, dispositivos, admin, iot
│   │   ├── motor/                    eto.js (Penman-Monteith), decision.js, riego.js, ingesta.js,
│   │   │                             supervisor.js, simulador.js, historico.js
│   │   ├── ia/                       clima.js (predicción 72 h), sector.js (aprendizaje por sector)
│   │   └── servicios/                alertas, notificaciones (SSE), auditoría, configuración
│   └── public/                       panel web (HTML, CSS, JavaScript sin frameworks)
├── firmware/                         nodo_sector.ino, nodo_tanque.ino (ESP32)
├── ia_python/                        entrenamiento LSTM y Random Forest (opcional)
└── docs/                             capturas y pruebas de la API
```

## 8. Coherencia con el Marco Práctico

| Marco práctico | Implementación |
|---|---|
| 3.8 RF-01 a RF-28 | `backend/src/routes/*` y `backend/src/motor/*` |
| 3.14 ETo / ETc / lámina / tiempo | `motor/eto.js`, `motor/decision.js` (función `calcularPlan`). La calculadora de *Clima e IA* da 2,78 mm/día con el ejemplo del 15 de julio |
| 3.15 IA: predicción, horizontes 6/24/48/72 h, fases de aprendizaje | `ia/clima.js`, `ia/sector.js`, tabla `modelos_ia` |
| 3.15.3 Motivos M-01 a M-09 | tabla `motivos`, registrados en `decisiones` |
| 3.19.7 Alertas A-01 a A-11 | tabla `tipos_alerta`, `servicios/alertas.js` |
| 3.16 Base de datos | **MySQL** (reemplaza a Firebase). Las notificaciones se envían por SSE al navegador y se guardan en `notificaciones` |
| 3.20 Pruebas | escenarios de la sección 6 y `docs/pruebas_api.http` |

## 9. Solución de problemas

| Problema | Solución |
|---|---|
| `No se pudo conectar a MySQL` | Verifique que el servicio MySQL esté iniciado, que ejecutó los 3 scripts y los datos de `backend/.env` |
| `ER_ACCESS_DENIED_ERROR` | El usuario `riego_app` no existe: ejecute de nuevo `03_vistas_procedimientos.sql` o use `root` en `.env` |
| `EADDRINUSE :3000` | El puerto está ocupado: cambie `PUERTO=3001` en `.env` |
| `npm` no se reconoce | Instale Node.js y reinicie VS Code |
| Quiero reiniciar los datos | Ejecute de nuevo los 3 scripts SQL; el histórico se regenera al iniciar |

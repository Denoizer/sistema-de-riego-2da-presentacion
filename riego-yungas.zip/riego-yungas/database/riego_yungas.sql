-- =====================================================================
--  riego_yungas.sql – v2 · SCRIPT COMPLETO (esquema + datos + vistas/SP/triggers)
--  MySQL Workbench: File > Open SQL Script > Ejecutar (rayo ⚡)
--  ATENCIÓN: borra y vuelve a crear la base riego_yungas.
-- =====================================================================

-- =====================================================================
--  SISTEMA DE RIEGO AUTOMATIZADO BASADO EN EVAPOTRANSPIRACIÓN
--  Y PREDICCIÓN CLIMÁTICA  –  Finca de 4 ha, Coroico (Nor Yungas)
--  Script 01: ESQUEMA DE LA BASE DE DATOS (MySQL 8.0 / Workbench)
-- =====================================================================
--  Ejecutar en MySQL Workbench en este orden:
--    01_esquema.sql  ->  02_datos_iniciales.sql  ->  03_vistas_procedimientos.sql
-- =====================================================================

DROP DATABASE IF EXISTS riego_yungas;
CREATE DATABASE riego_yungas CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;
USE riego_yungas;

SET NAMES utf8mb4;
SET time_zone = '-04:00';

-- ---------------------------------------------------------------------
--  MÓDULO 1: SEGURIDAD (roles, permisos, usuarios, auditoría)
-- ---------------------------------------------------------------------
CREATE TABLE roles (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(20) NOT NULL,
  nombre VARCHAR(60) NOT NULL,
  descripcion VARCHAR(255) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_roles_codigo (codigo)
) ENGINE=InnoDB COMMENT='Roles del sistema: admin, agricultor, tecnico';

CREATE TABLE permisos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(50) NOT NULL,
  modulo VARCHAR(40) NOT NULL,
  descripcion VARCHAR(255) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_permisos_codigo (codigo)
) ENGINE=InnoDB COMMENT='Permisos atómicos por funcionalidad';

CREATE TABLE rol_permiso (
  rol_id INT UNSIGNED NOT NULL,
  permiso_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (rol_id, permiso_id),
  CONSTRAINT fk_rp_rol FOREIGN KEY (rol_id) REFERENCES roles (id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_permiso FOREIGN KEY (permiso_id) REFERENCES permisos (id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='Matriz de permisos por rol';

CREATE TABLE usuarios (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  rol_id INT UNSIGNED NOT NULL,
  usuario VARCHAR(40) NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  apellido VARCHAR(80) NOT NULL,
  correo VARCHAR(120) NOT NULL,
  telefono VARCHAR(20) NULL,
  password_hash VARCHAR(255) NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  intentos_fallidos INT NOT NULL DEFAULT 0,
  bloqueado_hasta DATETIME NULL,
  ultimo_acceso DATETIME NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuarios_usuario (usuario),
  UNIQUE KEY uq_usuarios_correo (correo),
  CONSTRAINT fk_usuarios_rol FOREIGN KEY (rol_id) REFERENCES roles (id)
) ENGINE=InnoDB COMMENT='Usuarios con contraseña cifrada (scrypt)';

CREATE TABLE auditoria (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id INT UNSIGNED NULL,
  accion VARCHAR(60) NOT NULL,
  entidad VARCHAR(40) NULL,
  entidad_id VARCHAR(40) NULL,
  detalle VARCHAR(500) NULL,
  ip VARCHAR(45) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_auditoria_fecha (fecha),
  CONSTRAINT fk_auditoria_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='Bitácora de acciones de usuarios';

-- ---------------------------------------------------------------------
--  MÓDULO 2: FINCA, CULTIVOS, SUELOS Y SECTORES
-- ---------------------------------------------------------------------
CREATE TABLE fincas (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  municipio VARCHAR(60) NOT NULL,
  provincia VARCHAR(60) NOT NULL,
  departamento VARCHAR(60) NOT NULL,
  latitud DECIMAL(9,6) NOT NULL,
  longitud DECIMAL(9,6) NOT NULL,
  altitud_m DECIMAL(7,1) NOT NULL,
  area_ha DECIMAL(6,2) NOT NULL,
  zona_horaria VARCHAR(40) NOT NULL DEFAULT 'America/La_Paz',
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE cultivos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(60) NOT NULL,
  nombre_cientifico VARCHAR(80) NULL,
  kc_inicial DECIMAL(4,2) NOT NULL,
  kc_medio DECIMAL(4,2) NOT NULL,
  kc_final DECIMAL(4,2) NOT NULL,
  kr DECIMAL(4,2) NOT NULL COMMENT 'Coeficiente de reducción por cobertura (goteo)',
  prof_raiz_m DECIMAL(4,2) NOT NULL,
  p_agotamiento DECIMAL(4,2) NOT NULL COMMENT 'Fracción de agotamiento permitida',
  PRIMARY KEY (id),
  UNIQUE KEY uq_cultivos_nombre (nombre)
) ENGINE=InnoDB COMMENT='Coeficientes FAO-56 por cultivo';

CREATE TABLE suelos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  textura VARCHAR(40) NOT NULL,
  theta_cc DECIMAL(4,3) NOT NULL COMMENT 'Capacidad de campo (m3/m3)',
  theta_pmp DECIMAL(4,3) NOT NULL COMMENT 'Punto de marchitez permanente (m3/m3)',
  densidad_aparente DECIMAL(4,2) NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE sectores (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  finca_id INT UNSIGNED NOT NULL,
  codigo VARCHAR(10) NOT NULL,
  nombre VARCHAR(60) NOT NULL,
  cultivo_id INT UNSIGNED NOT NULL,
  suelo_id INT UNSIGNED NOT NULL,
  area_ha DECIMAL(5,2) NOT NULL,
  n_plantas INT NOT NULL,
  goteros_por_planta INT NOT NULL,
  caudal_gotero_lh DECIMAL(5,2) NOT NULL,
  caudal_nominal_lh DECIMAL(10,2) NOT NULL,
  eficiencia DECIMAL(4,2) NOT NULL DEFAULT 0.90,
  fraccion_humedecida DECIMAL(4,2) NOT NULL DEFAULT 0.50,
  umbral_base DECIMAL(4,3) NOT NULL COMMENT 'Umbral agronómico calculado',
  umbral_humedad DECIMAL(4,3) NOT NULL COMMENT 'Umbral efectivo (ajustable por IA ±10%)',
  factor_kc_ia DECIMAL(4,3) NOT NULL DEFAULT 1.000,
  modo ENUM('automatico','manual','mantenimiento') NOT NULL DEFAULT 'automatico',
  estado ENUM('reposo','evaluando','regando','pospuesto','esperando_agua','falla','mantenimiento') NOT NULL DEFAULT 'reposo',
  deficit_mm DECIMAL(6,2) NOT NULL DEFAULT 0,
  pospuesto_hasta DATETIME NULL,
  ultimo_riego DATETIME NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sectores_codigo (finca_id, codigo),
  CONSTRAINT fk_sectores_finca FOREIGN KEY (finca_id) REFERENCES fincas (id),
  CONSTRAINT fk_sectores_cultivo FOREIGN KEY (cultivo_id) REFERENCES cultivos (id),
  CONSTRAINT fk_sectores_suelo FOREIGN KEY (suelo_id) REFERENCES suelos (id)
) ENGINE=InnoDB COMMENT='Sectores de riego de 1 ha';

CREATE TABLE usuario_sector (
  usuario_id INT UNSIGNED NOT NULL,
  sector_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (usuario_id, sector_id),
  CONSTRAINT fk_us_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
  CONSTRAINT fk_us_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='Sectores a cargo de cada agricultor (recibe sus alertas)';

-- ---------------------------------------------------------------------
--  MÓDULO 3: DISPOSITIVOS (nodos, sensores, calibraciones)
-- ---------------------------------------------------------------------
CREATE TABLE nodos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(20) NOT NULL,
  tipo ENUM('sector','tanque','central') NOT NULL,
  sector_id INT UNSIGNED NULL,
  descripcion VARCHAR(120) NULL,
  api_key VARCHAR(64) NOT NULL,
  firmware VARCHAR(20) NULL,
  bateria_v DECIMAL(4,2) NULL,
  rssi_dbm INT NULL,
  en_linea TINYINT(1) NOT NULL DEFAULT 0,
  ultima_conexion DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_nodos_codigo (codigo),
  UNIQUE KEY uq_nodos_api_key (api_key),
  CONSTRAINT fk_nodos_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='Nodos ESP32 (LoRa) y unidad central';

CREATE TABLE sensores (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nodo_id INT UNSIGNED NOT NULL,
  tipo ENUM('humedad','temp_suelo','caudal','nivel','temp_aire','hr','presion','viento','radiacion','lluvia') NOT NULL,
  posicion VARCHAR(20) NULL,
  modelo VARCHAR(40) NULL,
  unidad VARCHAR(15) NOT NULL,
  adc_seco INT NULL,
  adc_saturado INT NULL,
  factor_calibracion DECIMAL(8,4) NOT NULL DEFAULT 1.0000,
  rango_min DECIMAL(10,3) NULL,
  rango_max DECIMAL(10,3) NULL,
  ultimo_valor DECIMAL(10,3) NULL,
  estado ENUM('ok','falla','calibrando') NOT NULL DEFAULT 'ok',
  ultima_calibracion DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_sensores_nodo FOREIGN KEY (nodo_id) REFERENCES nodos (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE calibraciones (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sensor_id INT UNSIGNED NOT NULL,
  tecnico_id INT UNSIGNED NULL,
  adc_seco INT NULL,
  adc_saturado INT NULL,
  factor DECIMAL(8,4) NULL,
  observacion VARCHAR(255) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_calib_sensor FOREIGN KEY (sensor_id) REFERENCES sensores (id) ON DELETE CASCADE,
  CONSTRAINT fk_calib_tecnico FOREIGN KEY (tecnico_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  MÓDULO 4: TELEMETRÍA (lecturas de sectores, estación y tanque)
-- ---------------------------------------------------------------------
CREATE TABLE lecturas_sector (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  humedad_prom DECIMAL(5,3) NULL,
  humedad_1 DECIMAL(5,3) NULL,
  humedad_2 DECIMAL(5,3) NULL,
  humedad_3 DECIMAL(5,3) NULL,
  temp_suelo DECIMAL(5,2) NULL,
  caudal_lmin DECIMAL(8,2) NULL,
  bateria_v DECIMAL(4,2) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_ls_sector_fecha (sector_id, fecha),
  CONSTRAINT fk_ls_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='Lecturas de nodos de sector (cada 5 min)';

CREATE TABLE lecturas_estacion (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  temp_c DECIMAL(5,2) NOT NULL,
  hr_pct DECIMAL(5,2) NOT NULL,
  presion_kpa DECIMAL(6,2) NULL,
  viento_ms DECIMAL(5,2) NOT NULL,
  radiacion_wm2 DECIMAL(7,2) NOT NULL,
  lluvia_mm DECIMAL(6,2) NOT NULL DEFAULT 0,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_le_fecha (fecha)
) ENGINE=InnoDB COMMENT='Estación meteorológica (cada 10 min)';

CREATE TABLE clima_diario (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  fecha DATE NOT NULL,
  tmax DECIMAL(5,2) NOT NULL,
  tmin DECIMAL(5,2) NOT NULL,
  hrmax DECIMAL(5,2) NOT NULL,
  hrmin DECIMAL(5,2) NOT NULL,
  viento_ms DECIMAL(5,2) NOT NULL,
  rs_mj DECIMAL(6,2) NOT NULL COMMENT 'Radiación solar MJ/m2·día',
  lluvia_mm DECIMAL(6,2) NOT NULL,
  eto_mm DECIMAL(5,2) NOT NULL COMMENT 'ETo FAO Penman-Monteith',
  PRIMARY KEY (id),
  UNIQUE KEY uq_clima_fecha (fecha)
) ENGINE=InnoDB;

CREATE TABLE tanques (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  finca_id INT UNSIGNED NOT NULL,
  nombre VARCHAR(60) NOT NULL,
  capacidad_l DECIMAL(10,1) NOT NULL,
  nivel_l DECIMAL(10,1) NOT NULL,
  umbral_min_pct DECIMAL(5,2) NOT NULL DEFAULT 25,
  umbral_max_pct DECIMAL(5,2) NOT NULL DEFAULT 95,
  caudal_entrada_ls DECIMAL(5,2) NOT NULL DEFAULT 1.20,
  llenando TINYINT(1) NOT NULL DEFAULT 0,
  llenado_desde DATETIME NULL,
  nivel_inicio_llenado DECIMAL(10,1) NULL,
  actualizado_en DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_tanques_finca FOREIGN KEY (finca_id) REFERENCES fincas (id)
) ENGINE=InnoDB;

CREATE TABLE lecturas_tanque (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tanque_id INT UNSIGNED NOT NULL,
  nivel_l DECIMAL(10,1) NOT NULL,
  porcentaje DECIMAL(5,2) NOT NULL,
  caudal_salida_lmin DECIMAL(8,2) NOT NULL DEFAULT 0,
  llenando TINYINT(1) NOT NULL DEFAULT 0,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_lt_fecha (tanque_id, fecha),
  CONSTRAINT fk_lt_tanque FOREIGN KEY (tanque_id) REFERENCES tanques (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  MÓDULO 5: RIEGO Y DECISIONES
-- ---------------------------------------------------------------------
CREATE TABLE motivos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(6) NOT NULL,
  decision ENUM('regar','no_regar','posponer','esperar','suspender') NOT NULL,
  descripcion VARCHAR(200) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_motivos_codigo (codigo)
) ENGINE=InnoDB COMMENT='Catálogo M-01..M-09 del marco práctico';

CREATE TABLE riegos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  usuario_id INT UNSIGNED NULL,
  tipo ENUM('automatico','manual','programado') NOT NULL,
  programado_id INT UNSIGNED NULL,
  motivo_id INT UNSIGNED NOT NULL,
  lamina_mm DECIMAL(6,2) NULL,
  litros_plan DECIMAL(10,1) NOT NULL,
  litros_reales DECIMAL(10,1) NOT NULL DEFAULT 0,
  caudal_prom_lmin DECIMAL(8,2) NULL,
  duracion_plan_min DECIMAL(7,1) NOT NULL,
  inicio DATETIME NOT NULL,
  fin DATETIME NULL,
  estado ENUM('en_curso','completado','cancelado','fallido') NOT NULL DEFAULT 'en_curso',
  PRIMARY KEY (id),
  KEY idx_riegos_sector_inicio (sector_id, inicio),
  CONSTRAINT fk_riegos_sector FOREIGN KEY (sector_id) REFERENCES sectores (id),
  CONSTRAINT fk_riegos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL,
  CONSTRAINT fk_riegos_motivo FOREIGN KEY (motivo_id) REFERENCES motivos (id)
) ENGINE=InnoDB;

CREATE TABLE riegos_programados (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  usuario_id INT UNSIGNED NULL,
  litros DECIMAL(10,1) NOT NULL,
  hora TIME NOT NULL,
  proxima_ejecucion DATETIME NOT NULL,
  repetir ENUM('una_vez','diario') NOT NULL DEFAULT 'una_vez',
  activo TINYINT(1) NOT NULL DEFAULT 1,
  nota VARCHAR(200) NULL,
  ultima_ejecucion DATETIME NULL,
  creado_en DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_prog_proxima (activo, proxima_ejecucion),
  CONSTRAINT fk_prog_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE,
  CONSTRAINT fk_prog_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='Riegos manuales programados por litros (una vez o diario)';

CREATE TABLE decisiones (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  motivo_id INT UNSIGNED NOT NULL,
  decision ENUM('regar','no_regar','posponer','esperar','suspender') NOT NULL,
  humedad DECIMAL(5,3) NULL,
  umbral DECIMAL(5,3) NULL,
  eto_mm DECIMAL(5,2) NULL,
  etc_loc_mm DECIMAL(5,2) NULL,
  deficit_mm DECIMAL(6,2) NULL,
  lluvia_prevista_mm DECIMAL(6,2) NULL,
  prob_lluvia DECIMAL(5,2) NULL,
  humedad_pred_24h DECIMAL(5,3) NULL,
  detalle VARCHAR(300) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_decisiones_fecha (sector_id, fecha),
  CONSTRAINT fk_dec_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE,
  CONSTRAINT fk_dec_motivo FOREIGN KEY (motivo_id) REFERENCES motivos (id)
) ENGINE=InnoDB COMMENT='Trazabilidad de cada decisión del motor';

CREATE TABLE comandos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nodo_id INT UNSIGNED NOT NULL,
  usuario_id INT UNSIGNED NULL,
  accion ENUM('abrir','cerrar','llenar','detener_llenado','reiniciar') NOT NULL,
  litros DECIMAL(10,1) NULL,
  minutos INT NULL,
  estado ENUM('pendiente','enviado','ejecutado','rechazado') NOT NULL DEFAULT 'pendiente',
  creado_en DATETIME NOT NULL,
  ejecutado_en DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_comandos_nodo (nodo_id, estado),
  CONSTRAINT fk_cmd_nodo FOREIGN KEY (nodo_id) REFERENCES nodos (id) ON DELETE CASCADE,
  CONSTRAINT fk_cmd_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='Órdenes enviadas a los nodos';

CREATE TABLE horarios_riego (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  hora TIME NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE reglas_automatizacion (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(30) NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(300) NOT NULL,
  parametro VARCHAR(40) NULL,
  valor DECIMAL(10,3) NULL,
  unidad VARCHAR(15) NULL,
  activa TINYINT(1) NOT NULL DEFAULT 1,
  actualizado_en DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_reglas_codigo (codigo)
) ENGINE=InnoDB COMMENT='Reglas de disparo/corte del motor de decisión';

CREATE TABLE configuracion (
  clave VARCHAR(50) NOT NULL,
  valor VARCHAR(100) NOT NULL,
  tipo ENUM('numero','booleano','texto') NOT NULL DEFAULT 'numero',
  descripcion VARCHAR(200) NULL,
  editable_por ENUM('admin','agricultor') NOT NULL DEFAULT 'admin',
  PRIMARY KEY (clave)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  MÓDULO 6: INTELIGENCIA ARTIFICIAL
-- ---------------------------------------------------------------------
CREATE TABLE modelos_ia (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  tipo ENUM('clima','sector') NOT NULL,
  sector_id INT UNSIGNED NULL,
  algoritmo VARCHAR(60) NOT NULL,
  version INT NOT NULL DEFAULT 1,
  fase ENUM('observacion','recomendacion','adaptacion') NOT NULL DEFAULT 'observacion',
  n_muestras INT NOT NULL DEFAULT 0,
  mae DECIMAL(8,4) NULL,
  rmse DECIMAL(8,4) NULL,
  parametros TEXT NULL COMMENT 'Pesos del modelo serializados (JSON)',
  activo TINYINT(1) NOT NULL DEFAULT 1,
  entrenado_en DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_modelos_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE muestras_ia (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  humedad DECIMAL(5,3) NOT NULL,
  etc_loc_mm DECIMAL(5,2) NOT NULL,
  temp_suelo DECIMAL(5,2) NULL,
  lluvia_prev_mm DECIMAL(6,2) NULL,
  horas_desde_riego DECIMAL(7,1) NULL,
  humedad_objetivo DECIMAL(5,3) NULL COMMENT 'Humedad real observada 24 h después',
  fecha DATETIME NOT NULL,
  fecha_objetivo DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_muestras_pend (sector_id, fecha_objetivo),
  CONSTRAINT fk_muestras_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='Datos de entrenamiento del aprendizaje por sector';

CREATE TABLE predicciones (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  generado_en DATETIME NOT NULL,
  horizonte_h INT NOT NULL,
  fecha_objetivo DATETIME NOT NULL,
  temp_c DECIMAL(5,2) NULL,
  hr_pct DECIMAL(5,2) NULL,
  lluvia_mm DECIMAL(6,2) NULL,
  prob_lluvia DECIMAL(5,2) NULL,
  eto_mm DECIMAL(5,2) NULL,
  fuente ENUM('local','open_meteo','fusion') NOT NULL,
  PRIMARY KEY (id),
  KEY idx_pred_generado (generado_en)
) ENGINE=InnoDB COMMENT='Predicción climática horaria 72 h';

-- ---------------------------------------------------------------------
--  MÓDULO 7: ALERTAS, NOTIFICACIONES Y MANTENIMIENTO
-- ---------------------------------------------------------------------
CREATE TABLE tipos_alerta (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(6) NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  severidad ENUM('critica','alta','media','info') NOT NULL,
  destinatarios VARCHAR(60) NOT NULL COMMENT 'Roles separados por coma',
  PRIMARY KEY (id),
  UNIQUE KEY uq_tipos_alerta_codigo (codigo)
) ENGINE=InnoDB COMMENT='Catálogo A-01..A-11';

CREATE TABLE alertas (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  tipo_alerta_id INT UNSIGNED NOT NULL,
  sector_id INT UNSIGNED NULL,
  nodo_id INT UNSIGNED NULL,
  mensaje VARCHAR(300) NOT NULL,
  atendida TINYINT(1) NOT NULL DEFAULT 0,
  atendida_por INT UNSIGNED NULL,
  atendida_en DATETIME NULL,
  nota_atencion VARCHAR(300) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_alertas_estado (atendida, fecha),
  CONSTRAINT fk_alertas_tipo FOREIGN KEY (tipo_alerta_id) REFERENCES tipos_alerta (id),
  CONSTRAINT fk_alertas_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE SET NULL,
  CONSTRAINT fk_alertas_nodo FOREIGN KEY (nodo_id) REFERENCES nodos (id) ON DELETE SET NULL,
  CONSTRAINT fk_alertas_usuario FOREIGN KEY (atendida_por) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE notificaciones (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id INT UNSIGNED NOT NULL,
  titulo VARCHAR(100) NOT NULL,
  mensaje VARCHAR(300) NOT NULL,
  nivel ENUM('critica','alta','media','info') NOT NULL DEFAULT 'info',
  leida TINYINT(1) NOT NULL DEFAULT 0,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_notif_usuario (usuario_id, leida),
  CONSTRAINT fk_notif_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='Notificaciones push por usuario';

CREATE TABLE mantenimientos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nodo_id INT UNSIGNED NULL,
  sector_id INT UNSIGNED NULL,
  tecnico_id INT UNSIGNED NULL,
  tipo ENUM('preventivo','correctivo','calibracion') NOT NULL,
  descripcion VARCHAR(400) NOT NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_mant_nodo FOREIGN KEY (nodo_id) REFERENCES nodos (id) ON DELETE SET NULL,
  CONSTRAINT fk_mant_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE SET NULL,
  CONSTRAINT fk_mant_tecnico FOREIGN KEY (tecnico_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
--  Script 02: DATOS INICIALES (catálogos, roles, usuarios, finca)
--  El histórico de lecturas (14 días) lo genera el backend al iniciar
--  por primera vez (ver backend/src/motor/historico.js).
-- =====================================================================
USE riego_yungas;

-- ------------------------------ ROLES --------------------------------
INSERT INTO roles (id, codigo, nombre, descripcion) VALUES
 (1, 'admin',      'Administrador',            'Configura la plataforma: usuarios, sectores, cultivos, reglas e IA.'),
 (2, 'agricultor', 'Agricultor / Productor',   'Monitorea la finca, recibe notificaciones, riega manualmente y consulta historial.'),
 (3, 'tecnico',    'Técnico de mantenimiento', 'Atiende alertas, calibra sensores y registra mantenimientos.');

-- ----------------------------- PERMISOS ------------------------------
INSERT INTO permisos (id, codigo, modulo, descripcion) VALUES
 (1,  'dashboard.ver',          'Panel',          'Ver el panel de control'),
 (2,  'sectores.ver',           'Sectores',       'Ver estado y detalle de sectores'),
 (3,  'riego.manual',           'Sectores',       'Iniciar y detener riego manual'),
 (4,  'tanque.ver',             'Tanque',         'Ver nivel del tanque en litros'),
 (5,  'tanque.operar',          'Tanque',         'Iniciar/detener llenado manual del tanque'),
 (6,  'clima.ver',              'Clima e IA',     'Ver clima actual y predicción 72 h'),
 (7,  'historial.ver',          'Historial',      'Ver historial de riegos y consumo'),
 (8,  'reportes.exportar',      'Historial',      'Exportar reportes CSV/PDF'),
 (9,  'alertas.ver',            'Alertas',        'Ver alertas del sistema'),
 (10, 'alertas.atender',        'Alertas',        'Marcar alertas como atendidas'),
 (11, 'sensores.ver',           'Sensores',       'Ver nodos, sensores, batería y señal'),
 (12, 'sensores.calibrar',      'Sensores',       'Calibrar sensores'),
 (13, 'mantenimiento.gestionar','Mantenimiento',  'Poner sectores en mantenimiento y registrar trabajos'),
 (14, 'riego.configurar',       'Configuración',  'Configurar umbrales, horarios y probabilidad de lluvia'),
 (15, 'sectores.configurar',    'Configuración',  'Configurar sectores, cultivos, Kc y caudales'),
 (16, 'automatizacion.gestionar','Automatización','Activar/desactivar y parametrizar reglas'),
 (17, 'ia.ver',                 'Clima e IA',     'Ver modelos de IA y sus métricas'),
 (18, 'ia.reentrenar',          'Clima e IA',     'Forzar reentrenamiento de modelos'),
 (19, 'usuarios.gestionar',     'Usuarios',       'Crear, editar y desactivar usuarios'),
 (20, 'auditoria.ver',          'Usuarios',       'Ver la bitácora de auditoría'),
 (21, 'simulacion.fallas',      'Mantenimiento',  'Inyectar fallas de prueba (modo simulación)'),
 (22, 'riego.programar',        'Sectores',       'Programar riegos por litros (una vez o diario)');

-- Administrador: todos los permisos
INSERT INTO rol_permiso (rol_id, permiso_id) SELECT 1, id FROM permisos;
-- Agricultor
INSERT INTO rol_permiso (rol_id, permiso_id) VALUES
 (2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(2,9),(2,14),(2,22);
-- Técnico
INSERT INTO rol_permiso (rol_id, permiso_id) VALUES
 (3,1),(3,2),(3,4),(3,6),(3,9),(3,10),(3,11),(3,12),(3,13),(3,21);

-- ----------------------------- USUARIOS ------------------------------
-- Contraseñas (cámbielas en producción):
--   admin      / Admin2026!
--   agricultor / Agro2026!
--   tecnico    / Tecnico2026!
INSERT INTO usuarios (id, rol_id, usuario, nombre, apellido, correo, telefono, password_hash) VALUES
 (1, 1, 'admin',      'Andrea', 'Rojas',  'admin@riegoyungas.bo',      '70000001', 'scrypt$16384$8$1$gGKWYjUbtUMqt5xUPptr8g==$nbHMKxlL+eCOoqV32JVs7ME5QdFJCSpaLYPJGtFUnw0lfLWCcXaqA+2oPgs4VSGHTAgxlG++/rn1PctqvrHf0g=='),
 (2, 2, 'agricultor', 'Juan',   'Quispe', 'agricultor@riegoyungas.bo', '70000002', 'scrypt$16384$8$1$9dpTVsAqFqGe97rP+oA6hQ==$bfTJCXRm6TzxYWXP/180bjh44mCBSI2r7/4q7dG2n81/Ank2YI/7WU+Vc+xBmrvahTJdMK/ZGbosIEBDrTDJrQ=='),
 (3, 3, 'tecnico',    'Luis',   'Choque', 'tecnico@riegoyungas.bo',    '70000003', 'scrypt$16384$8$1$pGw9TG8Db9noov7cwEbkjA==$3e7bfXmQqaeGL1OM82EmVA3TBhysAFRec+Re5Ekh0teG2Z50biyl6nVjEbU9kE3LYgIc12LQEz/HNNcuvfkhyg==');

-- ------------------------ FINCA, CULTIVOS, SUELO ---------------------
INSERT INTO fincas (id, nombre, municipio, provincia, departamento, latitud, longitud, altitud_m, area_ha) VALUES
 (1, 'Finca de estudio – Coroico', 'Coroico', 'Nor Yungas', 'La Paz', -16.190000, -67.730000, 1700.0, 4.00);

INSERT INTO cultivos (id, nombre, nombre_cientifico, kc_inicial, kc_medio, kc_final, kr, prof_raiz_m, p_agotamiento) VALUES
 (1, 'Café',     'Coffea arabica',     0.90, 0.95, 0.95, 0.70, 0.60, 0.25),
 (2, 'Cítricos', 'Citrus spp.',        0.65, 0.65, 0.65, 0.60, 0.80, 0.30),
 (3, 'Banano',   'Musa × paradisiaca', 0.50, 1.10, 1.10, 0.80, 0.50, 0.20);

INSERT INTO suelos (id, textura, theta_cc, theta_pmp, densidad_aparente) VALUES
 (1, 'Franco', 0.300, 0.150, 1.35);

-- ----------------------------- SECTORES ------------------------------
-- caudal_nominal = n_plantas × goteros × caudal_gotero
-- umbral = θcc − p·(θcc − θpmp)
INSERT INTO sectores (id, finca_id, codigo, nombre, cultivo_id, suelo_id, area_ha, n_plantas, goteros_por_planta, caudal_gotero_lh, caudal_nominal_lh, eficiencia, fraccion_humedecida, umbral_base, umbral_humedad) VALUES
 (1, 1, 'S1', 'Sector 1 – Café',     1, 1, 1.00, 5000, 1, 2.00, 10000.00, 0.90, 0.50, 0.263, 0.263),
 (2, 1, 'S2', 'Sector 2 – Café',     1, 1, 1.00, 5000, 1, 2.00, 10000.00, 0.90, 0.50, 0.263, 0.263),
 (3, 1, 'S3', 'Sector 3 – Cítricos', 2, 1, 1.00,  400, 4, 4.00,  6400.00, 0.90, 0.50, 0.255, 0.255),
 (4, 1, 'S4', 'Sector 4 – Banano',   3, 1, 1.00, 1600, 2, 4.00, 12800.00, 0.90, 0.50, 0.270, 0.270);

-- --------------------- SECTORES A CARGO DEL AGRICULTOR ---------------
INSERT INTO usuario_sector (usuario_id, sector_id) VALUES (2,1),(2,2),(2,3),(2,4);

-- ------------------------------ TANQUE -------------------------------
INSERT INTO tanques (id, finca_id, nombre, capacidad_l, nivel_l, umbral_min_pct, umbral_max_pct, caudal_entrada_ls) VALUES
 (1, 1, 'Tanque principal', 50000.0, 34600.0, 25.00, 95.00, 1.20);

-- ------------------------------- NODOS -------------------------------
INSERT INTO nodos (id, codigo, tipo, sector_id, descripcion, api_key, firmware, bateria_v, rssi_dbm, en_linea) VALUES
 (1, 'N-S1', 'sector',  1,    'Nodo ESP32 + LoRa – Sector 1', 'ec499973e6acfcb570ff6e1f', 'v1.0.3', 12.90, -92, 1),
 (2, 'N-S2', 'sector',  2,    'Nodo ESP32 + LoRa – Sector 2', '6bcc9b2607d20e3f8a4570c4', 'v1.0.3', 12.85, -97, 1),
 (3, 'N-S3', 'sector',  3,    'Nodo ESP32 + LoRa – Sector 3', '8f3978bf8e25123a261244aa', 'v1.0.3', 12.95, -101, 1),
 (4, 'N-S4', 'sector',  4,    'Nodo ESP32 + LoRa – Sector 4', '4faabfddaa7f0937d71f8adc', 'v1.0.3', 12.80, -104, 1),
 (5, 'N-TQ', 'tanque',  NULL, 'Nodo ESP32 + LoRa – Tanque',   '6d0c708cedf6911a6dfa132e', 'v1.0.3', 12.90, -88, 1),
 (6, 'UC-01','central', NULL, 'Unidad central Raspberry Pi 4 + estación meteorológica', '7d6c70756485e3940600fa44', 'v1.2.0', 12.95, 0, 1);

-- ------------------------------ SENSORES -----------------------------
INSERT INTO sensores (nodo_id, tipo, posicion, modelo, unidad, adc_seco, adc_saturado, rango_min, rango_max) VALUES
 (1,'humedad','H1','Capacitivo v1.2','m³/m³',3200,1350,0.05,0.50),(1,'humedad','H2','Capacitivo v1.2','m³/m³',3180,1400,0.05,0.50),(1,'humedad','H3','Capacitivo v1.2','m³/m³',3210,1380,0.05,0.50),
 (1,'temp_suelo','T1','DS18B20','°C',NULL,NULL,-5,50),(1,'caudal','Q1','YF-DN40','L/min',NULL,NULL,0,400),
 (2,'humedad','H1','Capacitivo v1.2','m³/m³',3190,1360,0.05,0.50),(2,'humedad','H2','Capacitivo v1.2','m³/m³',3205,1390,0.05,0.50),(2,'humedad','H3','Capacitivo v1.2','m³/m³',3170,1370,0.05,0.50),
 (2,'temp_suelo','T1','DS18B20','°C',NULL,NULL,-5,50),(2,'caudal','Q1','YF-DN40','L/min',NULL,NULL,0,400),
 (3,'humedad','H1','Capacitivo v1.2','m³/m³',3220,1410,0.05,0.50),(3,'humedad','H2','Capacitivo v1.2','m³/m³',3195,1385,0.05,0.50),(3,'humedad','H3','Capacitivo v1.2','m³/m³',3185,1365,0.05,0.50),
 (3,'temp_suelo','T1','DS18B20','°C',NULL,NULL,-5,50),(3,'caudal','Q1','YF-DN40','L/min',NULL,NULL,0,400),
 (4,'humedad','H1','Capacitivo v1.2','m³/m³',3210,1375,0.05,0.50),(4,'humedad','H2','Capacitivo v1.2','m³/m³',3200,1395,0.05,0.50),(4,'humedad','H3','Capacitivo v1.2','m³/m³',3180,1355,0.05,0.50),
 (4,'temp_suelo','T1','DS18B20','°C',NULL,NULL,-5,50),(4,'caudal','Q1','YF-DN40','L/min',NULL,NULL,0,400),
 (5,'nivel','US1','JSN-SR04T','L',NULL,NULL,0,50000),(5,'caudal','QS','YF-DN50','L/min',NULL,NULL,0,800),
 (6,'temp_aire','BME','BME280','°C',NULL,NULL,-10,45),(6,'hr','BME','BME280','%',NULL,NULL,0,100),(6,'presion','BME','BME280','kPa',NULL,NULL,70,90),
 (6,'viento','ANE','Anemómetro','m/s',NULL,NULL,0,40),(6,'radiacion','PIR','Piranómetro Si','W/m²',NULL,NULL,0,1400),(6,'lluvia','PLU','Pluviómetro balancín','mm',NULL,NULL,0,200);

-- ------------------------------ MOTIVOS ------------------------------
INSERT INTO motivos (id, codigo, decision, descripcion) VALUES
 (1, 'M-01', 'regar',     'Humedad del suelo (θ) bajo el umbral del sector'),
 (2, 'M-02', 'regar',     'Déficit hídrico acumulado por ETc supera la lámina mínima'),
 (3, 'M-03', 'regar',     'La IA prevé que el sector alcanzará el umbral antes del próximo ciclo'),
 (4, 'M-04', 'regar',     'Riego manual iniciado por el usuario'),
 (5, 'M-05', 'no_regar',  'Suelo con humedad suficiente'),
 (6, 'M-06', 'posponer',  'Lluvia prevista suficiente (≥ lámina neta y probabilidad ≥ mínima)'),
 (7, 'M-07', 'esperar',   'Volumen insuficiente en el tanque; llenado en curso'),
 (8, 'M-08', 'suspender', 'Falla detectada (válvula sin caudal, fuga o sensor con error)'),
 (9, 'M-09', 'suspender', 'Lluvia en curso detectada por el pluviómetro'),
 (10, 'M-10', 'regar',    'Riego programado por el usuario (litros definidos)');

-- --------------------------- TIPOS DE ALERTA -------------------------
INSERT INTO tipos_alerta (id, codigo, nombre, severidad, destinatarios) VALUES
 (1,  'A-01', 'Tanque requiere llenado',        'alta',    'agricultor,admin'),
 (2,  'A-02', 'Falla en el llenado',            'critica', 'agricultor,tecnico,admin'),
 (3,  'A-03', 'Falla de válvula / tubería',     'critica', 'agricultor,tecnico,admin'),
 (4,  'A-04', 'Posible fuga',                   'critica', 'agricultor,tecnico,admin'),
 (5,  'A-05', 'Nodo sin comunicación',          'alta',    'agricultor,tecnico,admin'),
 (6,  'A-06', 'Sensor con falla',               'media',   'agricultor,tecnico,admin'),
 (7,  'A-07', 'Batería baja',                   'media',   'agricultor,tecnico,admin'),
 (8,  'A-08', 'Unidad central sin internet',    'alta',    'agricultor,tecnico,admin'),
 (9,  'A-09', 'Consumo anómalo',                'media',   'agricultor,tecnico,admin'),
 (10, 'A-10', 'Lluvia intensa prevista',        'info',    'agricultor,admin'),
 (11, 'A-11', 'Evento de riego',                'info',    'agricultor,admin');

-- ------------------------ REGLAS DE AUTOMATIZACIÓN -------------------
INSERT INTO reglas_automatizacion (codigo, nombre, descripcion, parametro, valor, unidad, activa) VALUES
 ('DISPARO_DEFICIT',  'Disparo por déficit radicular', 'Inicia el riego cuando la humedad promedio del sector cae bajo su umbral (θcc − p·ADT).', 'umbral', NULL, 'm³/m³', 1),
 ('CORTE_LLUVIA',     'Corte automático por pluviometría', 'Suspende o impide el riego si el pluviómetro registra lluvia en la última hora por encima del valor.', 'lluvia_1h', 2.000, 'mm/h', 1),
 ('POSPONER_PRONOST', 'Aplazamiento por pronóstico de lluvia', 'Pospone el riego si la lluvia efectiva prevista en 24 h cubre la lámina neta con probabilidad ≥ valor.', 'prob_lluvia', 60.000, '%', 1),
 ('BLOQUEO_TANQUE',   'Reserva mínima del tanque', 'No inicia riegos si el tanque quedaría por debajo de esta reserva.', 'reserva_pct', 10.000, '%', 1),
 ('LLENADO_AUTO',     'Llenado automático del tanque', 'Abre la válvula de llenado bajo el umbral mínimo y la cierra al umbral máximo.', 'umbral_min', 25.000, '%', 1),
 ('ANTICIPO_IA',      'Riego anticipado por IA', 'En fase de adaptación, riega si la IA predice que el sector cruzará el umbral en las próximas 24 h sin lluvia.', 'margen', 0.005, 'm³/m³', 1),
 ('DETECCION_FUGA',   'Detección de fugas', 'Genera alerta crítica si hay caudal con la válvula cerrada por encima del valor.', 'caudal_max', 2.000, 'L/min', 1);

-- ---------------------------- CONFIGURACIÓN --------------------------
INSERT INTO configuracion (clave, valor, tipo, descripcion, editable_por) VALUES
 ('riego_automatico',         '1',    'booleano', 'Activa o desactiva el riego automático global', 'agricultor'),
 ('evaluacion_continua_min',  '10',   'numero',   'Intervalo de evaluación continua (min reales)', 'admin'),
 ('max_min_riego',            '180',  'numero',   'Duración máxima de un riego (min)', 'agricultor'),
 ('lamina_minima_mm',         '1.0',  'numero',   'Lámina neta mínima para justificar un riego (mm)', 'admin'),
 ('posponer_horas',           '6',    'numero',   'Horas que se pospone un riego por lluvia prevista', 'admin'),
 ('lluvia_intensa_mm',        '30',   'numero',   'Lluvia prevista 24 h que genera alerta A-10 (mm)', 'admin'),
 ('bateria_min_v',            '11.8', 'numero',   'Tensión mínima de batería antes de alertar (V)', 'admin'),
 ('nodo_timeout_min',         '15',   'numero',   'Minutos sin reporte para considerar un nodo fuera de línea', 'admin'),
 ('usar_open_meteo',          '1',    'booleano', 'Fusionar la predicción local con Open-Meteo', 'admin');

INSERT INTO horarios_riego (hora, activo) VALUES ('05:00:00', 1), ('17:00:00', 1);

-- ---------------------------- MODELOS IA -----------------------------
INSERT INTO modelos_ia (tipo, sector_id, algoritmo, version, fase) VALUES
 ('clima', NULL, 'Regresión armónica + persistencia (fusión con Open-Meteo)', 1, 'observacion'),
 ('sector', 1, 'Regresión lineal en línea (SGD)', 1, 'observacion'),
 ('sector', 2, 'Regresión lineal en línea (SGD)', 1, 'observacion'),
 ('sector', 3, 'Regresión lineal en línea (SGD)', 1, 'observacion'),
 ('sector', 4, 'Regresión lineal en línea (SGD)', 1, 'observacion');

-- =====================================================================
--  Script 03: VISTAS, PROCEDIMIENTOS ALMACENADOS, TRIGGERS Y EVENTOS
-- =====================================================================
USE riego_yungas;

-- ------------------------------ VISTAS -------------------------------
CREATE OR REPLACE VIEW v_estado_sectores AS
SELECT s.id, s.codigo, s.nombre, c.nombre AS cultivo, s.area_ha, s.modo, s.estado,
       s.umbral_humedad, s.deficit_mm, s.caudal_nominal_lh,
       (SELECT ls.humedad_prom FROM lecturas_sector ls
         WHERE ls.sector_id = s.id ORDER BY ls.fecha DESC LIMIT 1) AS humedad_actual,
       (SELECT ls.fecha FROM lecturas_sector ls
         WHERE ls.sector_id = s.id ORDER BY ls.fecha DESC LIMIT 1) AS ultima_lectura,
       n.bateria_v, n.rssi_dbm, n.en_linea
FROM sectores s
JOIN cultivos c ON c.id = s.cultivo_id
LEFT JOIN nodos n ON n.sector_id = s.id AND n.tipo = 'sector'
WHERE s.activo = 1;

CREATE OR REPLACE VIEW v_consumo_diario_sector AS
SELECT DATE(r.inicio) AS fecha, s.codigo, c.nombre AS cultivo,
       COUNT(*) AS n_riegos,
       ROUND(SUM(r.litros_reales), 1) AS litros,
       ROUND(SUM(TIMESTAMPDIFF(SECOND, r.inicio, COALESCE(r.fin, r.inicio))) / 60, 1) AS minutos
FROM riegos r
JOIN sectores s ON s.id = r.sector_id
JOIN cultivos c ON c.id = s.cultivo_id
WHERE r.estado IN ('completado', 'cancelado')
GROUP BY DATE(r.inicio), s.codigo, c.nombre;

CREATE OR REPLACE VIEW v_alertas_activas AS
SELECT a.id, t.codigo, t.nombre, t.severidad, a.mensaje, s.codigo AS sector, n.codigo AS nodo, a.fecha
FROM alertas a
JOIN tipos_alerta t ON t.id = a.tipo_alerta_id
LEFT JOIN sectores s ON s.id = a.sector_id
LEFT JOIN nodos n ON n.id = a.nodo_id
WHERE a.atendida = 0
ORDER BY FIELD(t.severidad, 'critica', 'alta', 'media', 'info'), a.fecha DESC;

CREATE OR REPLACE VIEW v_fallas_activas AS
SELECT a.id, t.codigo, t.nombre, t.severidad, a.mensaje, s.codigo AS sector, n.codigo AS nodo, a.fecha,
       (SELECT GROUP_CONCAT(CONCAT(u.nombre, ' ', u.apellido) SEPARATOR ', ')
          FROM usuario_sector us JOIN usuarios u ON u.id = us.usuario_id
         WHERE us.sector_id = a.sector_id) AS agricultores_a_cargo
FROM alertas a
JOIN tipos_alerta t ON t.id = a.tipo_alerta_id
LEFT JOIN sectores s ON s.id = a.sector_id
LEFT JOIN nodos n ON n.id = a.nodo_id
WHERE a.atendida = 0 AND t.codigo IN ('A-02','A-03','A-04','A-05','A-06','A-07','A-08');

CREATE OR REPLACE VIEW v_riegos_programados AS
SELECT p.id, s.codigo AS sector, p.litros, ROUND(p.litros / s.caudal_nominal_lh * 60, 1) AS minutos_estimados,
       p.hora, p.repetir, p.proxima_ejecucion, p.activo, CONCAT(u.nombre, ' ', u.apellido) AS creado_por
FROM riegos_programados p JOIN sectores s ON s.id = p.sector_id LEFT JOIN usuarios u ON u.id = p.usuario_id;

CREATE OR REPLACE VIEW v_permisos_usuario AS
SELECT u.id AS usuario_id, u.usuario, r.codigo AS rol, p.codigo AS permiso
FROM usuarios u
JOIN roles r ON r.id = u.rol_id
JOIN rol_permiso rp ON rp.rol_id = r.id
JOIN permisos p ON p.id = rp.permiso_id
WHERE u.activo = 1;

CREATE OR REPLACE VIEW v_resumen_tanque AS
SELECT t.id, t.nombre, t.capacidad_l, t.nivel_l,
       ROUND(t.nivel_l / t.capacidad_l * 100, 1) AS porcentaje,
       t.umbral_min_pct, t.umbral_max_pct, t.llenando, t.actualizado_en,
       CASE WHEN t.nivel_l / t.capacidad_l * 100 < t.umbral_min_pct THEN 'REQUIERE LLENADO'
            WHEN t.llenando = 1 THEN 'LLENANDO'
            ELSE 'NORMAL' END AS situacion
FROM tanques t;

-- ------------------------ PROCEDIMIENTOS -----------------------------
DROP PROCEDURE IF EXISTS sp_consumo_por_sector;
DELIMITER $$
CREATE PROCEDURE sp_consumo_por_sector(IN p_desde DATE, IN p_hasta DATE)
BEGIN
  SELECT s.codigo, c.nombre AS cultivo,
         COUNT(r.id) AS n_riegos,
         COALESCE(ROUND(SUM(r.litros_reales), 1), 0) AS litros,
         COALESCE(ROUND(SUM(r.litros_reales) / (s.area_ha * 10000), 2), 0) AS lamina_mm
  FROM sectores s
  JOIN cultivos c ON c.id = s.cultivo_id
  LEFT JOIN riegos r ON r.sector_id = s.id
       AND DATE(r.inicio) BETWEEN p_desde AND p_hasta
       AND r.estado IN ('completado', 'cancelado')
  GROUP BY s.id, s.codigo, c.nombre, s.area_ha
  ORDER BY s.codigo;
END $$

DROP PROCEDURE IF EXISTS sp_registrar_lectura_sector $$
CREATE PROCEDURE sp_registrar_lectura_sector(
  IN p_sector INT, IN p_h1 DECIMAL(5,3), IN p_h2 DECIMAL(5,3), IN p_h3 DECIMAL(5,3),
  IN p_temp DECIMAL(5,2), IN p_caudal DECIMAL(8,2), IN p_bat DECIMAL(4,2))
BEGIN
  INSERT INTO lecturas_sector (sector_id, humedad_prom, humedad_1, humedad_2, humedad_3, temp_suelo, caudal_lmin, bateria_v, fecha)
  VALUES (p_sector, ROUND((p_h1 + p_h2 + p_h3) / 3, 3), p_h1, p_h2, p_h3, p_temp, p_caudal, p_bat, NOW());
  UPDATE nodos SET bateria_v = p_bat, en_linea = 1, ultima_conexion = NOW()
   WHERE sector_id = p_sector AND tipo = 'sector';
END $$

DROP PROCEDURE IF EXISTS sp_eto_rango $$
CREATE PROCEDURE sp_eto_rango(IN p_desde DATE, IN p_hasta DATE)
BEGIN
  SELECT fecha, tmax, tmin, rs_mj, lluvia_mm, eto_mm
  FROM clima_diario WHERE fecha BETWEEN p_desde AND p_hasta ORDER BY fecha;
END $$
DELIMITER ;

-- ------------------------------ TRIGGERS -----------------------------
DROP TRIGGER IF EXISTS trg_sectores_bi;
DROP TRIGGER IF EXISTS trg_sectores_bu;
DROP TRIGGER IF EXISTS trg_usuarios_au;
DELIMITER $$
-- Calcula automáticamente el caudal nominal del sector
CREATE TRIGGER trg_sectores_bi BEFORE INSERT ON sectores FOR EACH ROW
BEGIN
  SET NEW.caudal_nominal_lh = NEW.n_plantas * NEW.goteros_por_planta * NEW.caudal_gotero_lh;
END $$
CREATE TRIGGER trg_sectores_bu BEFORE UPDATE ON sectores FOR EACH ROW
BEGIN
  SET NEW.caudal_nominal_lh = NEW.n_plantas * NEW.goteros_por_planta * NEW.caudal_gotero_lh;
END $$
-- Audita cambios de rol o de estado de los usuarios
CREATE TRIGGER trg_usuarios_au AFTER UPDATE ON usuarios FOR EACH ROW
BEGIN
  IF OLD.rol_id <> NEW.rol_id OR OLD.activo <> NEW.activo THEN
    INSERT INTO auditoria (usuario_id, accion, entidad, entidad_id, detalle, fecha)
    VALUES (NULL, 'TRIGGER_CAMBIO_USUARIO', 'usuarios', NEW.id,
            CONCAT('rol ', OLD.rol_id, '→', NEW.rol_id, ', activo ', OLD.activo, '→', NEW.activo), NOW());
  END IF;
END $$
DELIMITER ;

-- ------------------------------ EVENTOS ------------------------------
-- Depuración automática de telemetría antigua (requiere event_scheduler=ON)
SET GLOBAL event_scheduler = ON;
DROP EVENT IF EXISTS ev_depurar_telemetria;
DELIMITER $$
CREATE EVENT ev_depurar_telemetria
  ON SCHEDULE EVERY 1 DAY STARTS (CURRENT_DATE + INTERVAL 1 DAY + INTERVAL 3 HOUR)
  DO
    BEGIN
      DELETE FROM lecturas_sector   WHERE fecha < NOW() - INTERVAL 180 DAY;
      DELETE FROM lecturas_estacion WHERE fecha < NOW() - INTERVAL 365 DAY;
      DELETE FROM lecturas_tanque   WHERE fecha < NOW() - INTERVAL 180 DAY;
      DELETE FROM predicciones      WHERE generado_en < NOW() - INTERVAL 30 DAY;
    END $$
DELIMITER ;

-- ------------------------- USUARIO DE LA APP -------------------------
-- Usuario MySQL con privilegios mínimos para el backend
DROP USER IF EXISTS 'riego_app'@'localhost';
CREATE USER 'riego_app'@'localhost' IDENTIFIED BY 'RiegoApp2026!';
GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE ON riego_yungas.* TO 'riego_app'@'localhost';
FLUSH PRIVILEGES;

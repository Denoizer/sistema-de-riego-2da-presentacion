-- =====================================================================
--  Script 02: DATOS INICIALES (catálogos, roles, usuarios, finca)
--  El histórico de lecturas (14 días) lo genera el backend al iniciar
--  por primera vez (ver backend/src/motor/historico.js).
-- =====================================================================
USE riego_yungas;

-- ------------------------------ ROLES --------------------------------
INSERT INTO roles (id, codigo, nombre, descripcion) VALUES
 (1, 'admin',      'Administrador',            'Configura la plataforma: usuarios, sectores, cultivos, reglas e IA.'),
 (2, 'agricultor', 'Agricultor / Productor',   'Monitorea la finca, recibe notificaciones, riega manualmente y consulta historial.'),
 (3, 'tecnico',    'Técnico de mantenimiento', 'Atiende alertas, calibra sensores y registra mantenimientos.');

-- ----------------------------- PERMISOS ------------------------------
INSERT INTO permisos (id, codigo, modulo, descripcion) VALUES
 (1,  'dashboard.ver',          'Panel',          'Ver el panel de control'),
 (2,  'sectores.ver',           'Sectores',       'Ver estado y detalle de sectores'),
 (3,  'riego.manual',           'Sectores',       'Iniciar y detener riego manual'),
 (4,  'tanque.ver',             'Tanque',         'Ver nivel del tanque en litros'),
 (5,  'tanque.operar',          'Tanque',         'Iniciar/detener llenado manual del tanque'),
 (6,  'clima.ver',              'Clima e IA',     'Ver clima actual y predicción 72 h'),
 (7,  'historial.ver',          'Historial',      'Ver historial de riegos y consumo'),
 (8,  'reportes.exportar',      'Historial',      'Exportar reportes CSV/PDF'),
 (9,  'alertas.ver',            'Alertas',        'Ver alertas del sistema'),
 (10, 'alertas.atender',        'Alertas',        'Marcar alertas como atendidas'),
 (11, 'sensores.ver',           'Sensores',       'Ver nodos, sensores, batería y señal'),
 (12, 'sensores.calibrar',      'Sensores',       'Calibrar sensores'),
 (13, 'mantenimiento.gestionar','Mantenimiento',  'Poner sectores en mantenimiento y registrar trabajos'),
 (14, 'riego.configurar',       'Configuración',  'Configurar umbrales, horarios y probabilidad de lluvia'),
 (15, 'sectores.configurar',    'Configuración',  'Configurar sectores, cultivos, Kc y caudales'),
 (16, 'automatizacion.gestionar','Automatización','Activar/desactivar y parametrizar reglas'),
 (17, 'ia.ver',                 'Clima e IA',     'Ver modelos de IA y sus métricas'),
 (18, 'ia.reentrenar',          'Clima e IA',     'Forzar reentrenamiento de modelos'),
 (19, 'usuarios.gestionar',     'Usuarios',       'Crear, editar y desactivar usuarios'),
 (20, 'auditoria.ver',          'Usuarios',       'Ver la bitácora de auditoría'),
 (21, 'simulacion.fallas',      'Mantenimiento',  'Inyectar fallas de prueba (modo simulación)'),
 (22, 'riego.programar',        'Sectores',       'Programar riegos por litros (una vez o diario)');

-- Administrador: todos los permisos
INSERT INTO rol_permiso (rol_id, permiso_id) SELECT 1, id FROM permisos;
-- Agricultor
INSERT INTO rol_permiso (rol_id, permiso_id) VALUES
 (2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(2,9),(2,14),(2,22);
-- Técnico
INSERT INTO rol_permiso (rol_id, permiso_id) VALUES
 (3,1),(3,2),(3,4),(3,6),(3,9),(3,10),(3,11),(3,12),(3,13),(3,21);

-- ----------------------------- USUARIOS ------------------------------
-- Contraseñas (cámbielas en producción):
--   admin      / Admin2026!
--   agricultor / Agro2026!
--   tecnico    / Tecnico2026!
INSERT INTO usuarios (id, rol_id, usuario, nombre, apellido, correo, telefono, password_hash) VALUES
 (1, 1, 'admin',      'Andrea', 'Rojas',  'admin@riegoyungas.bo',      '70000001', 'scrypt$16384$8$1$gGKWYjUbtUMqt5xUPptr8g==$nbHMKxlL+eCOoqV32JVs7ME5QdFJCSpaLYPJGtFUnw0lfLWCcXaqA+2oPgs4VSGHTAgxlG++/rn1PctqvrHf0g=='),
 (2, 2, 'agricultor', 'Juan',   'Quispe', 'agricultor@riegoyungas.bo', '70000002', 'scrypt$16384$8$1$9dpTVsAqFqGe97rP+oA6hQ==$bfTJCXRm6TzxYWXP/180bjh44mCBSI2r7/4q7dG2n81/Ank2YI/7WU+Vc+xBmrvahTJdMK/ZGbosIEBDrTDJrQ=='),
 (3, 3, 'tecnico',    'Luis',   'Choque', 'tecnico@riegoyungas.bo',    '70000003', 'scrypt$16384$8$1$pGw9TG8Db9noov7cwEbkjA==$3e7bfXmQqaeGL1OM82EmVA3TBhysAFRec+Re5Ekh0teG2Z50biyl6nVjEbU9kE3LYgIc12LQEz/HNNcuvfkhyg==');

-- ------------------------ FINCA, CULTIVOS, SUELO ---------------------
INSERT INTO fincas (id, nombre, municipio, provincia, departamento, latitud, longitud, altitud_m, area_ha) VALUES
 (1, 'Finca de estudio – Coroico', 'Coroico', 'Nor Yungas', 'La Paz', -16.190000, -67.730000, 1700.0, 4.00);

INSERT INTO cultivos (id, nombre, nombre_cientifico, kc_inicial, kc_medio, kc_final, kr, prof_raiz_m, p_agotamiento) VALUES
 (1, 'Café',     'Coffea arabica',     0.90, 0.95, 0.95, 0.70, 0.60, 0.25),
 (2, 'Cítricos', 'Citrus spp.',        0.65, 0.65, 0.65, 0.60, 0.80, 0.30),
 (3, 'Banano',   'Musa × paradisiaca', 0.50, 1.10, 1.10, 0.80, 0.50, 0.20);

INSERT INTO suelos (id, textura, theta_cc, theta_pmp, densidad_aparente) VALUES
 (1, 'Franco', 0.300, 0.150, 1.35);

-- ----------------------------- SECTORES ------------------------------
-- caudal_nominal = n_plantas × goteros × caudal_gotero
-- umbral = θcc − p·(θcc − θpmp)
INSERT INTO sectores (id, finca_id, codigo, nombre, cultivo_id, suelo_id, area_ha, n_plantas, goteros_por_planta, caudal_gotero_lh, caudal_nominal_lh, eficiencia, fraccion_humedecida, umbral_base, umbral_humedad) VALUES
 (1, 1, 'S1', 'Sector 1 – Café',     1, 1, 1.00, 5000, 1, 2.00, 10000.00, 0.90, 0.50, 0.263, 0.263),
 (2, 1, 'S2', 'Sector 2 – Café',     1, 1, 1.00, 5000, 1, 2.00, 10000.00, 0.90, 0.50, 0.263, 0.263),
 (3, 1, 'S3', 'Sector 3 – Cítricos', 2, 1, 1.00,  400, 4, 4.00,  6400.00, 0.90, 0.50, 0.255, 0.255),
 (4, 1, 'S4', 'Sector 4 – Banano',   3, 1, 1.00, 1600, 2, 4.00, 12800.00, 0.90, 0.50, 0.270, 0.270);

-- --------------------- SECTORES A CARGO DEL AGRICULTOR ---------------
INSERT INTO usuario_sector (usuario_id, sector_id) VALUES (2,1),(2,2),(2,3),(2,4);

-- ------------------------------ TANQUE -------------------------------
INSERT INTO tanques (id, finca_id, nombre, capacidad_l, nivel_l, umbral_min_pct, umbral_max_pct, caudal_entrada_ls) VALUES
 (1, 1, 'Tanque principal', 50000.0, 34600.0, 25.00, 95.00, 1.20);

-- ------------------------------- NODOS -------------------------------
INSERT INTO nodos (id, codigo, tipo, sector_id, descripcion, api_key, firmware, bateria_v, rssi_dbm, en_linea) VALUES
 (1, 'N-S1', 'sector',  1,    'Nodo ESP32 + LoRa – Sector 1', 'ec499973e6acfcb570ff6e1f', 'v1.0.3', 12.90, -92, 1),
 (2, 'N-S2', 'sector',  2,    'Nodo ESP32 + LoRa – Sector 2', '6bcc9b2607d20e3f8a4570c4', 'v1.0.3', 12.85, -97, 1),
 (3, 'N-S3', 'sector',  3,    'Nodo ESP32 + LoRa – Sector 3', '8f3978bf8e25123a261244aa', 'v1.0.3', 12.95, -101, 1),
 (4, 'N-S4', 'sector',  4,    'Nodo ESP32 + LoRa – Sector 4', '4faabfddaa7f0937d71f8adc', 'v1.0.3', 12.80, -104, 1),
 (5, 'N-TQ', 'tanque',  NULL, 'Nodo ESP32 + LoRa – Tanque',   '6d0c708cedf6911a6dfa132e', 'v1.0.3', 12.90, -88, 1),
 (6, 'UC-01','central', NULL, 'Unidad central Raspberry Pi 4 + estación meteorológica', '7d6c70756485e3940600fa44', 'v1.2.0', 12.95, 0, 1);

-- ------------------------------ SENSORES -----------------------------
INSERT INTO sensores (nodo_id, tipo, posicion, modelo, unidad, adc_seco, adc_saturado, rango_min, rango_max) VALUES
 (1,'humedad','H1','Capacitivo v1.2','m³/m³',3200,1350,0.05,0.50),(1,'humedad','H2','Capacitivo v1.2','m³/m³',3180,1400,0.05,0.50),(1,'humedad','H3','Capacitivo v1.2','m³/m³',3210,1380,0.05,0.50),
 (1,'temp_suelo','T1','DS18B20','°C',NULL,NULL,-5,50),(1,'caudal','Q1','YF-DN40','L/min',NULL,NULL,0,400),
 (2,'humedad','H1','Capacitivo v1.2','m³/m³',3190,1360,0.05,0.50),(2,'humedad','H2','Capacitivo v1.2','m³/m³',3205,1390,0.05,0.50),(2,'humedad','H3','Capacitivo v1.2','m³/m³',3170,1370,0.05,0.50),
 (2,'temp_suelo','T1','DS18B20','°C',NULL,NULL,-5,50),(2,'caudal','Q1','YF-DN40','L/min',NULL,NULL,0,400),
 (3,'humedad','H1','Capacitivo v1.2','m³/m³',3220,1410,0.05,0.50),(3,'humedad','H2','Capacitivo v1.2','m³/m³',3195,1385,0.05,0.50),(3,'humedad','H3','Capacitivo v1.2','m³/m³',3185,1365,0.05,0.50),
 (3,'temp_suelo','T1','DS18B20','°C',NULL,NULL,-5,50),(3,'caudal','Q1','YF-DN40','L/min',NULL,NULL,0,400),
 (4,'humedad','H1','Capacitivo v1.2','m³/m³',3210,1375,0.05,0.50),(4,'humedad','H2','Capacitivo v1.2','m³/m³',3200,1395,0.05,0.50),(4,'humedad','H3','Capacitivo v1.2','m³/m³',3180,1355,0.05,0.50),
 (4,'temp_suelo','T1','DS18B20','°C',NULL,NULL,-5,50),(4,'caudal','Q1','YF-DN40','L/min',NULL,NULL,0,400),
 (5,'nivel','US1','JSN-SR04T','L',NULL,NULL,0,50000),(5,'caudal','QS','YF-DN50','L/min',NULL,NULL,0,800),
 (6,'temp_aire','BME','BME280','°C',NULL,NULL,-10,45),(6,'hr','BME','BME280','%',NULL,NULL,0,100),(6,'presion','BME','BME280','kPa',NULL,NULL,70,90),
 (6,'viento','ANE','Anemómetro','m/s',NULL,NULL,0,40),(6,'radiacion','PIR','Piranómetro Si','W/m²',NULL,NULL,0,1400),(6,'lluvia','PLU','Pluviómetro balancín','mm',NULL,NULL,0,200);

-- ------------------------------ MOTIVOS ------------------------------
INSERT INTO motivos (id, codigo, decision, descripcion) VALUES
 (1, 'M-01', 'regar',     'Humedad del suelo (θ) bajo el umbral del sector'),
 (2, 'M-02', 'regar',     'Déficit hídrico acumulado por ETc supera la lámina mínima'),
 (3, 'M-03', 'regar',     'La IA prevé que el sector alcanzará el umbral antes del próximo ciclo'),
 (4, 'M-04', 'regar',     'Riego manual iniciado por el usuario'),
 (5, 'M-05', 'no_regar',  'Suelo con humedad suficiente'),
 (6, 'M-06', 'posponer',  'Lluvia prevista suficiente (≥ lámina neta y probabilidad ≥ mínima)'),
 (7, 'M-07', 'esperar',   'Volumen insuficiente en el tanque; llenado en curso'),
 (8, 'M-08', 'suspender', 'Falla detectada (válvula sin caudal, fuga o sensor con error)'),
 (9, 'M-09', 'suspender', 'Lluvia en curso detectada por el pluviómetro'),
 (10, 'M-10', 'regar',    'Riego programado por el usuario (litros definidos)');

-- --------------------------- TIPOS DE ALERTA -------------------------
INSERT INTO tipos_alerta (id, codigo, nombre, severidad, destinatarios) VALUES
 (1,  'A-01', 'Tanque requiere llenado',        'alta',    'agricultor,admin'),
 (2,  'A-02', 'Falla en el llenado',            'critica', 'agricultor,tecnico,admin'),
 (3,  'A-03', 'Falla de válvula / tubería',     'critica', 'agricultor,tecnico,admin'),
 (4,  'A-04', 'Posible fuga',                   'critica', 'agricultor,tecnico,admin'),
 (5,  'A-05', 'Nodo sin comunicación',          'alta',    'agricultor,tecnico,admin'),
 (6,  'A-06', 'Sensor con falla',               'media',   'agricultor,tecnico,admin'),
 (7,  'A-07', 'Batería baja',                   'media',   'agricultor,tecnico,admin'),
 (8,  'A-08', 'Unidad central sin internet',    'alta',    'agricultor,tecnico,admin'),
 (9,  'A-09', 'Consumo anómalo',                'media',   'agricultor,tecnico,admin'),
 (10, 'A-10', 'Lluvia intensa prevista',        'info',    'agricultor,admin'),
 (11, 'A-11', 'Evento de riego',                'info',    'agricultor,admin');

-- ------------------------ REGLAS DE AUTOMATIZACIÓN -------------------
INSERT INTO reglas_automatizacion (codigo, nombre, descripcion, parametro, valor, unidad, activa) VALUES
 ('DISPARO_DEFICIT',  'Disparo por déficit radicular', 'Inicia el riego cuando la humedad promedio del sector cae bajo su umbral (θcc − p·ADT).', 'umbral', NULL, 'm³/m³', 1),
 ('CORTE_LLUVIA',     'Corte automático por pluviometría', 'Suspende o impide el riego si el pluviómetro registra lluvia en la última hora por encima del valor.', 'lluvia_1h', 2.000, 'mm/h', 1),
 ('POSPONER_PRONOST', 'Aplazamiento por pronóstico de lluvia', 'Pospone el riego si la lluvia efectiva prevista en 24 h cubre la lámina neta con probabilidad ≥ valor.', 'prob_lluvia', 60.000, '%', 1),
 ('BLOQUEO_TANQUE',   'Reserva mínima del tanque', 'No inicia riegos si el tanque quedaría por debajo de esta reserva.', 'reserva_pct', 10.000, '%', 1),
 ('LLENADO_AUTO',     'Llenado automático del tanque', 'Abre la válvula de llenado bajo el umbral mínimo y la cierra al umbral máximo.', 'umbral_min', 25.000, '%', 1),
 ('ANTICIPO_IA',      'Riego anticipado por IA', 'En fase de adaptación, riega si la IA predice que el sector cruzará el umbral en las próximas 24 h sin lluvia.', 'margen', 0.005, 'm³/m³', 1),
 ('DETECCION_FUGA',   'Detección de fugas', 'Genera alerta crítica si hay caudal con la válvula cerrada por encima del valor.', 'caudal_max', 2.000, 'L/min', 1);

-- ---------------------------- CONFIGURACIÓN --------------------------
INSERT INTO configuracion (clave, valor, tipo, descripcion, editable_por) VALUES
 ('riego_automatico',         '1',    'booleano', 'Activa o desactiva el riego automático global', 'agricultor'),
 ('evaluacion_continua_min',  '10',   'numero',   'Intervalo de evaluación continua (min reales)', 'admin'),
 ('max_min_riego',            '180',  'numero',   'Duración máxima de un riego (min)', 'agricultor'),
 ('lamina_minima_mm',         '1.0',  'numero',   'Lámina neta mínima para justificar un riego (mm)', 'admin'),
 ('posponer_horas',           '6',    'numero',   'Horas que se pospone un riego por lluvia prevista', 'admin'),
 ('lluvia_intensa_mm',        '30',   'numero',   'Lluvia prevista 24 h que genera alerta A-10 (mm)', 'admin'),
 ('bateria_min_v',            '11.8', 'numero',   'Tensión mínima de batería antes de alertar (V)', 'admin'),
 ('nodo_timeout_min',         '15',   'numero',   'Minutos sin reporte para considerar un nodo fuera de línea', 'admin'),
 ('usar_open_meteo',          '1',    'booleano', 'Fusionar la predicción local con Open-Meteo', 'admin');

INSERT INTO horarios_riego (hora, activo) VALUES ('05:00:00', 1), ('17:00:00', 1);

-- ---------------------------- MODELOS IA -----------------------------
INSERT INTO modelos_ia (tipo, sector_id, algoritmo, version, fase) VALUES
 ('clima', NULL, 'Regresión armónica + persistencia (fusión con Open-Meteo)', 1, 'observacion'),
 ('sector', 1, 'Regresión lineal en línea (SGD)', 1, 'observacion'),
 ('sector', 2, 'Regresión lineal en línea (SGD)', 1, 'observacion'),
 ('sector', 3, 'Regresión lineal en línea (SGD)', 1, 'observacion'),
 ('sector', 4, 'Regresión lineal en línea (SGD)', 1, 'observacion');

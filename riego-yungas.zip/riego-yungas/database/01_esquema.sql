-- =====================================================================
--  SISTEMA DE RIEGO AUTOMATIZADO BASADO EN EVAPOTRANSPIRACIÓN
--  Y PREDICCIÓN CLIMÁTICA  –  Finca de 4 ha, Coroico (Nor Yungas)
--  Script 01: ESQUEMA DE LA BASE DE DATOS (MySQL 8.0 / Workbench)
-- =====================================================================
--  Ejecutar en MySQL Workbench en este orden:
--    01_esquema.sql  ->  02_datos_iniciales.sql  ->  03_vistas_procedimientos.sql
-- =====================================================================

DROP DATABASE IF EXISTS riego_yungas;
CREATE DATABASE riego_yungas CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;
USE riego_yungas;

SET NAMES utf8mb4;
SET time_zone = '-04:00';

-- ---------------------------------------------------------------------
--  MÓDULO 1: SEGURIDAD (roles, permisos, usuarios, auditoría)
-- ---------------------------------------------------------------------
CREATE TABLE roles (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(20) NOT NULL,
  nombre VARCHAR(60) NOT NULL,
  descripcion VARCHAR(255) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_roles_codigo (codigo)
) ENGINE=InnoDB COMMENT='Roles del sistema: admin, agricultor, tecnico';

CREATE TABLE permisos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(50) NOT NULL,
  modulo VARCHAR(40) NOT NULL,
  descripcion VARCHAR(255) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_permisos_codigo (codigo)
) ENGINE=InnoDB COMMENT='Permisos atómicos por funcionalidad';

CREATE TABLE rol_permiso (
  rol_id INT UNSIGNED NOT NULL,
  permiso_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (rol_id, permiso_id),
  CONSTRAINT fk_rp_rol FOREIGN KEY (rol_id) REFERENCES roles (id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_permiso FOREIGN KEY (permiso_id) REFERENCES permisos (id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='Matriz de permisos por rol';

CREATE TABLE usuarios (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  rol_id INT UNSIGNED NOT NULL,
  usuario VARCHAR(40) NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  apellido VARCHAR(80) NOT NULL,
  correo VARCHAR(120) NOT NULL,
  telefono VARCHAR(20) NULL,
  password_hash VARCHAR(255) NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  intentos_fallidos INT NOT NULL DEFAULT 0,
  bloqueado_hasta DATETIME NULL,
  ultimo_acceso DATETIME NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuarios_usuario (usuario),
  UNIQUE KEY uq_usuarios_correo (correo),
  CONSTRAINT fk_usuarios_rol FOREIGN KEY (rol_id) REFERENCES roles (id)
) ENGINE=InnoDB COMMENT='Usuarios con contraseña cifrada (scrypt)';

CREATE TABLE auditoria (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id INT UNSIGNED NULL,
  accion VARCHAR(60) NOT NULL,
  entidad VARCHAR(40) NULL,
  entidad_id VARCHAR(40) NULL,
  detalle VARCHAR(500) NULL,
  ip VARCHAR(45) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_auditoria_fecha (fecha),
  CONSTRAINT fk_auditoria_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='Bitácora de acciones de usuarios';

-- ---------------------------------------------------------------------
--  MÓDULO 2: FINCA, CULTIVOS, SUELOS Y SECTORES
-- ---------------------------------------------------------------------
CREATE TABLE fincas (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  municipio VARCHAR(60) NOT NULL,
  provincia VARCHAR(60) NOT NULL,
  departamento VARCHAR(60) NOT NULL,
  latitud DECIMAL(9,6) NOT NULL,
  longitud DECIMAL(9,6) NOT NULL,
  altitud_m DECIMAL(7,1) NOT NULL,
  area_ha DECIMAL(6,2) NOT NULL,
  zona_horaria VARCHAR(40) NOT NULL DEFAULT 'America/La_Paz',
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE cultivos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(60) NOT NULL,
  nombre_cientifico VARCHAR(80) NULL,
  kc_inicial DECIMAL(4,2) NOT NULL,
  kc_medio DECIMAL(4,2) NOT NULL,
  kc_final DECIMAL(4,2) NOT NULL,
  kr DECIMAL(4,2) NOT NULL COMMENT 'Coeficiente de reducción por cobertura (goteo)',
  prof_raiz_m DECIMAL(4,2) NOT NULL,
  p_agotamiento DECIMAL(4,2) NOT NULL COMMENT 'Fracción de agotamiento permitida',
  PRIMARY KEY (id),
  UNIQUE KEY uq_cultivos_nombre (nombre)
) ENGINE=InnoDB COMMENT='Coeficientes FAO-56 por cultivo';

CREATE TABLE suelos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  textura VARCHAR(40) NOT NULL,
  theta_cc DECIMAL(4,3) NOT NULL COMMENT 'Capacidad de campo (m3/m3)',
  theta_pmp DECIMAL(4,3) NOT NULL COMMENT 'Punto de marchitez permanente (m3/m3)',
  densidad_aparente DECIMAL(4,2) NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE sectores (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  finca_id INT UNSIGNED NOT NULL,
  codigo VARCHAR(10) NOT NULL,
  nombre VARCHAR(60) NOT NULL,
  cultivo_id INT UNSIGNED NOT NULL,
  suelo_id INT UNSIGNED NOT NULL,
  area_ha DECIMAL(5,2) NOT NULL,
  n_plantas INT NOT NULL,
  goteros_por_planta INT NOT NULL,
  caudal_gotero_lh DECIMAL(5,2) NOT NULL,
  caudal_nominal_lh DECIMAL(10,2) NOT NULL,
  eficiencia DECIMAL(4,2) NOT NULL DEFAULT 0.90,
  fraccion_humedecida DECIMAL(4,2) NOT NULL DEFAULT 0.50,
  umbral_base DECIMAL(4,3) NOT NULL COMMENT 'Umbral agronómico calculado',
  umbral_humedad DECIMAL(4,3) NOT NULL COMMENT 'Umbral efectivo (ajustable por IA ±10%)',
  factor_kc_ia DECIMAL(4,3) NOT NULL DEFAULT 1.000,
  modo ENUM('automatico','manual','mantenimiento') NOT NULL DEFAULT 'automatico',
  estado ENUM('reposo','evaluando','regando','pospuesto','esperando_agua','falla','mantenimiento') NOT NULL DEFAULT 'reposo',
  deficit_mm DECIMAL(6,2) NOT NULL DEFAULT 0,
  pospuesto_hasta DATETIME NULL,
  ultimo_riego DATETIME NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sectores_codigo (finca_id, codigo),
  CONSTRAINT fk_sectores_finca FOREIGN KEY (finca_id) REFERENCES fincas (id),
  CONSTRAINT fk_sectores_cultivo FOREIGN KEY (cultivo_id) REFERENCES cultivos (id),
  CONSTRAINT fk_sectores_suelo FOREIGN KEY (suelo_id) REFERENCES suelos (id)
) ENGINE=InnoDB COMMENT='Sectores de riego de 1 ha';

CREATE TABLE usuario_sector (
  usuario_id INT UNSIGNED NOT NULL,
  sector_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (usuario_id, sector_id),
  CONSTRAINT fk_us_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
  CONSTRAINT fk_us_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='Sectores a cargo de cada agricultor (recibe sus alertas)';

-- ---------------------------------------------------------------------
--  MÓDULO 3: DISPOSITIVOS (nodos, sensores, calibraciones)
-- ---------------------------------------------------------------------
CREATE TABLE nodos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(20) NOT NULL,
  tipo ENUM('sector','tanque','central') NOT NULL,
  sector_id INT UNSIGNED NULL,
  descripcion VARCHAR(120) NULL,
  api_key VARCHAR(64) NOT NULL,
  firmware VARCHAR(20) NULL,
  bateria_v DECIMAL(4,2) NULL,
  rssi_dbm INT NULL,
  en_linea TINYINT(1) NOT NULL DEFAULT 0,
  ultima_conexion DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_nodos_codigo (codigo),
  UNIQUE KEY uq_nodos_api_key (api_key),
  CONSTRAINT fk_nodos_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='Nodos ESP32 (LoRa) y unidad central';

CREATE TABLE sensores (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nodo_id INT UNSIGNED NOT NULL,
  tipo ENUM('humedad','temp_suelo','caudal','nivel','temp_aire','hr','presion','viento','radiacion','lluvia') NOT NULL,
  posicion VARCHAR(20) NULL,
  modelo VARCHAR(40) NULL,
  unidad VARCHAR(15) NOT NULL,
  adc_seco INT NULL,
  adc_saturado INT NULL,
  factor_calibracion DECIMAL(8,4) NOT NULL DEFAULT 1.0000,
  rango_min DECIMAL(10,3) NULL,
  rango_max DECIMAL(10,3) NULL,
  ultimo_valor DECIMAL(10,3) NULL,
  estado ENUM('ok','falla','calibrando') NOT NULL DEFAULT 'ok',
  ultima_calibracion DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_sensores_nodo FOREIGN KEY (nodo_id) REFERENCES nodos (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE calibraciones (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sensor_id INT UNSIGNED NOT NULL,
  tecnico_id INT UNSIGNED NULL,
  adc_seco INT NULL,
  adc_saturado INT NULL,
  factor DECIMAL(8,4) NULL,
  observacion VARCHAR(255) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_calib_sensor FOREIGN KEY (sensor_id) REFERENCES sensores (id) ON DELETE CASCADE,
  CONSTRAINT fk_calib_tecnico FOREIGN KEY (tecnico_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  MÓDULO 4: TELEMETRÍA (lecturas de sectores, estación y tanque)
-- ---------------------------------------------------------------------
CREATE TABLE lecturas_sector (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  humedad_prom DECIMAL(5,3) NULL,
  humedad_1 DECIMAL(5,3) NULL,
  humedad_2 DECIMAL(5,3) NULL,
  humedad_3 DECIMAL(5,3) NULL,
  temp_suelo DECIMAL(5,2) NULL,
  caudal_lmin DECIMAL(8,2) NULL,
  bateria_v DECIMAL(4,2) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_ls_sector_fecha (sector_id, fecha),
  CONSTRAINT fk_ls_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='Lecturas de nodos de sector (cada 5 min)';

CREATE TABLE lecturas_estacion (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  temp_c DECIMAL(5,2) NOT NULL,
  hr_pct DECIMAL(5,2) NOT NULL,
  presion_kpa DECIMAL(6,2) NULL,
  viento_ms DECIMAL(5,2) NOT NULL,
  radiacion_wm2 DECIMAL(7,2) NOT NULL,
  lluvia_mm DECIMAL(6,2) NOT NULL DEFAULT 0,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_le_fecha (fecha)
) ENGINE=InnoDB COMMENT='Estación meteorológica (cada 10 min)';

CREATE TABLE clima_diario (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  fecha DATE NOT NULL,
  tmax DECIMAL(5,2) NOT NULL,
  tmin DECIMAL(5,2) NOT NULL,
  hrmax DECIMAL(5,2) NOT NULL,
  hrmin DECIMAL(5,2) NOT NULL,
  viento_ms DECIMAL(5,2) NOT NULL,
  rs_mj DECIMAL(6,2) NOT NULL COMMENT 'Radiación solar MJ/m2·día',
  lluvia_mm DECIMAL(6,2) NOT NULL,
  eto_mm DECIMAL(5,2) NOT NULL COMMENT 'ETo FAO Penman-Monteith',
  PRIMARY KEY (id),
  UNIQUE KEY uq_clima_fecha (fecha)
) ENGINE=InnoDB;

CREATE TABLE tanques (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  finca_id INT UNSIGNED NOT NULL,
  nombre VARCHAR(60) NOT NULL,
  capacidad_l DECIMAL(10,1) NOT NULL,
  nivel_l DECIMAL(10,1) NOT NULL,
  umbral_min_pct DECIMAL(5,2) NOT NULL DEFAULT 25,
  umbral_max_pct DECIMAL(5,2) NOT NULL DEFAULT 95,
  caudal_entrada_ls DECIMAL(5,2) NOT NULL DEFAULT 1.20,
  llenando TINYINT(1) NOT NULL DEFAULT 0,
  llenado_desde DATETIME NULL,
  nivel_inicio_llenado DECIMAL(10,1) NULL,
  actualizado_en DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_tanques_finca FOREIGN KEY (finca_id) REFERENCES fincas (id)
) ENGINE=InnoDB;

CREATE TABLE lecturas_tanque (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tanque_id INT UNSIGNED NOT NULL,
  nivel_l DECIMAL(10,1) NOT NULL,
  porcentaje DECIMAL(5,2) NOT NULL,
  caudal_salida_lmin DECIMAL(8,2) NOT NULL DEFAULT 0,
  llenando TINYINT(1) NOT NULL DEFAULT 0,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_lt_fecha (tanque_id, fecha),
  CONSTRAINT fk_lt_tanque FOREIGN KEY (tanque_id) REFERENCES tanques (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  MÓDULO 5: RIEGO Y DECISIONES
-- ---------------------------------------------------------------------
CREATE TABLE motivos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(6) NOT NULL,
  decision ENUM('regar','no_regar','posponer','esperar','suspender') NOT NULL,
  descripcion VARCHAR(200) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_motivos_codigo (codigo)
) ENGINE=InnoDB COMMENT='Catálogo M-01..M-09 del marco práctico';

CREATE TABLE riegos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  usuario_id INT UNSIGNED NULL,
  tipo ENUM('automatico','manual','programado') NOT NULL,
  programado_id INT UNSIGNED NULL,
  motivo_id INT UNSIGNED NOT NULL,
  lamina_mm DECIMAL(6,2) NULL,
  litros_plan DECIMAL(10,1) NOT NULL,
  litros_reales DECIMAL(10,1) NOT NULL DEFAULT 0,
  caudal_prom_lmin DECIMAL(8,2) NULL,
  duracion_plan_min DECIMAL(7,1) NOT NULL,
  inicio DATETIME NOT NULL,
  fin DATETIME NULL,
  estado ENUM('en_curso','completado','cancelado','fallido') NOT NULL DEFAULT 'en_curso',
  PRIMARY KEY (id),
  KEY idx_riegos_sector_inicio (sector_id, inicio),
  CONSTRAINT fk_riegos_sector FOREIGN KEY (sector_id) REFERENCES sectores (id),
  CONSTRAINT fk_riegos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL,
  CONSTRAINT fk_riegos_motivo FOREIGN KEY (motivo_id) REFERENCES motivos (id)
) ENGINE=InnoDB;

CREATE TABLE riegos_programados (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  usuario_id INT UNSIGNED NULL,
  litros DECIMAL(10,1) NOT NULL,
  hora TIME NOT NULL,
  proxima_ejecucion DATETIME NOT NULL,
  repetir ENUM('una_vez','diario') NOT NULL DEFAULT 'una_vez',
  activo TINYINT(1) NOT NULL DEFAULT 1,
  nota VARCHAR(200) NULL,
  ultima_ejecucion DATETIME NULL,
  creado_en DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_prog_proxima (activo, proxima_ejecucion),
  CONSTRAINT fk_prog_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE,
  CONSTRAINT fk_prog_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='Riegos manuales programados por litros (una vez o diario)';

CREATE TABLE decisiones (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  motivo_id INT UNSIGNED NOT NULL,
  decision ENUM('regar','no_regar','posponer','esperar','suspender') NOT NULL,
  humedad DECIMAL(5,3) NULL,
  umbral DECIMAL(5,3) NULL,
  eto_mm DECIMAL(5,2) NULL,
  etc_loc_mm DECIMAL(5,2) NULL,
  deficit_mm DECIMAL(6,2) NULL,
  lluvia_prevista_mm DECIMAL(6,2) NULL,
  prob_lluvia DECIMAL(5,2) NULL,
  humedad_pred_24h DECIMAL(5,3) NULL,
  detalle VARCHAR(300) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_decisiones_fecha (sector_id, fecha),
  CONSTRAINT fk_dec_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE,
  CONSTRAINT fk_dec_motivo FOREIGN KEY (motivo_id) REFERENCES motivos (id)
) ENGINE=InnoDB COMMENT='Trazabilidad de cada decisión del motor';

CREATE TABLE comandos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nodo_id INT UNSIGNED NOT NULL,
  usuario_id INT UNSIGNED NULL,
  accion ENUM('abrir','cerrar','llenar','detener_llenado','reiniciar') NOT NULL,
  litros DECIMAL(10,1) NULL,
  minutos INT NULL,
  estado ENUM('pendiente','enviado','ejecutado','rechazado') NOT NULL DEFAULT 'pendiente',
  creado_en DATETIME NOT NULL,
  ejecutado_en DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_comandos_nodo (nodo_id, estado),
  CONSTRAINT fk_cmd_nodo FOREIGN KEY (nodo_id) REFERENCES nodos (id) ON DELETE CASCADE,
  CONSTRAINT fk_cmd_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='Órdenes enviadas a los nodos';

CREATE TABLE horarios_riego (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  hora TIME NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE reglas_automatizacion (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(30) NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(300) NOT NULL,
  parametro VARCHAR(40) NULL,
  valor DECIMAL(10,3) NULL,
  unidad VARCHAR(15) NULL,
  activa TINYINT(1) NOT NULL DEFAULT 1,
  actualizado_en DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_reglas_codigo (codigo)
) ENGINE=InnoDB COMMENT='Reglas de disparo/corte del motor de decisión';

CREATE TABLE configuracion (
  clave VARCHAR(50) NOT NULL,
  valor VARCHAR(100) NOT NULL,
  tipo ENUM('numero','booleano','texto') NOT NULL DEFAULT 'numero',
  descripcion VARCHAR(200) NULL,
  editable_por ENUM('admin','agricultor') NOT NULL DEFAULT 'admin',
  PRIMARY KEY (clave)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  MÓDULO 6: INTELIGENCIA ARTIFICIAL
-- ---------------------------------------------------------------------
CREATE TABLE modelos_ia (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  tipo ENUM('clima','sector') NOT NULL,
  sector_id INT UNSIGNED NULL,
  algoritmo VARCHAR(60) NOT NULL,
  version INT NOT NULL DEFAULT 1,
  fase ENUM('observacion','recomendacion','adaptacion') NOT NULL DEFAULT 'observacion',
  n_muestras INT NOT NULL DEFAULT 0,
  mae DECIMAL(8,4) NULL,
  rmse DECIMAL(8,4) NULL,
  parametros TEXT NULL COMMENT 'Pesos del modelo serializados (JSON)',
  activo TINYINT(1) NOT NULL DEFAULT 1,
  entrenado_en DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_modelos_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE muestras_ia (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  humedad DECIMAL(5,3) NOT NULL,
  etc_loc_mm DECIMAL(5,2) NOT NULL,
  temp_suelo DECIMAL(5,2) NULL,
  lluvia_prev_mm DECIMAL(6,2) NULL,
  horas_desde_riego DECIMAL(7,1) NULL,
  humedad_objetivo DECIMAL(5,3) NULL COMMENT 'Humedad real observada 24 h después',
  fecha DATETIME NOT NULL,
  fecha_objetivo DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_muestras_pend (sector_id, fecha_objetivo),
  CONSTRAINT fk_muestras_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='Datos de entrenamiento del aprendizaje por sector';

CREATE TABLE predicciones (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  generado_en DATETIME NOT NULL,
  horizonte_h INT NOT NULL,
  fecha_objetivo DATETIME NOT NULL,
  temp_c DECIMAL(5,2) NULL,
  hr_pct DECIMAL(5,2) NULL,
  lluvia_mm DECIMAL(6,2) NULL,
  prob_lluvia DECIMAL(5,2) NULL,
  eto_mm DECIMAL(5,2) NULL,
  fuente ENUM('local','open_meteo','fusion') NOT NULL,
  PRIMARY KEY (id),
  KEY idx_pred_generado (generado_en)
) ENGINE=InnoDB COMMENT='Predicción climática horaria 72 h';

-- ---------------------------------------------------------------------
--  MÓDULO 7: ALERTAS, NOTIFICACIONES Y MANTENIMIENTO
-- ---------------------------------------------------------------------
CREATE TABLE tipos_alerta (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(6) NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  severidad ENUM('critica','alta','media','info') NOT NULL,
  destinatarios VARCHAR(60) NOT NULL COMMENT 'Roles separados por coma',
  PRIMARY KEY (id),
  UNIQUE KEY uq_tipos_alerta_codigo (codigo)
) ENGINE=InnoDB COMMENT='Catálogo A-01..A-11';

CREATE TABLE alertas (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  tipo_alerta_id INT UNSIGNED NOT NULL,
  sector_id INT UNSIGNED NULL,
  nodo_id INT UNSIGNED NULL,
  mensaje VARCHAR(300) NOT NULL,
  atendida TINYINT(1) NOT NULL DEFAULT 0,
  atendida_por INT UNSIGNED NULL,
  atendida_en DATETIME NULL,
  nota_atencion VARCHAR(300) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_alertas_estado (atendida, fecha),
  CONSTRAINT fk_alertas_tipo FOREIGN KEY (tipo_alerta_id) REFERENCES tipos_alerta (id),
  CONSTRAINT fk_alertas_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE SET NULL,
  CONSTRAINT fk_alertas_nodo FOREIGN KEY (nodo_id) REFERENCES nodos (id) ON DELETE SET NULL,
  CONSTRAINT fk_alertas_usuario FOREIGN KEY (atendida_por) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE notificaciones (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id INT UNSIGNED NOT NULL,
  titulo VARCHAR(100) NOT NULL,
  mensaje VARCHAR(300) NOT NULL,
  nivel ENUM('critica','alta','media','info') NOT NULL DEFAULT 'info',
  leida TINYINT(1) NOT NULL DEFAULT 0,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_notif_usuario (usuario_id, leida),
  CONSTRAINT fk_notif_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='Notificaciones push por usuario';

CREATE TABLE mantenimientos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nodo_id INT UNSIGNED NULL,
  sector_id INT UNSIGNED NULL,
  tecnico_id INT UNSIGNED NULL,
  tipo ENUM('preventivo','correctivo','calibracion') NOT NULL,
  descripcion VARCHAR(400) NOT NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_mant_nodo FOREIGN KEY (nodo_id) REFERENCES nodos (id) ON DELETE SET NULL,
  CONSTRAINT fk_mant_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE SET NULL,
  CONSTRAINT fk_mant_tecnico FOREIGN KEY (tecnico_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
--  Script 03: VISTAS, PROCEDIMIENTOS ALMACENADOS, TRIGGERS Y EVENTOS
-- =====================================================================
USE riego_yungas;

-- ------------------------------ VISTAS -------------------------------
CREATE OR REPLACE VIEW v_estado_sectores AS
SELECT s.id, s.codigo, s.nombre, c.nombre AS cultivo, s.area_ha, s.modo, s.estado,
       s.umbral_humedad, s.deficit_mm, s.caudal_nominal_lh,
       (SELECT ls.humedad_prom FROM lecturas_sector ls
         WHERE ls.sector_id = s.id ORDER BY ls.fecha DESC LIMIT 1) AS humedad_actual,
       (SELECT ls.fecha FROM lecturas_sector ls
         WHERE ls.sector_id = s.id ORDER BY ls.fecha DESC LIMIT 1) AS ultima_lectura,
       n.bateria_v, n.rssi_dbm, n.en_linea
FROM sectores s
JOIN cultivos c ON c.id = s.cultivo_id
LEFT JOIN nodos n ON n.sector_id = s.id AND n.tipo = 'sector'
WHERE s.activo = 1;

CREATE OR REPLACE VIEW v_consumo_diario_sector AS
SELECT DATE(r.inicio) AS fecha, s.codigo, c.nombre AS cultivo,
       COUNT(*) AS n_riegos,
       ROUND(SUM(r.litros_reales), 1) AS litros,
       ROUND(SUM(TIMESTAMPDIFF(SECOND, r.inicio, COALESCE(r.fin, r.inicio))) / 60, 1) AS minutos
FROM riegos r
JOIN sectores s ON s.id = r.sector_id
JOIN cultivos c ON c.id = s.cultivo_id
WHERE r.estado IN ('completado', 'cancelado')
GROUP BY DATE(r.inicio), s.codigo, c.nombre;

CREATE OR REPLACE VIEW v_alertas_activas AS
SELECT a.id, t.codigo, t.nombre, t.severidad, a.mensaje, s.codigo AS sector, n.codigo AS nodo, a.fecha
FROM alertas a
JOIN tipos_alerta t ON t.id = a.tipo_alerta_id
LEFT JOIN sectores s ON s.id = a.sector_id
LEFT JOIN nodos n ON n.id = a.nodo_id
WHERE a.atendida = 0
ORDER BY FIELD(t.severidad, 'critica', 'alta', 'media', 'info'), a.fecha DESC;

CREATE OR REPLACE VIEW v_fallas_activas AS
SELECT a.id, t.codigo, t.nombre, t.severidad, a.mensaje, s.codigo AS sector, n.codigo AS nodo, a.fecha,
       (SELECT GROUP_CONCAT(CONCAT(u.nombre, ' ', u.apellido) SEPARATOR ', ')
          FROM usuario_sector us JOIN usuarios u ON u.id = us.usuario_id
         WHERE us.sector_id = a.sector_id) AS agricultores_a_cargo
FROM alertas a
JOIN tipos_alerta t ON t.id = a.tipo_alerta_id
LEFT JOIN sectores s ON s.id = a.sector_id
LEFT JOIN nodos n ON n.id = a.nodo_id
WHERE a.atendida = 0 AND t.codigo IN ('A-02','A-03','A-04','A-05','A-06','A-07','A-08');

CREATE OR REPLACE VIEW v_riegos_programados AS
SELECT p.id, s.codigo AS sector, p.litros, ROUND(p.litros / s.caudal_nominal_lh * 60, 1) AS minutos_estimados,
       p.hora, p.repetir, p.proxima_ejecucion, p.activo, CONCAT(u.nombre, ' ', u.apellido) AS creado_por
FROM riegos_programados p JOIN sectores s ON s.id = p.sector_id LEFT JOIN usuarios u ON u.id = p.usuario_id;

CREATE OR REPLACE VIEW v_permisos_usuario AS
SELECT u.id AS usuario_id, u.usuario, r.codigo AS rol, p.codigo AS permiso
FROM usuarios u
JOIN roles r ON r.id = u.rol_id
JOIN rol_permiso rp ON rp.rol_id = r.id
JOIN permisos p ON p.id = rp.permiso_id
WHERE u.activo = 1;

CREATE OR REPLACE VIEW v_resumen_tanque AS
SELECT t.id, t.nombre, t.capacidad_l, t.nivel_l,
       ROUND(t.nivel_l / t.capacidad_l * 100, 1) AS porcentaje,
       t.umbral_min_pct, t.umbral_max_pct, t.llenando, t.actualizado_en,
       CASE WHEN t.nivel_l / t.capacidad_l * 100 < t.umbral_min_pct THEN 'REQUIERE LLENADO'
            WHEN t.llenando = 1 THEN 'LLENANDO'
            ELSE 'NORMAL' END AS situacion
FROM tanques t;

-- ------------------------ PROCEDIMIENTOS -----------------------------
DROP PROCEDURE IF EXISTS sp_consumo_por_sector;
DELIMITER $$
CREATE PROCEDURE sp_consumo_por_sector(IN p_desde DATE, IN p_hasta DATE)
BEGIN
  SELECT s.codigo, c.nombre AS cultivo,
         COUNT(r.id) AS n_riegos,
         COALESCE(ROUND(SUM(r.litros_reales), 1), 0) AS litros,
         COALESCE(ROUND(SUM(r.litros_reales) / (s.area_ha * 10000), 2), 0) AS lamina_mm
  FROM sectores s
  JOIN cultivos c ON c.id = s.cultivo_id
  LEFT JOIN riegos r ON r.sector_id = s.id
       AND DATE(r.inicio) BETWEEN p_desde AND p_hasta
       AND r.estado IN ('completado', 'cancelado')
  GROUP BY s.id, s.codigo, c.nombre, s.area_ha
  ORDER BY s.codigo;
END $$

DROP PROCEDURE IF EXISTS sp_registrar_lectura_sector $$
CREATE PROCEDURE sp_registrar_lectura_sector(
  IN p_sector INT, IN p_h1 DECIMAL(5,3), IN p_h2 DECIMAL(5,3), IN p_h3 DECIMAL(5,3),
  IN p_temp DECIMAL(5,2), IN p_caudal DECIMAL(8,2), IN p_bat DECIMAL(4,2))
BEGIN
  INSERT INTO lecturas_sector (sector_id, humedad_prom, humedad_1, humedad_2, humedad_3, temp_suelo, caudal_lmin, bateria_v, fecha)
  VALUES (p_sector, ROUND((p_h1 + p_h2 + p_h3) / 3, 3), p_h1, p_h2, p_h3, p_temp, p_caudal, p_bat, NOW());
  UPDATE nodos SET bateria_v = p_bat, en_linea = 1, ultima_conexion = NOW()
   WHERE sector_id = p_sector AND tipo = 'sector';
END $$

DROP PROCEDURE IF EXISTS sp_eto_rango $$
CREATE PROCEDURE sp_eto_rango(IN p_desde DATE, IN p_hasta DATE)
BEGIN
  SELECT fecha, tmax, tmin, rs_mj, lluvia_mm, eto_mm
  FROM clima_diario WHERE fecha BETWEEN p_desde AND p_hasta ORDER BY fecha;
END $$
DELIMITER ;

-- ------------------------------ TRIGGERS -----------------------------
DROP TRIGGER IF EXISTS trg_sectores_bi;
DROP TRIGGER IF EXISTS trg_sectores_bu;
DROP TRIGGER IF EXISTS trg_usuarios_au;
DELIMITER $$
-- Calcula automáticamente el caudal nominal del sector
CREATE TRIGGER trg_sectores_bi BEFORE INSERT ON sectores FOR EACH ROW
BEGIN
  SET NEW.caudal_nominal_lh = NEW.n_plantas * NEW.goteros_por_planta * NEW.caudal_gotero_lh;
END $$
CREATE TRIGGER trg_sectores_bu BEFORE UPDATE ON sectores FOR EACH ROW
BEGIN
  SET NEW.caudal_nominal_lh = NEW.n_plantas * NEW.goteros_por_planta * NEW.caudal_gotero_lh;
END $$
-- Audita cambios de rol o de estado de los usuarios
CREATE TRIGGER trg_usuarios_au AFTER UPDATE ON usuarios FOR EACH ROW
BEGIN
  IF OLD.rol_id <> NEW.rol_id OR OLD.activo <> NEW.activo THEN
    INSERT INTO auditoria (usuario_id, accion, entidad, entidad_id, detalle, fecha)
    VALUES (NULL, 'TRIGGER_CAMBIO_USUARIO', 'usuarios', NEW.id,
            CONCAT('rol ', OLD.rol_id, '→', NEW.rol_id, ', activo ', OLD.activo, '→', NEW.activo), NOW());
  END IF;
END $$
DELIMITER ;

-- ------------------------------ EVENTOS ------------------------------
-- Depuración automática de telemetría antigua (requiere event_scheduler=ON)
SET GLOBAL event_scheduler = ON;
DROP EVENT IF EXISTS ev_depurar_telemetria;
DELIMITER $$
CREATE EVENT ev_depurar_telemetria
  ON SCHEDULE EVERY 1 DAY STARTS (CURRENT_DATE + INTERVAL 1 DAY + INTERVAL 3 HOUR)
  DO
    BEGIN
      DELETE FROM lecturas_sector   WHERE fecha < NOW() - INTERVAL 180 DAY;
      DELETE FROM lecturas_estacion WHERE fecha < NOW() - INTERVAL 365 DAY;
      DELETE FROM lecturas_tanque   WHERE fecha < NOW() - INTERVAL 180 DAY;
      DELETE FROM predicciones      WHERE generado_en < NOW() - INTERVAL 30 DAY;
    END $$
DELIMITER ;

-- ------------------------- USUARIO DE LA APP -------------------------
-- Usuario MySQL con privilegios mínimos para el backend
DROP USER IF EXISTS 'riego_app'@'localhost';
CREATE USER 'riego_app'@'localhost' IDENTIFIED BY 'RiegoApp2026!';
GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE ON riego_yungas.* TO 'riego_app'@'localhost';
FLUSH PRIVILEGES;

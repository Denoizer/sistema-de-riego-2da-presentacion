-- =====================================================================
--  Script 04: ACTUALIZACIÓN v1 -> v2 (sin borrar los datos existentes)
--  Úselo solo si ya tenía la base v1 creada. Si va a instalar desde cero,
--  ejecute riego_yungas.sql (ya incluye estos cambios).
-- =====================================================================
USE riego_yungas;

-- 1) Sectores a cargo de cada agricultor
CREATE TABLE IF NOT EXISTS usuario_sector (
  usuario_id INT UNSIGNED NOT NULL,
  sector_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (usuario_id, sector_id),
  CONSTRAINT fk_us_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
  CONSTRAINT fk_us_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE
) ENGINE=InnoDB;
INSERT IGNORE INTO usuario_sector (usuario_id, sector_id)
  SELECT u.id, s.id FROM usuarios u JOIN roles r ON r.id = u.rol_id CROSS JOIN sectores s WHERE r.codigo = 'agricultor';

-- 2) Riegos programados por litros
CREATE TABLE IF NOT EXISTS riegos_programados (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sector_id INT UNSIGNED NOT NULL,
  usuario_id INT UNSIGNED NULL,
  litros DECIMAL(10,1) NOT NULL,
  hora TIME NOT NULL,
  proxima_ejecucion DATETIME NOT NULL,
  repetir ENUM('una_vez','diario') NOT NULL DEFAULT 'una_vez',
  activo TINYINT(1) NOT NULL DEFAULT 1,
  nota VARCHAR(200) NULL,
  ultima_ejecucion DATETIME NULL,
  creado_en DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_prog_proxima (activo, proxima_ejecucion),
  CONSTRAINT fk_prog_sector FOREIGN KEY (sector_id) REFERENCES sectores (id) ON DELETE CASCADE,
  CONSTRAINT fk_prog_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;

ALTER TABLE riegos MODIFY tipo ENUM('automatico','manual','programado') NOT NULL;
ALTER TABLE riegos ADD COLUMN programado_id INT UNSIGNED NULL AFTER tipo;

-- 3) Nuevo motivo y permiso
INSERT IGNORE INTO motivos (id, codigo, decision, descripcion) VALUES (10, 'M-10', 'regar', 'Riego programado por el usuario (litros definidos)');
INSERT IGNORE INTO permisos (id, codigo, modulo, descripcion) VALUES (22, 'riego.programar', 'Sectores', 'Programar riegos por litros (una vez o diario)');
INSERT IGNORE INTO rol_permiso (rol_id, permiso_id) VALUES (1, 22), (2, 22);

-- 4) Las fallas también se notifican al agricultor a cargo del sector
UPDATE tipos_alerta SET destinatarios = 'agricultor,tecnico,admin' WHERE codigo IN ('A-02','A-03','A-04','A-05','A-06','A-07','A-08','A-09');

-- 5) Vistas nuevas
CREATE OR REPLACE VIEW v_fallas_activas AS
SELECT a.id, t.codigo, t.nombre, t.severidad, a.mensaje, s.codigo AS sector, n.codigo AS nodo, a.fecha,
       (SELECT GROUP_CONCAT(CONCAT(u.nombre, ' ', u.apellido) SEPARATOR ', ')
          FROM usuario_sector us JOIN usuarios u ON u.id = us.usuario_id
         WHERE us.sector_id = a.sector_id) AS agricultores_a_cargo
FROM alertas a
JOIN tipos_alerta t ON t.id = a.tipo_alerta_id
LEFT JOIN sectores s ON s.id = a.sector_id
LEFT JOIN nodos n ON n.id = a.nodo_id
WHERE a.atendida = 0 AND t.codigo IN ('A-02','A-03','A-04','A-05','A-06','A-07','A-08');

CREATE OR REPLACE VIEW v_riegos_programados AS
SELECT p.id, s.codigo AS sector, p.litros, ROUND(p.litros / s.caudal_nominal_lh * 60, 1) AS minutos_estimados,
       p.hora, p.repetir, p.proxima_ejecucion, p.activo, CONCAT(u.nombre, ' ', u.apellido) AS creado_por
FROM riegos_programados p JOIN sectores s ON s.id = p.sector_id LEFT JOIN usuarios u ON u.id = p.usuario_id;

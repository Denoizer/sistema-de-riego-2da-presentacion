/*
 *  NODO DE TANQUE – ESP32
 *  Sensor ultrasónico JSN-SR04T (nivel), caudalímetro de salida y válvula de llenado.
 *  POST /api/iot/lecturas {nivel_l, caudal_salida}  ·  GET /api/iot/comandos (llenar / detener_llenado)
 */
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

const char* WIFI_SSID = "MI_WIFI";
const char* WIFI_CLAVE = "MI_CLAVE";
const char* SERVIDOR = "http://192.168.1.50:3000";
const char* API_KEY = "6d0c708cedf6911a6dfa132e";   // nodos.api_key (N-TQ)

#define PIN_TRIG 5
#define PIN_ECHO 18
#define PIN_FLOW 27
#define PIN_RELE 26           // válvula de llenado (vertiente)

// Geometría del tanque (cilíndrico vertical)
const float CAPACIDAD_L = 50000.0;
const float ALTURA_UTIL_M = 2.50;       // altura del agua al 100 %
const float DIST_SENSOR_LLENO_M = 0.30; // distancia sensor–espejo con el tanque lleno
const float LITROS_POR_PULSO = 0.90;

volatile uint32_t pulsos = 0;
void IRAM_ATTR isrFlujo() { pulsos++; }
uint32_t tLectura = 0, tComandos = 0, tCaudal = 0, pCaudal = 0;
float caudal = 0;

float distanciaM() {
  float suma = 0; int n = 0;
  for (int i = 0; i < 5; i++) {
    digitalWrite(PIN_TRIG, LOW); delayMicroseconds(2);
    digitalWrite(PIN_TRIG, HIGH); delayMicroseconds(10); digitalWrite(PIN_TRIG, LOW);
    long us = pulseIn(PIN_ECHO, HIGH, 30000);
    if (us > 0) { suma += us * 0.000343 / 2.0; n++; }
    delay(60);
  }
  return n ? suma / n : -1;
}

float nivelLitros() {
  float d = distanciaM();
  if (d < 0) return -1;
  float altura = constrain(ALTURA_UTIL_M - (d - DIST_SENSOR_LLENO_M), 0, ALTURA_UTIL_M);
  return altura / ALTURA_UTIL_M * CAPACIDAD_L;
}

int post(String ruta, String json) {
  HTTPClient http; http.begin(String(SERVIDOR) + ruta);
  http.addHeader("Content-Type", "application/json"); http.addHeader("X-Api-Key", API_KEY);
  int c = http.POST(json); http.end(); return c;
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_TRIG, OUTPUT); pinMode(PIN_ECHO, INPUT); pinMode(PIN_RELE, OUTPUT); digitalWrite(PIN_RELE, LOW);
  pinMode(PIN_FLOW, INPUT_PULLUP); attachInterrupt(digitalPinToInterrupt(PIN_FLOW), isrFlujo, FALLING);
  WiFi.begin(WIFI_SSID, WIFI_CLAVE);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
}

void loop() {
  uint32_t ahora = millis();
  if (ahora - tCaudal >= 1000) { caudal = (pulsos - pCaudal) * LITROS_POR_PULSO * 60000.0 / (ahora - tCaudal); pCaudal = pulsos; tCaudal = ahora; }
  if (ahora - tLectura >= 60000) {
    tLectura = ahora;
    float l = nivelLitros();
    if (l >= 0) { JsonDocument d; d["nivel_l"] = l; d["caudal_salida"] = caudal; String s; serializeJson(d, s); post("/api/iot/lecturas", s); }
  }
  if (ahora - tComandos >= 10000) {
    tComandos = ahora;
    HTTPClient http; http.begin(String(SERVIDOR) + "/api/iot/comandos"); http.addHeader("X-Api-Key", API_KEY);
    if (http.GET() == 200) {
      JsonDocument d; deserializeJson(d, http.getString());
      for (JsonObject c : d.as<JsonArray>()) {
        if (strcmp(c["accion"], "llenar") == 0) digitalWrite(PIN_RELE, HIGH);
        if (strcmp(c["accion"], "detener_llenado") == 0) digitalWrite(PIN_RELE, LOW);
        post(String("/api/iot/comandos/") + int(c["id"]) + "/ack", "{}");
      }
    }
    http.end();
  }
}

/*
 * ===================================================================
 *  NODO DE SECTOR – ESP32 (Sistema de riego automatizado – Yungas)
 * ===================================================================
 *  - Lee 3 sensores capacitivos de humedad, 1 DS18B20 y un caudalímetro.
 *  - Envía lecturas a la API:  POST /api/iot/lecturas   (cabecera X-Api-Key)
 *  - Consulta órdenes:        GET  /api/iot/comandos
 *  - Abre/cierra la electroválvula latch y reporta FIN_RIEGO / SIN_CAUDAL.
 *
 *  Versión Wi-Fi (prototipo). En la finca, la misma lógica se transporta
 *  por LoRa hasta la unidad central, que reenvía a la API (ver README).
 *
 *  Librerías (Arduino IDE / PlatformIO):
 *    OneWire, DallasTemperature, ArduinoJson (v7)
 *  Placa: "ESP32 Dev Module"
 * ===================================================================
 */
#include <WiFi.h>
#include <HTTPClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ArduinoJson.h>

// ---------------- CONFIGURACIÓN ----------------
const char* WIFI_SSID   = "MI_WIFI";
const char* WIFI_CLAVE  = "MI_CLAVE";
const char* SERVIDOR    = "http://192.168.1.50:3000";      // IP de la PC con el backend
const char* API_KEY     = "ec499973e6acfcb570ff6e1f";       // nodos.api_key (N-S1)
const uint32_t PERIODO_LECTURA_MS = 5UL * 60UL * 1000UL;    // 5 minutos
const uint32_t PERIODO_COMANDOS_MS = 10UL * 1000UL;         // 10 s

// Pines (ver tabla 3.13.1 del marco práctico)
#define PIN_H1   32
#define PIN_H2   33
#define PIN_H3   34
#define PIN_DS   4
#define PIN_FLOW 27
#define PIN_BAT  35
#define PIN_IN1  25
#define PIN_IN2  13

// Calibración (actualizable desde la app → sensores.adc_seco / adc_saturado)
int ADC_SECO[3] = {3200, 3180, 3210};
int ADC_SAT[3]  = {1350, 1400, 1380};
const float THETA_MIN = 0.075, THETA_MAX = 0.45;  // rango físico m3/m3
const float LITROS_POR_PULSO = 0.45;              // calibrado por aforo

OneWire ow(PIN_DS);
DallasTemperature ds(&ow);
volatile uint32_t pulsos = 0;
void IRAM_ATTR isrFlujo() { pulsos++; }

bool valvulaAbierta = false;
float litrosObjetivo = 0;
uint32_t inicioRiego = 0, maxMsRiego = 0, ultimoPulsoMs = 0, pulsosPrevios = 0;
uint32_t tLectura = 0, tComandos = 0;

float leerHumedad(int pin, int i) {
  long s = 0;
  for (int k = 0; k < 20; k++) { s += analogRead(pin); delay(5); }
  float adc = s / 20.0;
  float rel = constrain((ADC_SECO[i] - adc) / float(ADC_SECO[i] - ADC_SAT[i]), 0.0, 1.0);
  return THETA_MIN + rel * (THETA_MAX - THETA_MIN);
}

float leerBateria() { return analogRead(PIN_BAT) * 3.3 / 4095.0 * (127.0 / 27.0); }

void pulsoValvula(bool abrir) {               // válvula latch: pulso de 50 ms
  digitalWrite(abrir ? PIN_IN1 : PIN_IN2, HIGH);
  delay(50);
  digitalWrite(PIN_IN1, LOW); digitalWrite(PIN_IN2, LOW);
  valvulaAbierta = abrir;
}

float litrosRiego() { return (pulsos) * LITROS_POR_PULSO; }

float caudalLmin() {                           // caudal instantáneo en ventana de 1 s
  static uint32_t t0 = 0, p0 = 0; static float q = 0;
  uint32_t ahora = millis();
  if (ahora - t0 >= 1000) { q = (pulsos - p0) * LITROS_POR_PULSO * 60000.0 / (ahora - t0); t0 = ahora; p0 = pulsos; }
  return q;
}

int post(const char* ruta, const String& json) {
  if (WiFi.status() != WL_CONNECTED) return -1;
  HTTPClient http;
  http.begin(String(SERVIDOR) + ruta);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Api-Key", API_KEY);
  int code = http.POST(json);
  http.end();
  return code;
}

void enviarLecturas() {
  JsonDocument d;
  JsonArray h = d["h"].to<JsonArray>();
  h.add(leerHumedad(PIN_H1, 0)); h.add(leerHumedad(PIN_H2, 1)); h.add(leerHumedad(PIN_H3, 2));
  ds.requestTemperatures();
  d["temp"] = ds.getTempCByIndex(0);
  d["caudal"] = caudalLmin();
  d["litros"] = valvulaAbierta ? litrosRiego() : 0;
  d["bateria"] = leerBateria();
  d["rssi"] = WiFi.RSSI();
  String s; serializeJson(d, s);
  int c = post("/api/iot/lecturas", s);
  Serial.printf("[lectura] %s -> %d\n", s.c_str(), c);
}

void enviarEvento(const char* tipo, float litros) {
  JsonDocument d; d["tipo"] = tipo; d["litros"] = litros;
  String s; serializeJson(d, s);
  post("/api/iot/eventos", s);
}

void consultarComandos() {
  if (WiFi.status() != WL_CONNECTED) return;
  HTTPClient http;
  http.begin(String(SERVIDOR) + "/api/iot/comandos");
  http.addHeader("X-Api-Key", API_KEY);
  if (http.GET() == 200) {
    JsonDocument d; deserializeJson(d, http.getString());
    for (JsonObject c : d.as<JsonArray>()) {
      const char* accion = c["accion"];
      if (strcmp(accion, "abrir") == 0) {
        pulsos = 0; litrosObjetivo = c["litros"] | 0.0f;
        maxMsRiego = (c["minutos"] | 180) * 60000UL; inicioRiego = millis(); ultimoPulsoMs = millis(); pulsosPrevios = 0;
        pulsoValvula(true);
      } else if (strcmp(accion, "cerrar") == 0) {
        pulsoValvula(false);
      }
      post((String("/api/iot/comandos/") + int(c["id"]) + "/ack").c_str(), "{}");
    }
  }
  http.end();
}

void controlarRiego() {
  if (!valvulaAbierta) return;
  if (pulsos != pulsosPrevios) { pulsosPrevios = pulsos; ultimoPulsoMs = millis(); }
  if (millis() - ultimoPulsoMs > 60000UL) {           // 60 s sin caudal -> falla
    pulsoValvula(false); enviarEvento("SIN_CAUDAL", litrosRiego()); return;
  }
  if ((litrosObjetivo > 0 && litrosRiego() >= litrosObjetivo) || millis() - inicioRiego > maxMsRiego) {
    pulsoValvula(false); enviarEvento("FIN_RIEGO", litrosRiego()); enviarLecturas();
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_IN1, OUTPUT); pinMode(PIN_IN2, OUTPUT);
  pinMode(PIN_FLOW, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_FLOW), isrFlujo, FALLING);
  analogReadResolution(12);
  ds.begin();
  pulsoValvula(false);                                  // estado seguro
  WiFi.begin(WIFI_SSID, WIFI_CLAVE);
  Serial.print("Conectando Wi-Fi");
  for (int i = 0; i < 40 && WiFi.status() != WL_CONNECTED; i++) { delay(500); Serial.print("."); }
  Serial.println(WiFi.status() == WL_CONNECTED ? " OK" : " sin conexión (reintentará)");
  enviarLecturas();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) WiFi.reconnect();
  uint32_t ahora = millis();
  controlarRiego();
  if (ahora - tComandos >= PERIODO_COMANDOS_MS) { tComandos = ahora; consultarComandos(); }
  // Durante el riego se reporta cada 30 s; en reposo cada 5 min
  if (ahora - tLectura >= (valvulaAbierta ? 30000UL : PERIODO_LECTURA_MS)) { tLectura = ahora; enviarLecturas(); }
  delay(50);
}
